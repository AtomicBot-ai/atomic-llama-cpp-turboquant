"""Build a private F02 variant on the R08 aligned controller/mask and scratch-pool sources."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import sys
import subprocess

HERE=Path(__file__).resolve().parent
NARROW="--narrow" in sys.argv
EXTENDED="--extend" in sys.argv or NARROW
if EXTENDED:
    sys.path.insert(0,str(HERE))
    import extend_narrow as extend
R08=HERE.parent/"blackwell-recovery-1127"
LAB=HERE.parent/"indexed-fa-1127-ab01/baseline"
BUILD=LAB/"build"
STAGE=HERE/("narrow-src" if NARROW else "next-src" if EXTENDED else "candidate-src")
STAGE.mkdir(exist_ok=True)
original=R08/"final-src"
hashes=json.loads((R08/"final-hashes.json").read_text())
for name,digest in hashes.items():
    if name.endswith((".cu",".cuh",".cpp")):
        assert hashlib.sha256((original/name).read_bytes()).hexdigest()==digest

def edit(text,before,after):
    if text.count(before)!=1: raise ValueError(before)
    return text.replace(before,after)

def escape(path):
    return str(path).replace(":","$:").replace(" ","$ ")

diff=[]
def publish(path,old,new):
    target=STAGE/path.name
    target.write_text(new)
    diff.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
                                     fromfile="a/"+str(path),tofile="b/"+str(path)))

model=Path("src/models/inkling2.cpp")
s=(LAB/"src"/model).read_text()
m=edit(s,'#include "../llama-atomic.h"','#include "../llama-atomic.h"\n#include "../llama-memory-contract.h"')
m=edit(m,"    ggml_tensor * x = ggml_transpose(ctx0, ggml_reshape_3d(ctx0, cur, n_channels, n_seq_tokens, n_seqs));",'''#if defined(_WIN32) && (defined(_M_ARM64) || defined(__aarch64__))
    static const bool enable_conv = [] {
        const char * v = std::getenv("ATOMIC_F01_CONV");
        return v && std::strcmp(v, "1") == 0;
    }();
    static const char * select_conv = std::getenv("ATOMIC_F01_SELECT");
    auto selected = [&] {
        if (!select_conv || std::strcmp(select_conv, "safe") == 0) {
            return std::strstr(weight->name, "attn_k_conv") || std::strstr(weight->name, "attn_v_conv") ||
                   std::strstr(weight->name, "ffn_post_conv");
        }
        return std::strcmp(select_conv, "all") == 0 || (std::strcmp(select_conv, "static") == 0 && !dynamic) ||
               (std::strcmp(select_conv, "dynamic") == 0 && dynamic) || std::strstr(weight->name, select_conv);
    };
    if (enable_conv && inkling_dense_backend && n_conv == 4 && n_seq_tokens == 1 && n_seqs == 1 &&
            n_outputs == 1 && cparams.n_rs_seq == 0 && selected() &&
            !cparams.cb_eval && model.memory_contract && !model.memory_contract->inkling_dspark_target &&
            model.memory_contract->discrete.unified && model.ftype() == LLAMA_FTYPE_MOSTLY_NVFP4 &&
            state->type == GGML_TYPE_F32 && expert_executor && expert_executor->inkling_all_resident()) {
        auto reg = ggml_backend_dev_backend_reg(ggml_backend_get_device(inkling_dense_backend));
        using factory = ggml_tensor * (*)(ggml_context *, ggml_tensor *, ggml_tensor *, ggml_tensor *, ggml_tensor *);
        auto make = reinterpret_cast<factory>(ggml_backend_reg_get_proc_address(reg, "atomic_f01_conv"));
        auto * packed = make ? make(ctx0, past, cur, weight, dynamic) : nullptr;
        if (packed) {
            ggml_backend_sched_set_tensor_backend(sched, packed, inkling_dense_backend);
            // State is graph-owned. Preserve the existing cell destination and order the copy
            // after the entire kernel has finished reading the old history.
            const size_t cell_offset = inp->mctx->get_head()*state->nb[1] + offset*3*sizeof(float);
            auto * next = ggml_view_1d(ctx0, packed, 3*n_channels, n_channels*sizeof(float));
            auto * cell = ggml_view_1d(ctx0, state, 3*n_channels, cell_offset);
            ggml_build_forward_expand(gf, ggml_cpy(ctx0, next, cell));
            if (std::getenv("ATOMIC_F01_TRACE")) std::fprintf(stderr,"F01 conv %s %lld\\n",weight->name,(long long)n_channels);
            return ggml_view_2d(ctx0, packed, n_channels, 1, n_channels*sizeof(float), 0);
        }
    }
#endif
    ggml_tensor * x = ggml_transpose(ctx0, ggml_reshape_3d(ctx0, cur, n_channels, n_seq_tokens, n_seqs));''')
line="    ggml_tensor * gate = ggml_concat(ctx0, ggml_rms_norm(ctx0, cur, 1e-6f), ggml_rms_norm(ctx0, message, 1e-6f), 0);"
m=edit(m,line,'''    ggml_tensor * gate = nullptr;
#if defined(_WIN32) && (defined(_M_ARM64) || defined(__aarch64__))
    static const bool pair = [] { const char * v=std::getenv("ATOMIC_F01_PAIR"); return v && std::strcmp(v,"1")==0; }();
    if (pair && inkling_dense_backend && control_kernel && model.memory_contract && model.memory_contract->discrete.unified &&
            !model.memory_contract->inkling_dspark_target && n_tokens == 1 && n_outputs == 1 && cparams.n_rs_seq == 0 && !cparams.cb_eval &&
            cur->type == GGML_TYPE_F32 && message->type == GGML_TYPE_F32 && cur->ne[0] == 2304 &&
            ggml_nelements(cur)==2304 && ggml_are_same_shape(cur, message) &&
            ggml_is_contiguous(cur) && ggml_is_contiguous(message) && expert_executor && expert_executor->inkling_all_resident()) {
        gate = ggml_reshape_2d(ctx0, ggml_rms_norm(ctx0, ggml_concat(ctx0, cur, message, 1), 1e-6f), 4608, 1);
        if (std::getenv("ATOMIC_F01_TRACE")) std::fprintf(stderr,"F01 pair %s\\n",loop.ctrl_down[ctrl]->name);
    }
#endif
    if (!gate) {
        gate = ggml_concat(ctx0, ggml_rms_norm(ctx0, cur, 1e-6f), ggml_rms_norm(ctx0, message, 1e-6f), 0);
    }''')
publish(model,s,extend.model_path(m,NARROW) if EXTENDED else m)

cuda=Path("ggml/src/ggml-cuda")
header=original/"spark-verify.cuh"
s=header.read_text()
h=edit(s,"spark_target_control, spark_target_mask };","spark_target_control, spark_target_mask, spark_target_short_conv };")
h=edit(h,"<= spark_target_mask;","<= spark_target_short_conv;")
h=edit(h,"== spark_target_mask);","== spark_target_mask || (node->op_params[spark_op_tag] == spark_target_short_conv && !ggml_cuda_env_flag(\"ATOMIC_F01_OLD_CUTS\")));")
kernel=(HERE/"conv.cu").read_text().split("static __global__ void fused(",1)[1].split('extern "C"',1)[0]
h=edit(h,"static bool spark_verify_dispatch(", "static __global__ void f01_short_conv("+kernel+"\nstatic bool spark_verify_dispatch(")
h=edit(h,"        case spark_conv: {",'''        case spark_target_short_conv: {
            const int n=dst->src[1]->ne[0];
            auto * out=static_cast<float *>(dst->data);
            const auto * taps=dst->src[3];
            f01_short_conv<<<(n+127)/128,128,0,ctx.stream()>>>(f(0),f(1),f(2),taps?f(3):nullptr,
                out+n,out,n,taps?taps->ne[0]/4:0,ggml_get_op_params_f32(dst,spark_op_tag-1));
        } break;
        case spark_conv: {''')
h+='''\nstatic ggml_tensor * f01_conv_factory(ggml_context * ctx, ggml_tensor * past, ggml_tensor * cur,
        ggml_tensor * weight, ggml_tensor * taps) {
    const int64_t n=cur->ne[0];
    if ((n!=1024 && n!=2304) || ggml_nelements(cur)!=n || past->ne[0]!=3 || past->ne[1]!=n ||
            ggml_nelements(past)!=3*n || weight->ne[0]!=4 || weight->ne[1]!=n || ggml_nelements(weight)!=4*n) return nullptr;
    for (auto * t : {past,cur,weight}) if (t->type!=GGML_TYPE_F32 || !ggml_is_contiguous(t)) return nullptr;
    if (taps && (taps->type!=GGML_TYPE_F32 || !ggml_is_contiguous(taps) ||
            taps->ne[0]!=32 || ggml_nelements(taps)!=32 || n!=1024)) return nullptr;
    ggml_tensor * inputs[]={past,cur,weight,taps};
    auto * node=ggml_custom_4d(ctx,GGML_TYPE_F32,4*n,1,1,1,inputs,taps?4:3,spark_verify_device_only,1,nullptr);
    ggml_set_op_params_f32(node,spark_op_tag-1,1.0f/sqrtf(taps?9.0f:5.0f));
    node->op_params[spark_op_tag]=spark_target_short_conv;
    return node;
}
'''
publish(cuda/header.name,s,extend.header(h,NARROW) if EXTENDED else h)
s=(original/"ggml-cuda.cu").read_text()
marker='    if (strcmp(name, "ggml_backend_cuda_spark_inkling_rel_mask_v1") == 0) {'
c=edit(s,marker,'''    if (strcmp(name,"atomic_f01_conv")==0) {
        static const bool enabled=ggml_cuda_env_flag("ATOMIC_F01_CONV");
        return enabled ? (void *) f01_conv_factory : nullptr;
    }
'''+marker)
anchor="// try and fuse nodes and return the number of nodes to skip"
guard="#if defined(USE_CUDA_GRAPH) && defined(_WIN32) && (defined(_M_ARM64) || defined(__aarch64__))"
c=edit(c,anchor,guard+"\n"+(HERE/"clip-tail.cuh").read_text()+"\n#endif\n\n"+anchor)
start="    if (node->op == GGML_OP_MUL_MAT_ID && cuda_ctx->stream_context().concurrent_events.empty() &&"
c=edit(c,start,guard+"\n    if (node->op == GGML_OP_SQR && f01_clip_capture && ggml_cuda_env_flag(\"ATOMIC_F01_CLIP_FULL\") && f01_try_clip(cuda_ctx,cgraph,i,true)) { return 7; }\n    if (node->op == GGML_OP_SQRT && f01_clip_capture && f01_try_clip(cuda_ctx,cgraph,i,false)) { return 5; }\n#endif\n"+start)
publish(cuda/"ggml-cuda.cu",s,extend.cuda(c) if EXTENDED else c)
path=original/"spark-decode-graph.cuh"
s=path.read_text()
anchor="        const int stride = split ?"
decl="""        struct clip_scope {
            bool saved;
            explicit clip_scope(bool active) : saved(f01_clip_capture) { f01_clip_capture = active; }
            ~clip_scope() { f01_clip_capture = saved; }
        } clip(target_chunks && !pool.parent_uid && ggml_cuda_env_flag("ATOMIC_F01_CLIP"));
"""
publish(cuda/path.name,s,edit(s,anchor,decl+anchor))
unit=next(original.glob("unity_*.cxx"))
body=unit.read_text()
body,n=re.subn(r'^#include "[^"]*/models/inkling2.cpp"', '#include "'+(STAGE/model.name).as_posix()+'"',body,flags=re.M)
assert n==1
(STAGE/unit.name).write_text(body)
(HERE/("narrow.patch" if NARROW else "next.patch" if EXTENDED else "candidate.patch")).write_text("".join(diff).replace("a/ggml\\src\\ggml-cuda\\","a/ggml/src/ggml-cuda/").replace("b/ggml\\src\\ggml-cuda\\","b/ggml/src/ggml-cuda/").replace("src\\models\\","src/models/"))

rules=(BUILD/"r08-final.ninja").read_text()
rules,n=re.subn(r"^build [^\n:]*final-llama-context\.cpp.obj:[^\n]*\n(?:  [^\n]*\n)*", "", rules, flags=re.M)
assert n==1
# Preserve the prebuilt R08 context object. Only two compiler rules, libraries and executables differ.
for name in ("ggml-cuda.cu",unit.name):
    rules=rules.replace(escape(original/name),escape(STAGE/name))
for name in ("ggml-cuda.cu.obj",unit.name+".obj","llama.lib","ggml-cuda.lib","llama-server.exe","raw-server.exe","llama-server.pdb","raw-server.pdb"):
    rules=rules.replace("final-"+name,"f01-"+name)
rules=rules.replace("r08-final-state","f01-fusion-state")
if EXTENDED:
    rules=rules.replace("f01-","f07-" if NARROW else "f06-")
part=HERE/("f07.ninja" if NARROW else "f06.ninja" if EXTENDED else "f01.ninja")
part.write_text(rules)
setup=(LAB/"build.cmd").read_text().split("cmake -S")[0].replace('cd /d "%~dp0"',f'cd /d "{LAB}"')
cmd=HERE/"build-candidate.cmd"
cmd.write_text(setup+f'ninja -C build -f "{part}" -j 1 bin\\f01-llama-server.exe bin\\f01-raw-server.exe\nexit /b %errorlevel%\n')
if EXTENDED:
    cmd.write_text(cmd.read_text().replace("bin\\f01-", "bin\\f07-" if NARROW else "bin\\f06-"))
subprocess.run(["cmd","/c",str(cmd)],check=True)
