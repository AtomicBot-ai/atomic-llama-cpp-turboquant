"""Measure four normal R08 requests per arm if the fixed-input qualification finishes in time."""
from datetime import datetime, timezone
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from qualify_narrow import BASE, arm
from window import exclusive

root = Path(__file__).resolve().parent
latest = datetime.fromisoformat(sys.argv[1])
while not (root / "budget_depth01/restoration.json").is_file():
    if datetime.now(timezone.utc) >= latest:
        sys.exit("Short serving window expired")
    time.sleep(1)
if datetime.now(timezone.utc) >= latest:
    sys.exit("Short serving window expired")
winner = next((root / "abba_depth01").glob("01-*.json")).stem.split("-", 1)[1]
BASE["cases"] = {name: BASE["cases"][name] for name in ("lunch", "sky")}
out = root / "serving_depth_short01"
out.mkdir(exist_ok=False)
with exclusive(out):
    for index, mode in enumerate(("frozen+ext+v7", winner)):
        arm(out, "serve", index, mode)
