"""Additional, separately switchable experiments on the remaining measured device work."""
from pathlib import Path
here=Path(__file__).resolve().parent

def model_path(s, narrow=False):
    marker="    ggml_tensor * states = ggml_reshape_3d(ctx0, cur, n_embd, 1, n_tokens);"
    assert s.count(marker)==1
    result=s.replace(marker,'''#if defined(_WIN32) && (defined(_M_ARM64) || defined(__aarch64__))
    static const bool pack = [] {
        const char * v=std::getenv("ATOMIC_F01_DEPTH_PACK"); return v && std::strcmp(v,"1")==0;
    }();
    if (pack && n_tokens==1 && n_outputs==1 && ubatch.n_seqs==1 && cparams.n_rs_seq==0 && !cparams.cb_eval &&
            inkling_dense_backend && control_kernel && expert_executor && expert_executor->inkling_all_resident() &&
            model.memory_contract && model.memory_contract->discrete.unified && !model.memory_contract->inkling_dspark_target &&
            query->type==GGML_TYPE_F32 && ggml_is_contiguous(query) && ggml_is_matrix(query) && query->ne[0]==2304) {
        auto reg=ggml_backend_dev_backend_reg(ggml_backend_get_device(inkling_dense_backend));
        using factory=ggml_tensor * (*)(ggml_context *,ggml_tensor *,ggml_tensor * const *,size_t);
        auto make=reinterpret_cast<factory>(ggml_backend_reg_get_proc_address(reg,"atomic_f01_depth_pack"));
        if (auto * p=make ? make(ctx0,cur,blocks.data(),blocks.size()) : nullptr) {
            ggml_backend_sched_set_tensor_backend(sched,p,inkling_dense_backend);
            const int64_t d=blocks.size()+1;
            auto * rows=ggml_view_2d(ctx0,p,2304,d,2304*sizeof(float),0);
            auto * cols=ggml_view_2d(ctx0,p,d,2304,d*sizeof(float),d*2304*sizeof(float));
            auto * scores=ggml_mul_mat(ctx0,rows,query);
            scores=ggml_soft_max_ext(ctx0,scores,nullptr,1.0f/sqrtf(n_embd),0.0f);
            if (std::getenv("ATOMIC_F01_TRACE")) { std::fprintf(stderr,"F01 pack %lld\\n",(long long)d); }
            return ggml_mul_mat(ctx0,cols,scores);
        }
    }
#endif
'''+marker)

    if narrow:
        result=result.replace("            auto * cols=ggml_view_2d(ctx0,p,d,2304,d*sizeof(float),d*2304*sizeof(float));", """            static const char * kind=std::getenv("ATOMIC_F01_DEPTH_MODE");
            const bool raw=kind && std::strncmp(kind,"raw",3)==0;
            if (raw) { rows=ggml_rms_norm(ctx0,rows,1e-6f); }
            auto * cols=raw ? ggml_cont(ctx0,ggml_transpose(ctx0,rows)) :
                ggml_view_2d(ctx0,p,d,2304,d*sizeof(float),d*2304*sizeof(float));
            if (kind && (std::strcmp(kind,"keepquery")==0 || std::strcmp(kind,"rawkeep")==0)) {
                query=ggml_repeat(ctx0,query,ggml_new_tensor_3d(ctx0,GGML_TYPE_F32,n_embd,query->ne[1],1));
            }""")
    return result

def header(s, narrow=False):
    s=s.replace("spark_target_short_conv };","spark_target_short_conv, spark_target_depth_pack };")
    s=s.replace("<= spark_target_short_conv;","<= spark_target_depth_pack;")
    mark="static bool spark_verify_dispatch("
    code=(here/"depth-pack.cuh").read_text()
    assert s.count(mark)==1
    s=s.replace(mark,code+"\n"+mark)
    mark="        case spark_target_short_conv: {"
    s=s.replace(mark,'''        case spark_target_depth_pack: {
            spark_depth_states inputs{};
            const int d=dst->ne[0]/(2*2304);
            for (int i=0;i<d;++i) { inputs.data[i]=f(i); }
            f01_pack_rms<<<d,1024,0,ctx.stream()>>>(inputs,static_cast<float *>(dst->data),2304,d,1e-6f);
        } break;
'''+mark)
    if narrow:
        pos="static ggml_tensor * f01_pack_factory("
        s=s.replace(pos,"""static __global__ void f01_pack_copy(spark_depth_states inputs,float4 * out) {
    const int i=blockIdx.x*blockDim.x+threadIdx.x;
    if (i<576) { out[blockIdx.y*576+i]=reinterpret_cast<const float4 *>(inputs.data[blockIdx.y])[i]; }
}
"""+pos)
        s=s.replace("auto * dst=ggml_custom_4d(ctx,GGML_TYPE_F32,2*2304*(n+1)","""static const char * kind=std::getenv("ATOMIC_F01_DEPTH_MODE");
    const bool raw=kind && std::strncmp(kind,"raw",3)==0;
    auto * dst=ggml_custom_4d(ctx,GGML_TYPE_F32,(raw?1:2)*2304*(n+1)""")
        s=s.replace("dst->op_params[spark_op_tag]=spark_target_depth_pack;","dst->op_params[spark_op_tag-1]=raw;\n    dst->op_params[spark_op_tag]=spark_target_depth_pack;")
        s=s.replace("const int d=dst->ne[0]/(2*2304);","const bool raw=dst->op_params[spark_op_tag-1]!=0;\n            const int d=dst->ne[0]/((raw?1:2)*2304);")
        s=s.replace("            f01_pack_rms<<<d","            if (raw) { f01_pack_copy<<<dim3(3,d),256,0,ctx.stream()>>>(inputs,static_cast<float4 *>(dst->data)); break; }\n            f01_pack_rms<<<d")
    return s

def cuda(s):
    marker='    if (strcmp(name,"atomic_f01_conv")==0) {'
    s=s.replace(marker,'''    if (strcmp(name,"atomic_f01_depth_pack")==0) { return (void *) f01_pack_factory; }
'''+marker)
    marker="static bool f01_try_clip("
    s=s.replace(marker,(here/"project-exact.cuh").read_text()+"\n"+marker)
    marker="    if (node->op == GGML_OP_SQR && f01_clip_capture"
    return s.replace(marker,'''    if (node->op == GGML_OP_MUL_MAT && f01_clip_capture && ggml_cuda_env_flag("ATOMIC_F01_PROJECT") &&
            f01_try_project(cuda_ctx,cgraph,i)) { return 2; }
'''+marker)
