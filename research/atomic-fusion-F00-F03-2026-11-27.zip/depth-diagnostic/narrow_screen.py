"""Localize the depth-preparation mismatch and estimate the cost of exact remaining operations."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qualify_narrow import arm
from reduce import numeric,timing
from window import exclusive

root=Path(__file__).resolve().parent
ref="frozen+ext+v7"
base="both+safe+clipfull+ext+v7+project"
def group(folder,action,modes):
    out=root/folder
    out.mkdir(exist_ok=False)
    with exclusive(out):return [arm(out,action,i,m) for i,m in enumerate(modes)]

if __name__=="__main__":
    if "--after" in sys.argv:
        from datetime import datetime,timezone
        import time
        latest=datetime.fromisoformat(sys.argv[sys.argv.index("--after")+1])
        while not (root/"trace_next/summary.json").is_file():
            if datetime.now(timezone.utc)>=latest: sys.exit("No time left for the optional depth diagnosis")
            time.sleep(3)
        if datetime.now(timezone.utc)>=latest: sys.exit("No time left for the optional depth diagnosis")
    out=root/"build07"
    out.mkdir(exist_ok=False)
    with exclusive(out), (out/"compiler.log").open("w") as log:
        subprocess.run([sys.executable,str(root/"prepare_narrow.py"),"--narrow"],stdout=log,stderr=subprocess.STDOUT,check=True)
    modes=[base+"+"+kind for kind in ("keepquery","rawkeep","rawdirect")]
    probe=group("depthloc01","localize",[ref]+modes)
    valid=[m for m,r in zip(modes,probe[1:]) if not numeric(probe[0],r)["primary"]["changed_fp"] and r["hits_at_graph_build"]["pack"]]
    if valid:
        qa=group("depthqa01","qa",[ref]+valid)
        valid=[m for m,r in zip(valid,qa[1:]) if not numeric(qa[0],r)["primary"]["changed_fp"] and
               r["fingerprints"][:65]==r["fingerprints"][-65:]]
    if valid:
        arm_names=[base]+valid+[base]
        rows=group("depthscreen01","abba",arm_names)
        print(list(zip(arm_names,[timing(r["requests"])["ms_per_update"] for r in rows])),flush=True)
