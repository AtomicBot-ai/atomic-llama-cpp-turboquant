"""Confirm a faster exact depth variant on three same-binary ABBA blocks within the first-pass timebox."""
from datetime import datetime,timezone
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qualify_narrow import arm
from reduce import timing
from window import exclusive

here=Path(__file__).resolve().parent
dest=here/"depthscreen01"
latest=datetime.fromisoformat(sys.argv[1])
while not (dest/"restoration.json").is_file():
    if datetime.now(timezone.utc)>=latest:sys.exit("No completed depth screen in time")
    time.sleep(2)
if datetime.now(timezone.utc)>=latest:sys.exit("Time reserved for a complete ABBA window has elapsed")
paths=sorted(dest.glob("[0-9][0-9]-*.json"))
values=[timing(json.loads(p.read_text())["requests"])["ms_per_update"] for p in paths]
j=min(range(1,len(values)-1),key=values.__getitem__)
best=paths[j].stem.split("-",1)[1]
if values[j]>=min(values[0],values[-1]):
    print("Depth screen did not beat both controls",values,flush=True)
    sys.exit(0)
ref="frozen+ext+v7"
print("Confirming",best,values,flush=True)
for folder,action,modes in [("abba_depth01","abba",[ref,best,best,ref]*3),
                            ("state_depth01","state",[ref,best]),("budget_depth01","partial",[ref,best])]:
    out=here/folder
    out.mkdir(exist_ok=False)
    with exclusive(out):
        for i,mode in enumerate(modes):arm(out,action,i,mode)
