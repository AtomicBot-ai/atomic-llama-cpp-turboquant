// mmvf.cu at 6115c7090 uses pairs (2*lane, 2*lane+1) for the width-one FP32 rank-64 projection.
static __global__ void f01_project_exact(const float * cur,const float * msg,const float2 * gate,
                                         const float2 * gain,const float2 * forget,float * dst) {
    const int lane=threadIdx.x%32, row=blockIdx.x*8+threadIdx.x/32;
    const float2 x=gate[lane], g=gain[row*32+lane], f=forget[row*32+lane];
    float a=0,b=0;
    ggml_cuda_mad(a,g.x,x.x); ggml_cuda_mad(a,g.y,x.y);
    ggml_cuda_mad(b,f.x,x.x); ggml_cuda_mad(b,f.y,x.y);
    a=warp_reduce_sum<32>(a); b=warp_reduce_sum<32>(b);
    if (!lane) {
        dst[row]=__fadd_rn(__fsub_rn(cur[row],__fmul_rn(tanhf(b),cur[row])),__fmul_rn(tanhf(a),msg[row]));
    }
}
static bool f01_try_project(ggml_backend_cuda_context * ctx,ggml_cgraph * graph,int i) {
    if (i+2>=graph->n_nodes) { return false; }
    auto ** op=graph->nodes+i;
    if (op[2]->op!=GGML_OP_CUSTOM || !spark_verify_owned(op[2]) || op[2]->op_params[spark_op_tag]!=spark_target_control ||
        !ggml_can_fuse_subgraph(graph,i,{GGML_OP_MUL_MAT,GGML_OP_MUL_MAT,GGML_OP_CUSTOM},{i+2})) { return false; }
    auto * g=op[2]->src[2], * f=op[2]->src[3], * cur=op[2]->src[0], * msg=op[2]->src[1];
    if (!((g==op[0] && f==op[1]) || (g==op[1] && f==op[0])) || g->src[1]!=f->src[1]) { return false; }
    auto * gate=g->src[1], * wg=g->src[0], * wf=f->src[0], * out=op[2];
    for (auto * t : {gate,wg,wf,cur,msg,out}) {
        if (t->type!=GGML_TYPE_F32 || !ggml_is_contiguous(t) || reinterpret_cast<uintptr_t>(t->data)%8!=0) { return false; }
        const uintptr_t x=reinterpret_cast<uintptr_t>(t->data), y=reinterpret_cast<uintptr_t>(out->data);
        if (t!=out && !((t==cur || t==msg) && x==y) && x<y+ggml_nbytes(out) && y<x+ggml_nbytes(t)) { return false; }
    }
    if (ggml_nelements(cur)!=2304 || !ggml_are_same_shape(cur,msg) || !ggml_are_same_shape(cur,out) ||
        ggml_nelements(gate)!=64 || gate->ne[0]!=64 || wg->ne[0]!=64 || wg->ne[1]!=2304 ||
        !ggml_is_matrix(wg) || !ggml_are_same_shape(wg,wf)) { return false; }
    f01_project_exact<<<288,256,0,ctx->stream()>>>(static_cast<const float *>(cur->data),
        static_cast<const float *>(msg->data),static_cast<const float2 *>(gate->data),
        static_cast<const float2 *>(wg->data),static_cast<const float2 *>(wf->data),static_cast<float *>(out->data));
    if (ggml_cuda_env_flag("ATOMIC_F01_TRACE")) { std::fprintf(stderr,"F01 project 64\n"); }
    return true;
}
