"""Run fixed-ID width-one controls through the existing Spark servers."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = Path.home() / "inkling-spark"
OLD = ROOT / "blackwell-fast-1127"
bench = runpy.run_path(str(OLD / "bench.py"))["BENCH"]
cases = {v["id"]: v["messages"] for v in map(json.loads, (OLD / "prompts.jsonl").read_text().splitlines())}
names = ["lunch", "sky", "python", "briefing"]
fixture = HERE / "fixture.json"

def rpc(url, route, **payload):
    with bench["post"](url + route, payload) as response:
        return json.load(response)

def tokens(url, name):
    rendered = rpc(url, "/apply-template", messages=cases[name])["prompt"]
    ids = rpc(url, "/tokenize", content=rendered, add_special=True, parse_special=True)["tokens"]
    return ids[:1536]

def profile(label):
    mode = label.split(".")[0]
    config_file = "R00b-2-stock.jsonl" if mode.startswith("stock") else "R00b-1-target.jsonl"
    with (OLD / config_file).open() as f:
        config = json.loads(f.readline())
    cmd, flags = config["cmd"], config["env"]
    if mode in ("uncapped", "clean", "clean-nograph"):
        del cmd[cmd.index("--engine-budget-mib"):]
    if mode in ("clean", "clean-nograph"):
        flags = {}
    if mode.endswith("-nograph"):
        flags["GGML_CUDA_DISABLE_GRAPHS"] = "1"
    if mode == "nosplit":
        flags["LLAMA_EXPERIMENTAL_SPARK_SPLIT_GRAPH"] = "0"
    if mode == "noverify":
        flags["LLAMA_EXPERIMENTAL_SPARK_VERIFY"] = "0"
    if mode == "noattn":
        flags["LLAMA_EXPERIMENTAL_SPARK_ATTENTION"] = "0"
    if mode.endswith("-nofusion"):
        flags["GGML_CUDA_DISABLE_FUSION"] = "1"
    if mode in ("pool-release", "pool-off"):
        cmd[0] = str(Path(cmd[0]).with_name("pool-llama-server.exe"))
        if mode == "pool-release":
            flags["LLAMA_EXPERIMENTAL_SPARK_SHORT_PROMPT_POOL"] = "1"
        return cmd,flags,hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
    if mode.startswith("final"):
        cmd[0] = str(Path(cmd[0]).with_name("final-llama-server.exe"))
        if mode in ("final","final-both"):
            flags["LLAMA_EXPERIMENTAL_SPARK_TARGET_FUSION"]="1"
        if mode in ("final-pool","final-both"):
            flags["LLAMA_EXPERIMENTAL_SPARK_SHORT_PROMPT_POOL"]="1"
        return cmd,flags,hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
    if mode.startswith(("operators-","onegraph-","aligned-")):
        cmd[0] = str(Path(cmd[0]).with_name(mode.split("-")[0]+"-llama-server.exe"))
        flags["LLAMA_EXPERIMENTAL_SPARK_TARGET_FUSION"] = "1"
        if mode.startswith("aligned-"):
            flags["R08_TARGET_SAFE_CUTS"]="1"
        if mode.startswith("onegraph-"):
            flags["R08_TARGET_ONE_GRAPH"]="1"
        flags["R08_TARGET_OPERATORS"] = str(int(mode.split("-")[1]))
        return cmd,flags,hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
    if mode.startswith(("candidate","fusion2")):
        cmd[0] = str(Path(cmd[0]).with_name(mode.split("-")[0]+"-llama-server.exe"))
        if mode in ("candidate","fusion2"):
            flags["LLAMA_EXPERIMENTAL_SPARK_TARGET_FUSION"] = "1"
        return cmd, flags, hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
    return cmd, flags, config["sha256"]

def record_request(url, name, data, expected, greedy=False, constant=False):
    body = dict(prompt=data, n_predict=65, ignore_eos=greedy, cache_prompt=False, stream=True,
                temperature=0, return_tokens=True, seed=42)
    if constant:
        expected = [13] * 65
        body["logit_bias"] = [[13, 100.0]]
    elif not greedy:
        body["grammar"] = "root ::= " + " ".join(f"<[{n}]>" for n in expected)
    before = time.perf_counter()
    ids, arrival = [], []
    final = {}
    with bench["post"](url + "/completion", body) as stream:
        for line in stream:
            if not line.startswith(b"data:") or line[5:].strip() == b"[DONE]":
                continue
            event = json.loads(line[5:])
            if "error" in event:
                raise ValueError(event["error"])
            if event.get("stop"):
                final = event
            else:
                step = (time.perf_counter() - before) * 1000
                for token in event["tokens"]:
                    ids.append(token)
                    arrival.append(step)
    elapsed = (time.perf_counter() - before) * 1000
    timing = final.get("timings", {})
    if len(ids) != 65 or (expected is not None and ids != expected) or timing.get("cache_n") != 0 or timing.get("prompt_n") != len(data):
        raise ValueError((name, len(data), timing, len(ids), ids[:12], (expected or [])[:12]))
    return dict(case=name, ids=ids, arrival_ms=arrival, ttft_ms=arrival[0], wall_ms=elapsed,
                timings=timing, stop=final.get("stop_type"))

def output(cmd):
    return subprocess.check_output(cmd, text=True, errors="replace").strip()

def telemetry():
    return output(["nvidia-smi", "--query-gpu=name,compute_cap,temperature.gpu,clocks.sm,clocks.mem,power.draw,utilization.gpu", "--format=csv,noheader"])

def run(label):
    cmd, flags, expected_hash = profile(label)
    exe_hash = hashlib.file_digest(open(cmd[0],"rb"),"sha256").hexdigest() if hasattr(hashlib,"file_digest") else hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
    assert exe_hash == expected_hash
    env = {k:v for k,v in os.environ.items() if not k.startswith(("LLAMA_", "GGML_", "INKLING_"))}
    cuda = Path(os.environ["ProgramFiles"]) / "NVIDIA GPU Computing Toolkit/CUDA/v13.4/bin/arm64"
    env.update(flags)
    env["PATH"] = str(cuda) + os.pathsep + env["PATH"]
    log = HERE / (label + ".log")
    with (HERE / (label + ".jsonl")).open("x") as out, log.open("x") as stderr:
        def emit(**row):
            out.write(json.dumps(row) + "\n")
            out.flush()
        emit(cmd=cmd, env=flags, exe_hash=exe_hash, gpu=telemetry())
        proc = subprocess.Popen(cmd, env=env, cwd=ROOT, stdout=stderr, stderr=subprocess.STDOUT)
        try:
            url = bench["wait_ready"](proc, log)
            mods = output(["powershell", "-NoProfile", "-Command", f"(Get-Process -Id {proc.pid}).Modules | Where-Object ModuleName -match 'cuda|cublas|ggml|llama' | Select-Object -ExpandProperty FileName"])
            emit(modules={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in mods.splitlines()})
            prompts = {n:tokens(url,n) for n in names}
            if not fixture.exists():
                assert label.startswith("stock")
                data = {n:dict(prompt=v, continuation=record_request(url,n,v,None,True)["ids"]) for n,v in prompts.items()}
                fixture.write_text(json.dumps(data))
            data = json.loads(fixture.read_text())
            assert all(prompts[n] == data[n]["prompt"] for n in names)
            emit(fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest())
            for i,n in enumerate(["lunch"] + names):
                result = record_request(url,n,prompts[n],data[n]["continuation"],constant=".bias" in label)
                emit(warmup=i==0, metrics=bench["engine_metrics"](url), gpu=telemetry(), **result)
                print(label,n,result["timings"]["predicted_per_token_ms"],flush=True)
            if ".abba" in label:
                return
            for n,offset in [(n,0) for n in names] + [(n,32) for n in names]:
                probe = rpc(url,"/completion",prompt=prompts[n]+data[n]["continuation"][:offset],n_predict=1,cache_prompt=False,temperature=0,
                            n_probs=8,post_sampling_probs=False,return_tokens=True)
                emit(probe=n, offset=offset, tokens=probe["tokens"], top=probe.get("completion_probabilities"))
        finally:
            proc.terminate()
            proc.wait()

def isolated(labels):
    restore = runpy.run_path(str(OLD / "serve-loopback.py"))["load"]()
    previous = json.loads((ROOT / "results/source-rollback-retain-20261125/manual-instance.json").read_bytes())
    launcher = OLD / "serve-loopback.py"
    cmd, _ = restore["prepare"]()
    pid, exe = previous["pid"], Path(cmd[0])
    assert previous["cmd"] == cmd and Path(previous["launcher"]) == launcher
    assert restore["owner"]() == pid and restore["pid_path"](pid) == exe
    restore["idle"]()
    restore["stop"](pid,exe)
    try:
        for _ in range(30):
            if restore["pid_path"](pid) != exe:
                break
            time.sleep(.5)
        assert not restore["ps"]("Get-Process llama-server* -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id; exit 0")
        for label in labels:
            run(label)
    finally:
        restore["launch"](launcher,["serve"])
        current = restore["ready"](exe,pid)
        assert current["cmd"] == cmd and current["sha256"] == previous["sha256"]
        print("Restored", current["url"], current["pid"], flush=True)

if __name__ == "__main__":
    isolated(sys.argv[1:])
