"""Run a single warmed chat profile on the Windows Spark host."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path.home() / "inkling-spark"
BUILD = ROOT / "indexed-fa-1127-ab01"
BENCH = runpy.run_path(str(BUILD / "baseline/src/tools/expert-source/bench-inkling-metal.py"))
CAP = 20580 << 20


def measure(url, body):
    start = time.perf_counter()
    first = None
    answer = []
    reasoning = []
    timings = {}
    finish = None
    with BENCH["post"](url + "/v1/chat/completions", body) as stream:
        for line in stream:
            if not line.startswith(b"data:"):
                continue
            data = line[5:].strip()
            if data == b"[DONE]":
                break
            event = json.loads(data)
            if "error" in event:
                raise RuntimeError(event["error"])
            timings = event.get("timings") or timings
            for choice in event.get("choices", []):
                delta = choice.get("delta", {})
                content = delta.get("content") or ""
                thought = delta.get("reasoning_content") or delta.get("reasoning") or ""
                if first is None and (content or thought):
                    first = time.perf_counter() - start
                answer.append(content)
                reasoning.append(thought)
                finish = choice.get("finish_reason") or finish
    if first is None or not finish or timings.get("cache_n") != 0 or not timings.get("predicted_ms", 0):
        raise ValueError((first, finish, timings))
    return dict(ttft_s=first, wall_s=time.perf_counter()-start, timings=timings, finish=finish,
                answer="".join(answer), reasoning_sha256=hashlib.sha256("".join(reasoning).encode()).hexdigest())


def run(mode, output, cases, seeds, max_tokens=192):
    trace = mode.startswith("trace-")
    wide = mode.startswith("wide-")
    phase = mode.startswith("phase-")
    mode = mode.removeprefix("trace-").removeprefix("phase-").removeprefix("wide-")
    frozen = json.loads((HERE / "profile.json").read_text())
    flags = dict(frozen["env"], LLAMA_EXPERIMENTAL_SPARK_VERIFY_MMQ="1")
    args = frozen["args"]
    exe = BUILD / "baseline/build/bin/llama-server.exe"
    args[args.index("-m")+1] = str(ROOT / args[args.index("-m")+1])
    args[args.index("-md")+1] = str(ROOT / args[args.index("-md")+1])
    if mode in ("target", "stock"):
        args = args[:args.index("-md")]
    stock = mode in ("stock","stock-df7")
    if stock:
        exe = BUILD / "stock-b12810/bin/llama-server.exe"
        budget=args.index("--engine-budget-mib")
        del args[budget:budget+2]
        flags = {}
    if trace:
        exe = BUILD / "build/bin/llama-fa-profile.exe"
        flags["GPU_ACTIVITY_FILE"] = str(output.with_suffix(".tsv"))
        flags["LLAMA_EXPERIMENTAL_SPARK_INDEXED_BIAS"] = "0"
    if wide:
        exe = exe.with_name("llama-wide.exe")
        flags["ATOMIC_ORACLE_CONTROL"] = "wide"
    if phase:
        exe = ROOT / "results/inkling-dflash2-v1/build/bin/llama-server-block.exe"
        flags["INKLING_PHASE_PROBE"] = "1"
        flags["INKLING_TRIAL_BLOCK_VERIFY"] = "1" if mode == "dfblock" else "0"
    if mode == "project":
        flags["LLAMA_EXPERIMENTAL_SPARK_CONTROL_PROJECT"] = "1"
    if mode in ("q8", "default"):
        flags["LLAMA_EXPERIMENTAL_SPARK_VERIFY_MMQ"] = "q8" if mode == "q8" else "0"
    if mode == "depth3":
        flags["LLAMA_EXPERIMENTAL_SPARK_DSPARK_MODEL_DEPTH"] = "3"
    if mode.startswith("df") or mode=="stock-df7":
        args[args.index("--spec-type")+1] = "draft-dflash2"
        args[args.index("-md")+1] = str(ROOT / "results/inkling-dflash2-v1/inkling-dflash2-bf16.gguf")
        args[args.index("--spec-draft-n-max")+1] = "4" if mode == "df4" else "7"
        args.extend(["--spec-draft-sampling", "probabilistic"])
        if not stock:
            flags.update(LLAMA_EXPERIMENTAL_SPARK_DFLASH2="1", LLAMA_EXPERIMENTAL_SPARK_BLOCK_VERIFY="1" if mode == "dfblock" else "0")
    env = {k:v for k,v in os.environ.items() if not k.startswith(("LLAMA_", "GGML_", "INKLING_"))}
    cuda = Path(os.environ["ProgramFiles"]) / "NVIDIA GPU Computing Toolkit/CUDA/v13.4/bin/arm64"
    env.update(flags)
    env["PATH"] = str(cuda) + os.pathsep + env["PATH"]
    if trace or phase:
        sdk = next((ROOT / "results/spark-kernel-profile-v1").glob("cuda_cupti-*-archive"))
        env["PATH"] = str(sdk / "lib/arm64") + os.pathsep + env["PATH"]
    cmd = [str(exe), *args]
    if trace and mode == "df7":
        cmd += ["-lv","4"]
    fixture = {r["id"]:r["messages"] for r in map(json.loads, (HERE / "prompts.jsonl").read_text().splitlines())}
    log = output.with_suffix(".log")
    with output.open("x", encoding="utf-8") as raw, log.open("x") as f:
        def emit(record):
            raw.write(json.dumps(record, ensure_ascii=True) + "\n")
            raw.flush()
        emit(dict(mode=mode, cmd=cmd, env=flags, sha256=hashlib.sha256(exe.read_bytes()).hexdigest()))
        proc = subprocess.Popen(cmd, env=env, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
        try:
            url = BENCH["wait_ready"](proc, log)
            with BENCH["HTTP"].open(url+"/props") as props:
                template = json.load(props).get("chat_template")
            emit(dict(chat_template_sha256=hashlib.sha256(template.encode()).hexdigest() if isinstance(template,str) else None))
            requests = [(True, "lunch", 44)] + [(False,c,s) for s in seeds for c in cases]
            if trace or wide:
                requests = [(False, c, 42) for c in cases]
            for warm, case, seed in requests:
                before = BENCH["engine_metrics"](url)
                body = dict(messages=fixture[case], seed=seed, temperature=1.0,
                            max_tokens=32 if trace or wide else (192 if warm else max_tokens), cache_prompt=False, stream=True)
                result = measure(url, body)
                after = BENCH["engine_metrics"](url)
                delta = None
                if (not stock and mode != "target") or "expert_logical_read_bytes" in after:
                    delta = after["expert_logical_read_bytes"] - before["expert_logical_read_bytes"]
                emit(dict(case=case, seed=seed, warmup=warm, metrics=after, expert_source_bytes=delta, **result))
                if not stock and (delta not in (0, None) or after["budget_requested_bytes"] != CAP or
                    after["budget_applied_bytes"] != CAP or not 0 < after["budget_high_water_bytes"] <= CAP or
                    after["policy_decisions"] != 0):
                    raise RuntimeError("Invalid resident budget")
                if mode not in ("stock","target") and not result["timings"].get("draft_n"):
                    raise RuntimeError("No proposals")
                print(mode, case, seed, result["timings"]["predicted_per_second"], flush=True)
        finally:
            if proc.poll() is None:
                proc.terminate()
            proc.wait()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices="target stock fp4 q8 default depth3 project stock-df7 wide-df7 trace-fp4 trace-q8 trace-default trace-dfblock trace-df7 phase-fp4 phase-df7 phase-dfblock df4 df7 dfblock".split())
    p.add_argument("output", type=Path)
    p.add_argument("--cases", nargs="+", default=["lunch","sky"])
    p.add_argument("--seeds", nargs="+", type=int, default=[42])
    a = p.parse_args()
    run(a.mode, a.output, a.cases, a.seeds)
