#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-backend.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

namespace fs=std::filesystem;
using vec=std::vector<float>;
extern "C" void bench_conv(const float*,const float*,const float*,const float*,int,int,float*,float*,float*,float*,float*,float*);
static vec load(const fs::path & file) {
    const auto bytes=fs::file_size(file);
    GGML_ASSERT(bytes && bytes%4==0);
    vec v(bytes/4);
    std::ifstream f(file,std::ios::binary);f.read(reinterpret_cast<char*>(v.data()),bytes);GGML_ASSERT(f.good());
    return v;
}
static void compare(std::ostream & out,const vec & a,const vec & b) {
    GGML_ASSERT(a.size()==b.size());
    int changed=0,first=-1; double max_abs=0,max_rel=0;
    for(size_t i=0;i<a.size();i++) {
        GGML_ASSERT(std::isfinite(a[i]) && std::isfinite(b[i]));
        if(std::memcmp(&a[i],&b[i],4)!=0) {changed++;if(first<0)first=int(i);}
        double error=std::abs(double(a[i])-b[i]);
        max_abs=std::max(max_abs,error);max_rel=std::max(max_rel,error/std::max(1e-8,std::abs(double(a[i]))));
    }
    out<<"{\"changed\":"<<changed<<",\"first\":"<<first<<",\"max_abs\":"<<max_abs<<",\"max_rel\":"<<max_rel<<"}";
}

struct controller {
    ggml_context * ctx;
    ggml_cgraph * graph;
    ggml_backend_buffer_t buf;
    ggml_tensor * result;
    controller(ggml_backend_t backend,const fs::path & dir,bool paired) {
        ctx=ggml_init({1<<20,nullptr,true});
        graph=ggml_new_graph_custom(ctx,64,false);
        auto matrix=[&](int k,int n){return ggml_new_tensor_2d(ctx,GGML_TYPE_F32,k,n);};
        auto *cur=matrix(2304,1), *msg=matrix(2304,1), *wd=matrix(4608,64), *wg=matrix(64,2304), *wf=matrix(64,2304);
        ggml_tensor * input;
        if(paired) {
            auto * stack=ggml_concat(ctx,cur,msg,1);
            input=ggml_reshape_2d(ctx,ggml_rms_norm(ctx,stack,1e-6f),4608,1);
        } else {
            input=ggml_concat(ctx,ggml_rms_norm(ctx,cur,1e-6f),ggml_rms_norm(ctx,msg,1e-6f),0);
        }
        auto * down=ggml_mul_mat(ctx,wd,input);
        auto reg=ggml_backend_dev_backend_reg(ggml_backend_get_device(backend));
        using factory=ggml_tensor * (*)(ggml_context*,ggml_tensor*,ggml_tensor*,ggml_tensor*,ggml_tensor*);
        auto tail=reinterpret_cast<factory>(ggml_backend_reg_get_proc_address(reg,"ggml_backend_cuda_spark_inkling_control_v1"));
        GGML_ASSERT(tail);
        result=tail(ctx,cur,msg,ggml_mul_mat(ctx,wg,down),ggml_mul_mat(ctx,wf,down));
        GGML_ASSERT(result);ggml_build_forward_expand(graph,result);
        buf=ggml_backend_alloc_ctx_tensors(ctx,backend);GGML_ASSERT(buf);
        auto fill=[&](ggml_tensor * t,const char * name) {
            auto values=load(dir/name);GGML_ASSERT(4*values.size()==ggml_nbytes(t));
            ggml_backend_tensor_set(t,values.data(),0,ggml_nbytes(t));
        };
        fill(cur,"cur");fill(msg,"msg");fill(wd,"wd");fill(wg,"wg");fill(wf,"wf");
    }
    double time(ggml_backend_t backend) {
        for(int i=0;i<16;i++) GGML_ASSERT(ggml_backend_graph_compute_async(backend,graph)==GGML_STATUS_SUCCESS);
        ggml_backend_synchronize(backend);
        auto start=std::chrono::steady_clock::now();
        for(int i=0;i<128;i++) GGML_ASSERT(ggml_backend_graph_compute_async(backend,graph)==GGML_STATUS_SUCCESS);
        ggml_backend_synchronize(backend);
        return std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/128;
    }
    vec read() { vec v(2304);ggml_backend_tensor_get(result,v.data(),0,4*v.size());return v; }
    ~controller() { ggml_backend_buffer_free(buf);ggml_free(ctx); }
};
int main(int argc,char ** argv) {
    GGML_ASSERT(argc==3);
    fs::path inputs=argv[1],out=argv[2];
    ggml_backend_load_all();
    auto backend=ggml_backend_init_by_name("CUDA0",nullptr);GGML_ASSERT(backend);
    std::ofstream f(out/"replay.jsonl");
    f<<std::setprecision(9);
    for(int step=1;step<=3;step++) for(int visit=0;visit<3;visit++) {
        auto key=std::to_string(step)+"-"+std::to_string(visit);
        auto cd=inputs/("conv-"+key);
        vec window=load(cd/"window"), w=load(cd/"weight"),t=load(inputs/("taps-"+key)/"values");
        vec actual=load(cd/"output");
        int n=int(w.size()/4);
        GGML_ASSERT(n==1024 && window.size()==w.size() && t.size()==32);
        vec cur(n),past(3*n),n0(3*n),n1(3*n),ref(n),cand(n),ssm(n);
        for(int i=0;i<n;i++) {
            cur[i]=window[4*i+3];std::copy_n(&window[4*i],3,&past[3*i]);
        }
        if(step==1) GGML_ASSERT(std::all_of(past.begin(),past.end(),[](float x){return x==0;}));
        float us[4]={};
        bench_conv(past.data(),cur.data(),w.data(),t.data(),n,8,ssm.data(),ref.data(),cand.data(),n0.data(),n1.data(),us);
        f<<"{\"block\":\"conv\",\"key\":\""<<key<<"\",\"us_abba\":["<<us[0]<<","<<us[1]<<","<<us[2]<<","<<us[3]<<"],\"vs_engine_ssm\":";
        compare(f,ssm,load(cd/"ssm")); f<<",\"ref_vs_engine_output\":";compare(f,ref,actual);
        f<<",\"candidate_vs_engine_output\":";compare(f,cand,actual);f<<",\"histories\":";compare(f,n0,n1);
        if(step==2) {
            vec nextwin=load(inputs/("conv-3-"+std::to_string(visit))/"window"), recorded(3*n);
            for(int i=0;i<n;i++)std::copy_n(&nextwin[4*i],3,&recorded[3*i]);
            f<<",\"next_engine_history\":";compare(f,n1,recorded);
        }
        f<<"}\n"<<std::flush;
        if(visit>=2)continue;
        auto ctrl=inputs/("ctrl-"+key);
        controller a(backend,ctrl,false),b(backend,ctrl,true);
        double t0=a.time(backend),t1=b.time(backend),t2=b.time(backend),t3=a.time(backend);
        f<<"{\"block\":\"controller\",\"key\":\""<<key<<"\",\"us_abba\":["<<t0<<","<<t1<<","<<t2<<","<<t3<<"],\"candidate_vs_ref\":";
        compare(f,a.read(),b.read());f<<",\"ref_vs_engine\":";compare(f,a.read(),load(ctrl/"output"));f<<"}\n"<<std::flush;
    }
    ggml_backend_free(backend);return 0;
}
