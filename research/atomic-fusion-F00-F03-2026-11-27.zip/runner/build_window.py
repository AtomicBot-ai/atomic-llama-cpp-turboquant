"""Keep compilation separate from stand timing and restore the registered service."""
import sys
from pathlib import Path
import subprocess
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/"atomic-spec-s00-1127-01"))
from spark_window import exclusive
out=here/sys.argv[1]
out.mkdir(exist_ok=False)
with exclusive(out), (out/"compiler.log").open("w") as f:
    subprocess.run([sys.executable,str(here/"prepare_candidate.py"),*sys.argv[2:]],check=True,stdout=f,stderr=subprocess.STDOUT)
