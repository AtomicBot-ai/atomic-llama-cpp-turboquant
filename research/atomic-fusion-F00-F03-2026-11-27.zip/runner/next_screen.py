"""Compare only numerically admissible extensions on fixed native continuations."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qualify_fusion import arm
from reduce import numeric,timing
from window import exclusive

root=Path(__file__).resolve().parent
reference="both+safe+clipfull+ext"
candidates=[reference+"+"+k for k in ("pack","project","pack+project")]
def run(folder,action,modes):
    dest=root/folder
    dest.mkdir(exist_ok=False)
    with exclusive(dest):
        return [arm(dest,action,i,k) for i,k in enumerate(modes)]

if __name__=="__main__":
    qa=run("extqa01","qa",["frozen+ext"]+candidates)
    accepted=[]
    for name,entry in zip(candidates,qa[1:]):
        n=numeric(qa[0],entry)["primary"]
        repeat=entry["fingerprints"][:65]==entry["fingerprints"][-65:]
        hits=entry["hits_at_graph_build"]
        if n["argmax_changes"]==0 and n["changed_fp"]==0 and repeat and all(hits[k]>0 for k in ("pack","project") if k in name.split("+")):
            accepted.append(name)
    if accepted:
        tests=[reference]+accepted+[reference]
        rows=run("extscreen01","abba",tests)
        values=[timing(row["requests"])["ms_per_update"] for row in rows]
        summary=dict(candidates=accepted,arms=tests,ms_per_update=values)
        (root/"extension-screen.json").write_text(json.dumps(summary))
        print(summary,flush=True)
    else:
        print("No extension matched the reference and activated its new path",flush=True)
