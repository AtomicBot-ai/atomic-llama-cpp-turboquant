// Private Spark capture experiment. The graph and the sum-of-squares reduction stay intact.
static thread_local bool f01_clip_capture = false;

static __global__ void f01_clip_apply(const float * sum, const float * input, float * output,
                                      int width, float threshold) {
    const int row = blockIdx.y;
    const int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (col < width) {
        const float divisor = sqrtf(sum[row]) + 1e-6f;
        const float factor = fminf(fmaxf(threshold / divisor, 0.0f), 1.0f);
        output[row*width + col] = input[row*width + col] * factor;
    }
}

static bool f01_try_clip(ggml_backend_cuda_context * ctx, ggml_cgraph * graph, int start, bool include_sum) {
    const int i = start + (include_sum ? 2 : 0);
    if (include_sum && (!ggml_can_fuse_subgraph(graph,start,
            {GGML_OP_SQR, GGML_OP_SUM_ROWS, GGML_OP_SQRT, GGML_OP_SCALE, GGML_OP_FILL, GGML_OP_DIV,
             GGML_OP_CLAMP, GGML_OP_MUL}, {start+7}) ||
            !ggml_check_edges(graph,start,{{1,0,0},{2,0,1}}))) { return false; }
    if (!ggml_can_fuse_subgraph(graph, i, { GGML_OP_SQRT, GGML_OP_SCALE, GGML_OP_FILL, GGML_OP_DIV,
                                          GGML_OP_CLAMP, GGML_OP_MUL }, { i+5 }) ||
        !ggml_check_edges(graph, i, {{1,0,0}, {2,0,1}, {3,0,2}, {3,1,1}, {4,0,3}, {5,1,4}})) {
        return false;
    }
    auto ** ops = graph->nodes+i;
    const auto * sum = ops[0]->src[0];
    const auto * cur = ops[5]->src[0];
    auto * out = ops[5];
    if (sum->op != GGML_OP_SUM_ROWS || sum->src[0]->op != GGML_OP_SQR ||
        sum->src[0]->src[0] != cur || sum->ne[0] != 1 || ggml_nrows(sum) != ggml_nrows(cur) ||
        !ggml_are_same_shape(cur,out) || (cur->ne[0] != 128 && cur->ne[0] != 16) ||
        cur->ne[2] != 1 || cur->ne[3] != 1 || ggml_get_op_params_f32(ops[1],0) != 1.0f ||
        ggml_get_op_params_f32(ops[1],1) != 1e-6f || ggml_get_op_params_f32(ops[4],0) != 0.0f ||
        ggml_get_op_params_f32(ops[4],1) != 1.0f) {
        return false;
    }
    for (const ggml_tensor * t : {sum,cur,static_cast<const ggml_tensor *>(out)}) {
        if (t->type != GGML_TYPE_F32 || !ggml_is_contiguous(t)) { return false; }
    }
    auto overlaps = [](const ggml_tensor * a, const ggml_tensor * b) {
        const uintptr_t x = reinterpret_cast<uintptr_t>(a->data);
        const uintptr_t y = reinterpret_cast<uintptr_t>(b->data);
        return x < y + ggml_nbytes(b) && y < x + ggml_nbytes(a);
    };
    // One-to-one in-place scaling is safe. Broadcast sums must survive every thread's read.
    if ((!include_sum && overlaps(out,sum)) || (out->data != cur->data && overlaps(out,cur))) { return false; }
    if (include_sum) {
        const int nrows=ggml_nrows(cur);
        const int threads=nrows / ggml_cuda_info().devices[ctx->device].nsm < 2 ? 512 : 32;
        spark_clip_kernel<<<nrows,threads,0,ctx->stream()>>>(static_cast<const float *>(cur->data),
            nullptr,static_cast<float *>(out->data),cur->ne[0],nrows,ggml_get_op_params_f32(ops[2],0));
        if (ggml_cuda_env_flag("ATOMIC_F01_TRACE")) { std::fprintf(stderr,"F01 clipfull %lld\n",(long long)cur->ne[0]); }
        return true;
    }
    f01_clip_apply<<<dim3((cur->ne[0]+127)/128,ggml_nrows(cur)),128,0,ctx->stream()>>>(
        static_cast<const float *>(sum->data),static_cast<const float *>(cur->data),
        static_cast<float *>(out->data),cur->ne[0],ggml_get_op_params_f32(ops[2],0));
    if (ggml_cuda_env_flag("ATOMIC_F01_TRACE")) { std::fprintf(stderr,"F01 clip %lld\n",(long long)cur->ne[0]); }
    return true;
}
