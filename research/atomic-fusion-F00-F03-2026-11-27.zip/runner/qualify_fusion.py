"""Same-binary arms, with effective settings and raw per-request evidence."""
from contextlib import contextmanager
import argparse
import hashlib
from datetime import datetime,timezone
from statistics import median
import json
from pathlib import Path
import re
import runpy
import sys
import subprocess

sys.path.insert(0,str(Path(__file__).resolve().parent))
from window import BASE, FIXTURE, LAB, R08, exclusive, file_hash, server

DATA=json.loads(FIXTURE.read_text())
BENCH=BASE["bench"]
MEASURE=runpy.run_path(str(BASE["OLD"]/"bench.py"))["measure"]

@contextmanager
def gpu_memory(path):
    with path.open("w") as output:
        sampler=subprocess.Popen(["nvidia-smi","-i","0","--query-gpu=memory.used,clocks.sm,power.draw,utilization.gpu",
                                   "--format=csv,noheader,nounits","-lms","300"],stdout=output)
        try:
            yield
        finally:
            sampler.terminate()
            sampler.wait()

def fixed(url,name,count):
    data=DATA[name]
    ids=data["continuation"][:count]
    reply=BASE["rpc"](url,"/completion",prompt=data["prompt"],n_predict=count,temperature=0,n_probs=12,
                    grammar="root ::= "+" ".join(f"<[{t}]>" for t in ids),return_tokens=True,cache_prompt=False)
    assert reply["tokens"]==ids and reply["timings"]["cache_n"]==0
    return [[(x["id"],x["logprob"]) for x in pos["top_logprobs"]] for pos in reply["completion_probabilities"]]


def arm(out,action,index,mode):
    variant, *options = mode.split("+")
    filters = {"safe":"safe", "static":"static", "dyn":"dynamic", "ffn":"ffn_post_conv",
               "post":"attn_post_conv","k":"attn_k_conv","v":"attn_v_conv"}
    cmd,env,_=BASE["profile"]("final-pool" if variant=="frozen" else "final-both")
    diagnostic=action in ("qa","localize","state","partial","probe","rollback")
    if action in ("dflash","probe","rollback"):
        spec=json.loads((BASE["OLD"]/"resident-dflash2.json").read_text())
        cmd=spec["cmd"]
        env={**spec["env"],**env}
    cmd[0]=str(LAB/"build/bin"/("f01-raw-server.exe" if diagnostic else "f01-llama-server.exe"))
    if "ext" in options: cmd[0]=cmd[0].replace("f01-","f06-")
    env["ATOMIC_F01_CONV"]="1" if variant in ("conv","both") else "0"
    env["ATOMIC_F01_PAIR"]="1" if variant in ("pair","both") else "0"
    if variant in ("conv","both"): env["ATOMIC_F01_SELECT"]="all"
    for flag in options:
        if flag in ("clip","clipfull"):
            env["ATOMIC_F01_CLIP"]="1"
            env["ATOMIC_F01_CLIP_FULL"]=str(int(flag=="clipfull"))
        elif flag=="ext": pass
        elif flag=="pack": env["ATOMIC_F01_DEPTH_PACK"]="1"
        elif flag=="project": env["ATOMIC_F01_PROJECT"]="1"
        elif flag == "cuts": env["ATOMIC_F01_OLD_CUTS"]="1"
        elif flag in filters: env["ATOMIC_F01_SELECT"]=filters[flag]
        elif flag.startswith("blk."): env["ATOMIC_F01_SELECT"]=flag
        else: raise ValueError(flag)
    if diagnostic: env["ATOMIC_F01_TRACE"]="1"
    else: env.pop("GGML_CUDA_GRAPH_DEBUG",None)
    if action=="partial": cmd[cmd.index("--engine-budget-mib")+1]="16484"
    cfg=dict(cmd=cmd,env=env,sha256=file_hash(cmd[0]),fixture_sha256=file_hash(FIXTURE))
    stem=f"{index:02}-{mode}"
    log=out/(stem+".log")
    result=dict(profile=cfg,requests=[],started_utc=datetime.now(timezone.utc).isoformat())
    memory=out/(stem+".memory")
    with server(BENCH,cfg,log) as url, gpu_memory(memory):
        if action=="localize":
            result["requests"].append(dict(case="lunch",top=fixed(url,"lunch",24)))
        elif action=="qa":
            for name in ("lunch","sky","python","briefing","lunch"):
                result["requests"].append(dict(case=name,top=fixed(url,name,65)))
        elif action=="partial":
            result["requests"].append(dict(case="lunch",top=fixed(url,"lunch",8)))
        elif action=="rollback":
            def greedy(case,cap):
                reply=BASE["rpc"](url,"/completion",prompt=DATA[case]["prompt"],seed=42,n_predict=cap,temperature=0,
                                  cache_prompt=False,return_tokens=True)
                assert reply["timings"]["cache_n"]==0
                return dict(case=case,ids=reply["tokens"],stop=reply["stop_type"],timings=reply["timings"])
            check=[greedy("lunch",32),greedy("sky",1024),greedy("lunch",32),greedy("python",2),greedy("lunch",32)]
            assert check[1]["stop"]=="eos" and check[3]["stop"]=="limit"
            assert check[0]["ids"]==check[2]["ids"]==check[4]["ids"]
            result["rollback"]=check
        elif action=="state":
            for phase in ("fresh","eos","limit"):
                if phase!="fresh":
                    name,n=("sky",1024) if phase=="eos" else ("python",2)
                    x=BASE["rpc"](url,"/completion",prompt=DATA[name]["prompt"],n_predict=n,temperature=0,cache_prompt=False,return_tokens=True)
                    assert x["stop_type"]==phase
                result["requests"].append(dict(case=phase,top=fixed(url,"lunch",16)))
        elif action in ("screen","abba"):
            for warm in (True,False):
                for name in ("sky","briefing"):
                    d=DATA[name]
                    row=BASE["record_request"](url,name,d["prompt"],d["continuation"],constant=action=="abba")
                    result["requests"].append(dict(warmup=warm,**row))
        elif action in ("serve","dflash","probe"):
            cases=BASE["cases"] if action=="serve" else ("lunch","sky")
            main_cap=1536 if action=="serve" else 192
            jobs=[(n,s,main_cap) for s in (42,43) for n in cases]
            if action=="probe": jobs=[("lunch",42,32)]
            for name,seed,cap in [("lunch",44,128)]+jobs:
                r=MEASURE(url,dict(messages=BASE["cases"][name],seed=seed,temperature=1,max_tokens=cap,stream=True,cache_prompt=False))
                result["requests"].append(dict(case=name,seed=seed,warmup=seed==44,cap=cap,**r))
        result["metrics"]=BENCH["engine_metrics"](url)
        result["gpu"]=BASE["telemetry"]()
    samples=[]
    for line in memory.read_text().splitlines():
        fields=[x.strip() for x in line.split(",")]
        if len(fields)==4 and fields[0].isdigit():
            samples.append((int(fields[0]),int(fields[1]),float(fields[2]),int(fields[3])))
    busy=[r for r in samples if r[3]>=75]
    result["finished_utc"]=datetime.now(timezone.utc).isoformat()
    result["device_memory_mib"]=dict(samples=len(samples),interval_ms=300,peak=max((r[0] for r in samples),default=None))
    if busy:
        result["busy_device"]=dict(samples=len(busy),frequency_mhz=[min(r[1] for r in busy),median(r[1] for r in busy),max(r[1] for r in busy)],
                                   power_w=[min(r[2] for r in busy),median(r[2] for r in busy),max(r[2] for r in busy)])
    text=log.read_text(errors="replace")
    result["hits_at_graph_build"]={k:len(re.findall(r"^F01 "+k+" ",text,re.M)) for k in ("pair","conv","clip","clipfull","pack","project")}
    result["fingerprints"]=re.findall(r"R08_LOGITS 200058 ([0-9a-f]{16})",text)
    if action=="dflash":
        pat=r"draft acceptance = .*?\(\s*(\d+) accepted /\s*(\d+) generated\), mean len =\s+([.\d]+)"
        summary=re.findall(pat,text)
        assert len(summary)==len(result["requests"]), (len(summary),len(result["requests"]))
        for (acc,total,mean),row in zip(summary,result["requests"]):
            a,t=int(acc),int(total)
            assert (a,t)==(row["timings"]["draft_n_accepted"],row["timings"]["draft_n"])
            feasible=[n for n in range(1,t+1) if abs(1+a/n-float(mean))<=0.00500001]
            assert feasible
            row["round_bounds"]=[min(feasible),max(feasible)]
    expected={"qa":325,"partial":8,"state":48}.get(action)
    if action=="partial":
        metrics=result["metrics"]
        assert metrics["budget_high_water_bytes"]<=metrics["budget_applied_bytes"]==16484*2**20
        assert metrics["expert_logical_read_bytes"]>0 and not any(result["hits_at_graph_build"].values())
    if expected: assert len(result["fingerprints"])==expected
    (out/(stem+".json")).write_text(json.dumps(result))
    print(stem,action,result["hits_at_graph_build"],flush=True)
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("directory",type=Path)
    p.add_argument("action",choices=["qa","localize","partial","state","screen","abba","serve","dflash","probe","rollback"])
    p.add_argument("modes",nargs="+")
    a=p.parse_args()
    a.directory=a.directory.resolve()
    a.directory.mkdir(exist_ok=False)
    with exclusive(a.directory):
        for i,mode in enumerate(a.modes): arm(a.directory,a.action,i,mode)
