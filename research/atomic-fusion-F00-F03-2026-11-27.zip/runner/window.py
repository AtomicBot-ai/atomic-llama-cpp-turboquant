"""Run research arms sequentially inside the registered Spark service window."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import runpy
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path.home()/"inkling-spark"
sys.path.insert(0,str(ROOT/"atomic-spec-s00-1127-01"))
from spark_window import exclusive, LAB
from capture_s00 import server, file_hash, TARGET
R08 = ROOT/"blackwell-recovery-1127"
BASE = runpy.run_path(str(R08/"r08.py"))
FIXTURE = R08/"fixture.json"


def baseline(out):
    data=json.loads(FIXTURE.read_text())
    cmd,flags,sha=BASE["profile"]("final-pool")
    assert file_hash(cmd[0])==sha and file_hash(cmd[cmd.index("-m")+1])==TARGET
    config=dict(cmd=cmd,env=flags,sha256=sha)
    with server(BASE["bench"],config,out/"control.log") as url:
        rows=[]
        for n in ("lunch","sky","briefing","sky","briefing","sky","briefing"):
            row=BASE["record_request"](url,n,data[n]["prompt"],None,constant=True)
            rows.append(row)
        metrics=BASE["bench"]["engine_metrics"](url)
    (out/"control.json").write_text(json.dumps(dict(profile=config,model_sha256=TARGET,fixture_sha256=file_hash(FIXTURE),
                    cases=rows,metrics=metrics,warmup_rows=3)))


def main():
    p=argparse.ArgumentParser()
    p.add_argument("out",type=Path)
    p.add_argument("action",choices=["baseline","capture","replay","first"])
    p.add_argument("--inputs",type=Path, default=HERE/"capture")
    a=p.parse_args()
    out=a.out.resolve()
    out.mkdir(exist_ok=False)
    with exclusive(out):
        if a.action in ("baseline","first"):
            baseline(out)
        if a.action in ("capture","first"):
            subprocess.run([sys.executable,str(HERE/"build.py"),"probe"],check=True)
            cmd,flags,_=BASE["profile"]("final-both")
            ids=json.loads(FIXTURE.read_text())["lunch"]
            env={**os.environ,**flags}
            cuda=Path(os.environ["ProgramFiles"])/"NVIDIA GPU Computing Toolkit/CUDA/v13.4/bin/arm64"
            env["PATH"]=str(cuda)+os.pathsep+env["PATH"]
            subprocess.run([str(HERE/"probe.exe"),cmd[cmd.index("-m")+1],str(out),
                            *map(str,ids["prompt"]+ids["continuation"][:2])],env=env,check=True)
        elif a.action=="replay":
            subprocess.run([sys.executable,str(HERE/"build.py"),"replay"],check=True)
            subprocess.run([str(HERE/"replay.exe"),str(a.inputs.resolve()),str(out)],check=True)


if __name__=="__main__":
    main()
