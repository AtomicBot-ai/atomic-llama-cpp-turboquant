"""Summarize fixed-input runs and bounded device traces. No server required."""
import collections
import hashlib
import json
import math
from pathlib import Path
from statistics import median

here = Path(__file__).resolve().parent
def records(path):
    return [json.loads(s) for s in path.read_text().splitlines()]
def q(samples,p):
    return sorted(samples)[math.ceil(p*len(samples))-1]
def measurements(path):
    raw=records(path)
    results={}
    all_steps=[]
    all_ms=0
    n=0
    for row in raw:
        if row.get("warmup") is not False or "arrival_ms" not in row: continue
        ticks=row["arrival_ms"]
        steps=[b-a for a,b in zip(ticks,ticks[1:])]
        timing=row["timings"]
        assert len(steps)==64 and timing["predicted_n"]==65 and timing["cache_n"]==0
        assert abs(timing["predicted_per_token_ms"]-timing["predicted_ms"]/64)<1e-5
        results[row["case"]]=dict(prompt_ids=timing["prompt_n"],updates=len(steps),decode_ms=timing["predicted_ms"],ms_per_step=timing["predicted_per_token_ms"],ttft_ms=row["ttft_ms"],prefill_ms=timing["prompt_ms"],total_ms=row["wall_ms"],client_step_p50_ms=median(steps),client_step_p90_ms=q(steps,.9))
        all_steps+=steps
        all_ms+=timing["predicted_ms"]
        n+=len(steps)
    if len(results)!=4: return None
    return dict(cases=results,committed_updates=n,decode_s=all_ms/1000,rate=n*1000/all_ms,ms_per_step=all_ms/n,
                ttft_med=median(v["ttft_ms"] for v in results.values()),wall_ms=sum(v["total_ms"] for v in results.values()),
                client_step_p50_ms=median(all_steps),client_step_p90_ms=q(all_steps,.9))
def kernel_family(s):
    if "mul_mat_vec_q" in s and "ggml_type40" in s: return "NVFP4 expert MMVQ"
    if "mul_mat_vec_q" in s: return "other quantized MMVQ"
    if "mmq" in s and "quantize" not in s: return "MMQ"
    if "mul_mat_vec_f" in s or "gemm" in s.lower(): return "float matvec / GEMM"
    if "loop_ctrl" in s or "control" in s: return "loop control"
    if "depth_mix" in s or "spark_depth" in s: return "depth mix"
    if "concat" in s: return "concat"
    if "flash_attn" in s: return "flash attention"
    if "quant" in s: return "quantization"
    if "clip" in s: return "clip"
    if "conv" in s: return "convolution"
    if "norm" in s: return "normalization"
    if "cpy" in s: return "copy kernel"
    if "bcast" in s or "scale" in s or "unary" in s: return "elementwise"
    return "other"
def aggregate(rows):
    events=sorted((int(r[1]),int(r[2]),r) for r in rows if r[0]=="K")
    counts=collections.Counter(); sums=collections.Counter(); ids=collections.Counter(); api=collections.Counter(); api_ms=collections.Counter(); api_counts=collections.Counter()
    end=0; union=0
    for s,e,r in events:
        if e>max(end,s): union+=e-max(end,s)
        end=max(e,end)
        f=kernel_family(r[-1]);counts[f]+=1;sums[f]+=(e-s)/1e6;ids[r[4]]+=1
    for r in rows:
        if r[0]=="A":
            api_ms[r[-1]]+=(int(r[2])-int(r[1]))/1e6
            api_counts[r[-1]]+=1
        if r[0]=="A" and any(x in r[-1] for x in ("ynchronize","raphLaunch","raphInstantiate","eginCapture")): api[r[-1]]+=1
    return dict(kernel_count=len(events),kernel_envelope_ms=(end-events[0][0])/1e6,busy_union_ms=union/1e6,
                kernels={f:dict(count=n,sum_ms=sums[f]) for f,n in counts.items()},graph_ids=dict(ids),api_calls=dict(api),
                memcpy_count=sum(r[0]=="M" for r in rows),host_api={k:dict(count=v,sum_ms=api_ms[k]) for k,v in api_counts.items()})
def trace(path):
    rows=[l.rstrip().split("\t") for l in path.open()]
    assert not any(r[0]=="DROP" for r in rows)
    capture=next(r["capture"] for r in records(path.with_suffix(".jsonl")) if "capture" in r)
    copies=sorted(int(r[2]) for r in rows if r[0]=="M" and r[6:]==["800232","2"])
    assert len(copies)==len(capture["ids"])==7
    stamp,qpc,freq = map(int,next(r for r in rows if r[0]=="T")[1:])
    offset=stamp-qpc*1e9/freq
    bounds=[int(capture["begin_ns"]+offset)]+copies
    parts=[]
    for i,(a,b) in enumerate(zip(bounds,bounds[1:])):
        selected=[r for r in rows if r[0] in ("K","M","A") and a<=int(r[1])<int(r[2])<=b]
        p=aggregate(selected)
        p.update(phase="prefill" if i==0 else f"decode-{i}",wall_ms=(b-a)/1e6)
        p["wall_outside_kernel_envelope_ms"]=p["wall_ms"]-p["kernel_envelope_ms"]
        parts.append(p)
    syms=collections.defaultdict(lambda:[0,0])
    for r in rows:
        if r[0]=="K" and copies[2]<=int(r[1])<int(r[2])<=copies[5]:
            group=syms[(r[-1],r[6])]
            group[0]+=1
            group[1]+=(int(r[2])-int(r[1]))/1e6
    return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),dropped=0,logit_copy_bytes=800232,segments=parts,
                interior_symbols=[dict(symbol=s,grid=g,count_3=n,sum_ms_3=ms) for (s,g),(n,ms) in sorted(syms.items(),key=lambda kv:-kv[1][1])])
def main():
    perf={}
    for p in sorted(here.glob("*.jsonl")):
        result=measurements(p)
        if result: perf[p.stem]=result
    data=dict(sha256_fixture=hashlib.sha256((here/"fixture.json").read_bytes()).hexdigest(),profiles=perf,
              traces={p.stem:trace(p) for p in sorted(here.glob("*.trace.tsv"))})
    (here/"R08-parity.json").write_text(json.dumps(data,indent=1)+"\n")
if __name__=="__main__": main()
