"""Reduce private Spark logs to portable evidence without copying model activations."""
from collections import Counter
from pathlib import Path
import hashlib
import json
from statistics import median
import sys

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read_data(path):
    return json.loads(path.read_text())

def numeric(control,candidate):
    ref=[p for r in control["requests"] for p in r["top"]]
    test=[p for r in candidate["requests"] for p in r["top"]]
    assert len(ref)==len(test)
    def section(indices):
        a,b=control["fingerprints"],candidate["fingerprints"]
        wrong=[i for i in indices if ref[i][0][0]!=test[i][0][0]]
        different=[i for i in indices if a[i]!=b[i]]
        delta=[abs(score-dict(test[i])[token]) for i in indices for token,score in ref[i] if token in dict(test[i])]
        return dict(positions=len(indices),argmax_changes=len(wrong),first_argmax=wrong[:1],
                    first_choice_pair=[ref[wrong[0]][0],test[wrong[0]][0]] if wrong else None,
                    changed_fp=len(different),first_fp=different[:1],
                    max_shared_top12_logprob_delta=max(delta,default=None))
    return dict(primary=section(range(min(len(test),260))),tail=section(range(260,len(test))) if len(test)>260 else None)

def timing(rows):
    data=[r for r in rows if r.get("warmup") is False]
    ms=sum(r["timings"]["predicted_ms"] for r in data)
    count=sum(r["timings"]["predicted_n"]-1 for r in data)
    def seconds(r,k):
        return r.get(k+"_ms",0)/1000 if k+"_ms" in r else r[k+"_s"]
    return dict(updates=count,decode_ms=ms,ms_per_update=ms/count,tps=count*1000/ms,
                median_ttft_ms=median(seconds(r,"ttft")*1000 for r in data),wall_s=sum(seconds(r,"wall") for r in data),
                finish=dict(Counter(r.get("finish",r.get("stop")) for r in data)))

def collect(root):
    docs={}
    for folder in sorted(root.iterdir()):
        if not folder.is_dir():continue
        paths=sorted(folder.glob("[0-9][0-9]-*.json"))
        if not paths: continue
        control=read_data(paths[0])
        out={}
        for path in paths:
            row=read_data(path)
            values=dict(sha256=sha(path),profile=row["profile"],gpu=row["gpu"],metrics=row["metrics"],graph_build_hits=row["hits_at_graph_build"])
            values.update({k:row[k] for k in ("started_utc","finished_utc","busy_device") if k in row})
            values["device_memory_mib"]=row.get("device_memory_mib")
            if row["requests"] and "top" in row["requests"][0]:
                values.update(numerics=numeric(control,row),fingerprints=row["fingerprints"])
                if len(row["requests"])==5:
                    fp=row["fingerprints"]
                    ref=row["requests"][0]["top"]
                    tail=row["requests"][-1]["top"]
                    values["repeat_same_arm"]={"identical_logits":sum(a==b for a,b in zip(fp[:65],fp[-65:])),
                                               "argmax_changes":sum(x[0][0]!=y[0][0] for x,y in zip(ref,tail))}
                if len(row["requests"])==3:
                    fp=row["fingerprints"]
                    values["repeat_after_eos_limit"]=[sum(a==b for a,b in zip(fp[:16],fp[k:k+16])) for k in (16,32)]
            elif "rollback" in row:
                values["rollback"]=row["rollback"]
            else:
                values["timing"]=timing(row["requests"])
                values["requests"]=[{k:v for k,v in r.items() if k not in ("ids","arrival_ms","answer")} for r in row["requests"]]
                for dst,src in zip(values["requests"],row["requests"]):
                    if "arrival_ms" in src and not src.get("warmup"):
                        arrivals=src["arrival_ms"]
                        dst["interarrival_ms"]=[round(b-a,3) for a,b in zip(arrivals,arrivals[1:])]
                        dst["ids_sha256_le_i32"]=hashlib.sha256(b"".join(x.to_bytes(4,"little",signed=True) for x in src["ids"])).hexdigest()
                    if "answer" in src:dst["answer_sha256"]=hashlib.sha256(src["answer"].encode()).hexdigest()
            out[path.stem]=values
        if (folder/"restoration.json").exists():out["restored"]=read_data(folder/"restoration.json")
        docs[folder.name]=out
    return docs

if __name__=="__main__":
    print(json.dumps(collect(Path(sys.argv[1])),indent=1))
