"""Collect under one denominator. Interrupted measurements retain their raw arm data."""
from pathlib import Path
import argparse
import hashlib
import json
from collections import Counter
from statistics import median

HERE=Path(__file__).resolve().parent
def read(name):
    return json.loads((HERE/name).read_text())

def rows(arm):
    return [r for r in arm["requests"] if not r["warmup"]]

def pooled(arms,case=None):
    a=[r for arm in arms for r in rows(arm) if not case or r["case"]==case]
    count=sum(r["timings"]["predicted_n"]-1 for r in a)
    ms=sum(r["timings"]["predicted_ms"] for r in a)
    delta=[v for r in a for v in r.get("interarrival_ms",[])]
    clocks=[r.get("ttft_ms",1000*r.get("ttft_s",0)) for r in a]
    power=[v["gpu"].splitlines()[0] for v in arms]
    peaks=[v.get("device_memory_mib",{}).get("peak") for v in arms if v.get("device_memory_mib")]
    out=dict(updates=count,decode_ms=ms,ms_per_update=ms/count,updates_s=count*1000/ms,
             ttft_median_ms=median(clocks),ttft_range_ms=[min(clocks),max(clocks)],
             wall_s=sum(r.get("wall_ms",1000*r.get("wall_s",0)) for r in a)/1000,
             finish=dict(Counter(r.get("finish",r.get("stop")) for r in a)),
             ledger_peak_mib=max(v["metrics"]["budget_high_water_bytes"] for v in arms)/2**20,
             sampled_device_peak_mib=max((n for n in peaks if n is not None),default=None),telemetry=power)
    if delta:out["median_interarrival_ms"]=median(delta)
    if all("round_bounds" in r for r in a):
        lo,hi=map(sum,zip(*(r["round_bounds"] for r in a)))
        out.update(verify_rounds=[lo,hi],ms_per_round=[ms/hi,ms/lo],updates_per_round=[count/hi,count/lo],
                   proposals=sum(r["timings"]["draft_n"] for r in a),accepted=sum(r["timings"]["draft_n_accepted"] for r in a))
    return out

def compare(a,b):
    return dict(gain_percent=(a["ms_per_update"]/b["ms_per_update"]-1)*100,
                saved_ms=a["ms_per_update"]-b["ms_per_update"])

def block(entries):
    result={}
    for name,case in (("both",None),("sky","sky"),("briefing","briefing")):
        ref=pooled([entries[0],entries[3]],case)
        candidate=pooled(entries[1:3],case)
        spread=[abs(pooled([entries[x]],case)["ms_per_update"]-pooled([entries[y]],case)["ms_per_update"]) for x,y in [(0,3),(1,2)]]
        result[name]=dict(reference=ref,candidate=candidate,within_arm_ranges_ms=spread,**compare(ref,candidate))
    return result

def timed_arms(folder):
    return [v for _,v in sorted(folder.items()) if "timing" in v]

def arm_groups(folder):
    groups={}
    for arm,data in folder.items():
        if "timing" in data:groups.setdefault(arm.split("-",1)[1],[]).append(data)
    return groups

def summarize(raw):
    out={}
    if all(n in raw for n in ("abba01","abba02","abba03")):
        first,next_,last=(timed_arms(raw[n]) for n in ("abba01","abba02","abba03"))
        if len(first)==6 and len(next_)==6 and len(last)==4:
            out["fixed_abba"]=[block(first[:4]),block(next_[2:]),block(last)]
            out["power_transition_split_abba"]=block(first[4:]+next_[:2])
    for k in raw:
        if k.startswith(("abba_final","abba_depth")) and len(timed_arms(raw[k]))==12:
            entries=timed_arms(raw[k]);out[k]=[block(entries[i:i+4]) for i in (0,4,8)]
            combined={}
            for case in (None,"sky","briefing"):
                a,b=[pooled([r for i,r in enumerate(entries) if (i%4 in (1,2))==candidate],case) for candidate in (False,True)]
                combined[case or "both"]=dict(reference=a,candidate=b,**compare(a,b))
            out[k+"_pooled"]=combined
        if k.startswith(("serving","df01","df_final")):
            groups=arm_groups(raw[k])
            out[k]={name:pooled(arms) for name,arms in groups.items()}
            for name,arms in groups.items():
                out[k][name]["by_prompt"]={case:pooled(arms,case) for case in sorted({r["case"] for arm in arms for r in rows(arm)})}
            if len(groups)>1:
                key=next(iter(groups)); ref=rows(groups[key][0])
                for name,arms in list(groups.items())[1:]:
                    comp=rows(arms[0]); assert [(r["case"],r["seed"]) for r in ref]==[(r["case"],r["seed"]) for r in comp]
                    out[k][name].update(compare(out[k][key],out[k][name]))
                    out[k][name]["same_visible_answers"]=sum(x.get("answer_sha256")==y.get("answer_sha256") for x,y in zip(ref,comp))
                    out[k][name]["same_reasoning"]=sum(x.get("reasoning_sha256")==y.get("reasoning_sha256") for x,y in zip(ref,comp))
    return out

def compact(raw):
    profiles={}
    series={}
    arms={}
    for folder,items in raw.items():
        table={}
        for label,arm in items.items():
            if "profile" not in arm:
                table[label]=arm
                continue
            value=dict(arm)
            profile=value.pop("profile")
            digest=hashlib.sha256(json.dumps(profile,sort_keys=True).encode()).hexdigest()[:16]
            profiles[digest]=profile
            value["profile_id"]=digest
            if "fingerprints" in value:
                fps=value.pop("fingerprints")
                key=hashlib.sha256("".join(fps).encode("ascii")).hexdigest()
                series[key]=fps
                value["fingerprint_series_sha256"]=key
            table[label]=value
        arms[folder]=table
    return dict(profiles=profiles,full_vocab_fingerprint_series=series,runs=arms)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--final",action="store_true")
    args=parser.parse_args()
    raw=read("F02-results.json")
    result=summarize(raw)
    if args.final:
        with (HERE/"F01-replay.jsonl").open() as f:
            replay=[json.loads(line) for line in f]
        evidence=dict(commit="6115c7090feebdacd90f737cf02de9a45734e6b8",reference=read("F00-control.json"),
                      trace_attribution=read("F00-trace.json"),block_replays=replay,provenance=read("provenance.json"),
                      measured=result,**compact(raw))
        for name in ("trace_winner","trace_next"):
            if (HERE/(name+".json")).exists():evidence[name]=read(name+".json")
        if (HERE/"power01.jsonl").is_file():
            evidence["power_timeline"]=[json.loads(line) for line in (HERE/"power01.jsonl").read_text().splitlines()]
        evidence["reproduction"]=read("commands.json")
        evidence["artifact_sha256"]={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest()
                                     for p in [HERE/"FUSION-F01.patch",*sorted((HERE/"reference").glob("*"))] if p.is_file()}
        (HERE/"FUSION-F01.json").write_text(json.dumps(evidence,separators=(",",":"),allow_nan=False)+"\n")
    else:
        print(json.dumps(result,indent=1))
