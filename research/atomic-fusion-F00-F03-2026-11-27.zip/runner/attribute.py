"""Attribute the same interior update in R08 by GPU symbol, grid and neighboring operations."""
import json
from pathlib import Path
import sys


def step(path):
    rows=[line.rstrip().split("\t") for line in path.open()]
    assert not any(r[0]=="DROP" for r in rows)
    copies=sorted(int(r[2]) for r in rows if r[0]=="M" and r[6:]==["800232","2"])
    assert len(copies)==7
    return sorted([r for r in rows if r[0]=="K" and copies[2]<=int(r[1])<int(r[2])<=copies[3]],key=lambda r:int(r[1]))


def analyze(directory,tag):
    e=step(directory/(tag+".trace.tsv"))
    groups={"controller":set(),"conv":set(),"state_window":set(),"downstream_residual":set(),"depth_mix":set()}
    ctrl,conv,window,res,depth=groups.values()
    for i,row in enumerate(e):
        sym=row[-1]
        if tag=="stock":
            if "loop_ctrl_" in sym: ctrl.add(i)
            if "short_conv_f32" in sym: conv.add(i)
        elif "mul_mat_vec_f" in sym and row[6]=="64,1,1":
            assert "concat_cont" in e[i-1][-1] and "rms_norm" in e[i-2][-1]
            ctrl.update([i-2,i-1,i])
            if "rms_norm" in e[i-3][-1]: ctrl.add(i-3)
            if tag=="atomic":
                assert "mul_mat_vec_f" in e[i+1][-1] and "mul_mat_vec_f" in e[i+5][-1]
                assert all("op_" in e[i+x][-1] for x in (2,3,4,6,7,8))
                ctrl.update(range(i+1,i+9))
            else:
                assert all("mul_mat_vec_f" in e[i+x][-1] for x in (1,2))
                assert "spark_control" in e[i+3][-1]
                ctrl.update(range(i+1,i+4))
        if "concat_cont" in sym and i+1<len(e) and (row[6],e[i+1][6]) in (("16,1,1","48,1,1"),("36,1,1","108,1,1")) and "cpy_scalar" in e[i+1][-1]:
            window.update((i,i+1))
        if "ssm_conv_f32" in sym:
            conv.add(i)
            j=i+1
            while "scale_f32" not in e[j][-1]:
                assert j-i<19
                if not any(s in e[j][-1] for s in ("quantize","mul_mat_vec_q")): conv.add(j)
                j+=1
            conv.add(j)
            if "op_add" in e[j+1][-1]: res.add(j+1)
        if "spark_conv_kernel" in sym:
            conv.add(i)
            if "op_add" in e[i+1][-1]: res.add(i+1)
        if tag=="atomic" and "soft_max_f32" in sym:
            # RMS, transpose copy, repeated query, score and weighted sum. Include
            # only the dimension-one stack concatenations of this mix.
            j=i-1
            while "rms_norm" not in e[j][-1]: j-=1
            assert i-j in (4,5) and "cpy_scalar_transpose" in e[j+1][-1]
            while "concat_cont" in e[j-1][-1] and "Li1" in e[j-1][-1]: j-=1
            end=i+2+int("splitKreduce" in e[i+2][-1])
            depth.update(range(j,end))
        if "spark_depth" in sym or "depth_mix" in sym: depth.add(i)
    assert len(set.union(*groups.values()))==sum(map(len,groups.values()))
    assert len(window)==(0 if tag=="stock" else 384)
    return {k:dict(count=len(ids),sum_ms=sum(int(e[i][2])-int(e[i][1]) for i in ids)/1e6) for k,ids in groups.items()}

if __name__=="__main__":
    print(json.dumps({t:analyze(Path(sys.argv[1]),t) for t in ("atomic","fusion2","stock")},indent=2))
