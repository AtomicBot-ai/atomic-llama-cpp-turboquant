"""Link private tools against the already qualified ARM64 R08 libraries."""
from pathlib import Path
import subprocess
import sys

here=Path(__file__).resolve().parent
lab=here.parent/"indexed-fa-1127-ab01/baseline"
build=lab/"build"
src=lab/"src"
arm=sys.argv[1]
assert arm in ("probe","replay")
libraries=next(l.strip().split(" = ",1)[1] for l in (build/"r08-final.ninja").read_text().splitlines()
               if l.strip().startswith("LINK_LIBRARIES =") and "server-context.lib" in l)
setup=(lab/"build.cmd").read_text().split("cmake -S")[0].replace('cd /d "%~dp0"',f'cd /d "{lab}"')
includes=f'/I"{src}/include" /I"{src}/ggml/include" /I"%CUDA_PATH%/include"'
command=f'cl /nologo /EHsc /MD /std:c++17 /O2 {includes} "{here}/{arm}.cpp" /Fo"{here}/{arm}.obj" /Fe"{here}/{arm}.exe" '
if arm=="replay":
    setup+=f'\n"%CUDA_PATH%/bin/nvcc.exe" -arch=sm_121 -O3 -Xcompiler /MD -c "{here}/conv.cu" -o "{here}/conv.obj"\nif errorlevel 1 exit /b 1\n'
    command+=f'"{here}/conv.obj" '
script=here/("compile-"+arm+".cmd")
script.write_text(setup+f'\ncd /d "{build}"\n'+command+'/link '+libraries+'\nexit /b %errorlevel%\n')
subprocess.run(["cmd","/c",str(script)],check=True)
