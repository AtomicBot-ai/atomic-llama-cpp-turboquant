"""Read GPU clocks/power during already-running work without altering the device state."""
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
out=root/sys.argv[1]
deadline=time.monotonic()+int(sys.argv[2])
with out.open("x") as stream:
    while time.monotonic()<deadline:
        result=subprocess.run(["nvidia-smi","-i","0","--query-gpu=clocks.sm,power.draw,utilization.gpu",
                               "--format=csv,noheader,nounits"],capture_output=True,text=True,check=True)
        mhz,watts,pct=next(csv.reader(result.stdout.splitlines(),skipinitialspace=True))
        print(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),mhz=int(mhz),watts=float(watts),
                              utilization=int(pct))),file=stream,flush=True)
        time.sleep(10)
