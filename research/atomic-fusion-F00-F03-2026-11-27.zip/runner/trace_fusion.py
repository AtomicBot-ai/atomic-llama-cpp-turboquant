"""Trace one warmed fixed-ID step, using the frozen R08 CUPTI injector and clock mapping."""
import json
import os
from pathlib import Path
import runpy
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from attribute import step
from window import BASE, FIXTURE, HERE, LAB, R08, exclusive, server

def wait(path):
    until=time.monotonic()+35
    while not path.exists():
        if time.monotonic()>until: raise RuntimeError(str(path))
        time.sleep(.05)

def capture(path,mode):
    name,*options=mode.split("+")
    cmd,env,_=BASE["profile"]("final-pool" if name=="frozen" else "final-both")
    cmd[0]=str(LAB/"build/bin/f01-llama-server.exe")
    if "ext" in options: cmd[0]=cmd[0].replace("f01-","f06-")
    env["ATOMIC_F01_PROJECT"]=str(int("project" in options))
    env["ATOMIC_F01_DEPTH_PACK"]=str(int("pack" in options))
    env.update(ATOMIC_F01_PAIR=str(int(name in ("pair","both"))),ATOMIC_F01_CONV=str(int(name in ("conv","both"))),
               ATOMIC_F01_SELECT="safe",ATOMIC_F01_CLIP=str(int(bool({"clip","clipfull"} & set(options)))), ATOMIC_F01_CLIP_FULL=str(int("clipfull" in options)),
               CUDA_INJECTION64_PATH=str(R08/"r08-activity.dll"),R08_ACTIVITY=str(path))
    root=BASE["ROOT"]
    sdk=next((root/"results/spark-kernel-profile-v1").glob("cuda_cupti-*-archive"))
    if path.with_suffix(".done").is_file() and path.with_suffix(".jsonl").is_file():
        return summarize(path,env)
    previous=os.environ["PATH"]
    os.environ["PATH"]=str(sdk/"lib/arm64")+os.pathsep+previous
    fixture=json.loads(FIXTURE.read_text())["lunch"]
    try:
        with server(BASE["bench"],dict(cmd=cmd,env=env),path.with_suffix(".log")) as url:
            def request(count):
                ids=fixture["continuation"][:count]
                start=time.perf_counter_ns()
                v=BASE["rpc"](url,"/completion",prompt=fixture["prompt"],n_predict=count,temperature=0,
                              cache_prompt=False,return_tokens=True,grammar="root ::= "+" ".join(f"<[{x}]>" for x in ids))
                assert v["tokens"]==ids and v["timings"]["cache_n"]==0
                return dict(ids=ids,begin_ns=start,timing=v["timings"])
            request(8)
            path.with_suffix(".start").touch()
            wait(path.with_suffix(".ready"))
            result=request(7)
            path.with_suffix(".stop").touch()
            wait(path.with_suffix(".done"))
    finally:
        os.environ["PATH"]=previous
    path.with_suffix(".jsonl").write_text(json.dumps(dict(capture=result))+"\n")
    return summarize(path,env)

def summarize(path,env):
    tsv=path.with_suffix(".tsv")
    data=runpy.run_path(str(HERE/"analyze.py"))["trace"](tsv)
    active={}
    for row in step(tsv):
        for key in ("f01_pack_rms","f01_project_exact","f01_short_conv","f01_clip_apply","spark_clip_kernel","spark_control_kernel","spark_mask_kernel"):
            if key in row[-1]:
                counter=active.setdefault(key,dict(count=0,sum_ms=0))
                counter["count"]+=1
                counter["sum_ms"]+=(int(row[2])-int(row[1]))/1e6
    return dict(sha256=data["sha256"],segments=data["segments"][2:6],custom_decode3=active,flags=env)

if __name__=="__main__":
    out=Path(sys.argv[1]).resolve()
    if sys.argv[2]=="--read":
        result=summarize(out/sys.argv[3],{})
        print(result["sha256"],result["segments"][1]["kernel_count"])
        sys.exit(0)
    out.mkdir(exist_ok=True)
    with exclusive(out):
        result={m:capture(out/m,m) for m in sys.argv[2:]}
    (out/"summary.json").write_text(json.dumps(result))
