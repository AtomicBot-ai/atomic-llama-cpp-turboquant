"""Continue a named private schedule without tying the experiment to an SSH connection."""
import json
from pathlib import Path
import subprocess
import sys
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qualify_fusion import arm
from window import exclusive

here=Path(__file__).resolve().parent
winner="both+safe+clipfull"
schedule={
    "qualification":[("abba02","abba",[winner,"frozen","frozen",winner,winner,"frozen"]),
                     ("abba03","abba",["frozen",winner,winner,"frozen"]),
                     ("state02","state",["frozen",winner]),("budget02","partial",["frozen",winner]),
                     ("serving01","serve",["frozen",winner,"prior"])],
    "dflash":[("df01","dflash",["frozen",winner,winner,"frozen"]),("dfprobe01","probe",[winner]),
              ("dfstate01","rollback",["frozen",winner])],
}
def run(job):
    for folder,action,modes in schedule[job]:
        dest=here/folder
        if (dest/"complete.json").exists():continue
        dest.mkdir(exist_ok=True)
        with exclusive(dest):
            for i,mode in enumerate(modes):
                if (dest/f"{i:02}-{mode}.json").exists():continue
                # Preserve an incomplete arm's log before restarting from a fresh process.
                old=dest/f"{i:02}-{mode}.log"
                if old.exists():
                    import time
                    old.rename(old.with_suffix(f".{time.time_ns()}.log"))
                arm(dest,action,i,mode)
        (dest/"complete.json").write_text(json.dumps(modes))

if __name__=="__main__":
    job=sys.argv[2]
    assert job in schedule
    if sys.argv[1]=="start":
        with (here/(job+".progress")).open("a") as log:
            proc=subprocess.Popen([sys.executable,"-u",str(Path(__file__).resolve()),"run",job],
                stdin=subprocess.DEVNULL,stdout=log,stderr=log,cwd=here,close_fds=True,
                creationflags=subprocess.DETACHED_PROCESS|subprocess.CREATE_NEW_PROCESS_GROUP)
        print("Started",proc.pid,flush=True)
    else:
        try: run(job)
        except BaseException:
            traceback.print_exc()
            raise
