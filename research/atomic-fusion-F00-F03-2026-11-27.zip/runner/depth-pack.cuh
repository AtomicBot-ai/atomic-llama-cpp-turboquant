// Preserve the aligned FP32 RMS reduction order of norm.cu at 6115c7090.
// One 1024-thread block reduces one 2304-element row as 576 float4 values.
static __global__ void f01_pack_rms(spark_depth_states inputs,float * out,int width,int depth,float eps) {
    const int row=blockIdx.x, i=threadIdx.x;
    float4 x{};
    float sum=0;
    if (i<width/4) {
        x=reinterpret_cast<const float4 *>(inputs.data[row])[i];
        sum += x.x*x.x + x.y*x.y + x.z*x.z + x.w*x.w;
    }
    __shared__ float partial[32];
    sum=block_reduce<block_reduce_method::SUM,1024>(sum,partial);
    const float scale=rsqrtf(sum/width+eps);
    if (i<width/4) {
        const float4 r=make_float4(scale*x.x,scale*x.y,scale*x.z,scale*x.w);
        reinterpret_cast<float4 *>(out+row*width)[i]=r;
        float * transposed=out+depth*width+row+4*i*depth;
        transposed[0]=r.x; transposed[depth]=r.y; transposed[2*depth]=r.z; transposed[3*depth]=r.w;
    }
}
static ggml_tensor * f01_pack_factory(ggml_context * ctx,ggml_tensor * cur,ggml_tensor * const * blocks,size_t n) {
    if (n>=8 || cur->ne[0]!=2304 || ggml_nelements(cur)!=2304) { return nullptr; }
    ggml_tensor * inputs[8]{};
    for (size_t i=0;i<=n;++i) {
        auto * t=i==n ? cur : blocks[n-1-i];
        if (t->type!=GGML_TYPE_F32 || !ggml_are_same_shape(t,cur) || !ggml_is_contiguous(t) ||
                t->view_offs%16!=0) { return nullptr; }
        inputs[i]=t;
    }
    auto * dst=ggml_custom_4d(ctx,GGML_TYPE_F32,2*2304*(n+1),1,1,1,inputs,int(n+1),spark_verify_device_only,1,nullptr);
    dst->op_params[spark_op_tag]=spark_target_depth_pack;
    return dst;
}
