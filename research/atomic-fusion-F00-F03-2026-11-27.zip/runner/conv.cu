// Width-one replay. The graph owns the input and output history as separate arrays.
#include <cuda_runtime.h>
#include <initializer_list>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#define CK(expr) do { cudaError_t e=(expr); if(e!=cudaSuccess){std::fprintf(stderr,"%s: %s\n",#expr,cudaGetErrorString(e));std::abort();} } while(0)

static __global__ void make_window(const float * past,const float * cur,float * window,int n) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<n) { for(int k=0;k<3;k++) window[4*c+k]=past[3*c+k]; window[4*c+3]=cur[c]; }
}
static __global__ void store_state(const float * window,float * next,int n) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<n) for(int k=0;k<3;k++) next[3*c+k]=window[4*c+1+k];
}
static __global__ void ssm(const float * w,const float * x,float * out,int n) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<n) { float v=0; for(int k=0;k<4;k++) v=__fmaf_rn(x[4*c+k],w[4*c+k],v); out[c]=v; }
}
static __global__ void tap_term(const float * x,const float * taps,float * term,int n,int heads,int k) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<n) term[c]=__fmul_rn(x[4*c+3-k],taps[4*(c/(n/heads))+k]);
}
static __global__ void sum_vec(const float * x,const float * y,float * out,int n) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<n) out[c]=__fadd_rn(x[c],y[c]);
}
static __global__ void scale_vec(float * out,float scale,int n) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<n) out[c]=__fmul_rn(out[c],scale);
}
static __global__ void fused(const float * past,const float * cur,const float * w,const float * taps,
                             float * next,float * out,int n,int heads,float scale) {
    int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c>=n) return;
    float x[4]={past[3*c],past[3*c+1],past[3*c+2],cur[c]};
    float v=0;
    for(int k=0;k<4;k++) v=__fmaf_rn(x[k],w[4*c+k],v);
    if(heads) for(int k=0;k<4;k++) v=__fadd_rn(v,__fmul_rn(x[3-k],taps[4*(c/(n/heads))+k]));
    for(int k=0;k<3;k++) next[3*c+k]=x[k+1];
    out[c]=__fmul_rn(__fadd_rn(cur[c],v),scale);
}
extern "C" void bench_conv(const float * history,const float * current,const float * weight,const float * taps,
                           int n,int heads,float * ssm_host,float * ref,float * cand,float * state_a,float * state_b,
                           float * us) {
    float *p,*c,*w,*t,*next,*out,*win,*term,*static_out;
    cudaStream_t stream; CK(cudaStreamCreate(&stream));
    auto alloc=[](float **ptr,int count,const float *host=nullptr) {
        CK(cudaMalloc(ptr,count*sizeof(float)));
        if(host) CK(cudaMemcpy(*ptr,host,count*sizeof(float),cudaMemcpyHostToDevice));
    };
    alloc(&p,3*n,history);alloc(&c,n,current);alloc(&w,4*n,weight);alloc(&t,heads?heads*4:1,taps);
    alloc(&next,3*n);alloc(&out,n);alloc(&win,4*n);alloc(&term,n);alloc(&static_out,n);
    const float scale=1.0f/sqrtf(heads?9.0f:5.0f);
    const int blocks=(n+127)/128;
    cudaGraphExec_t exec[2];
    for(int mode=0; mode<2;mode++) {
        cudaGraph_t graph;
        CK(cudaStreamBeginCapture(stream,cudaStreamCaptureModeThreadLocal));
        if(mode==0) {
            make_window<<<blocks,128,0,stream>>>(p,c,win,n);
            store_state<<<blocks,128,0,stream>>>(win,next,n);
            ssm<<<blocks,128,0,stream>>>(w,win,static_out,n);
            const float * accumulator=static_out;
            for(int k=0;heads && k<4;k++) {
                tap_term<<<blocks,128,0,stream>>>(win,t,term,n,heads,k);
                sum_vec<<<blocks,128,0,stream>>>(accumulator,term,out,n);
                accumulator=out;
            }
            sum_vec<<<blocks,128,0,stream>>>(accumulator,c,out,n);
            scale_vec<<<blocks,128,0,stream>>>(out,scale,n);
        } else {
            fused<<<blocks,128,0,stream>>>(p,c,w,t,next,out,n,heads,scale);
        }
        CK(cudaStreamEndCapture(stream,&graph)); CK(cudaGraphInstantiate(&exec[mode],graph,0));
        CK(cudaGraphDestroy(graph)); CK(cudaGraphLaunch(exec[mode],stream)); CK(cudaStreamSynchronize(stream));
        CK(cudaMemcpy(mode?cand:ref,out,4*n,cudaMemcpyDeviceToHost));
        CK(cudaMemcpy(mode?state_b:state_a,next,12*n,cudaMemcpyDeviceToHost));
        if(!mode) CK(cudaMemcpy(ssm_host,static_out,4*n,cudaMemcpyDeviceToHost));
    }
    cudaEvent_t a,b; CK(cudaEventCreate(&a));CK(cudaEventCreate(&b));
    const int order[]={0,1,1,0};
    for(int j=0;j<4;j++) {
        auto graph=exec[order[j]];
        for(int i=0;i<32;i++) CK(cudaGraphLaunch(graph,stream));
        CK(cudaEventRecord(a,stream));
        for(int i=0;i<256;i++) CK(cudaGraphLaunch(graph,stream));
        CK(cudaEventRecord(b,stream)); CK(cudaEventSynchronize(b));
        float ms; CK(cudaEventElapsedTime(&ms,a,b)); us[j]=1000*ms/256;
    }
    CK(cudaEventDestroy(a)); CK(cudaEventDestroy(b)); for(auto g:exec) CK(cudaGraphExecDestroy(g));
    for(auto v:{p,c,w,t,next,out,win,term,static_out}) CK(cudaFree(v));
    CK(cudaStreamDestroy(stream));
}
