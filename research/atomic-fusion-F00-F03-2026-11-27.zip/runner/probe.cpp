// Private capture through ggml's evaluation callback. Never used for timing.
#include "llama.h"
#include "ggml-backend.h"
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
#include <string>
#include <vector>
namespace fs = std::filesystem;
struct capture {
    fs::path out;
    int step = 0;
    std::map<std::string,int> visits;
    int controllers = 0, convs = 0;
};
static void save(const fs::path & file, ggml_tensor * t) {
    GGML_ASSERT(t->type == GGML_TYPE_F32 && ggml_is_contiguous(t));
    std::vector<char> bytes(ggml_nbytes(t));
    ggml_backend_tensor_get(t, bytes.data(), 0, bytes.size());
    std::ofstream f(file, std::ios::binary);
    f.write(bytes.data(), bytes.size());
    GGML_ASSERT(f.good());
}
static bool inspect(ggml_tensor * t, bool ask, void * opaque) {
    auto & c = *static_cast<capture *>(opaque);
    if (c.step < 1 || !t->src[0]) return false;
    const auto named = [](ggml_tensor * node, const char * name) {
        return node && node->src[0] && std::string(node->src[0]->name)==name;
    };
    const bool down=t->op==GGML_OP_MUL_MAT && named(t,"blk.6.loop_q_ctrl_down.weight");
    const bool gain=t->op==GGML_OP_MUL_MAT && named(t,"blk.6.loop_q_ctrl_gain.weight");
    const bool forget=t->op==GGML_OP_MUL_MAT && named(t,"blk.6.loop_q_ctrl_forget.weight");
    const bool ctrl=t->op==GGML_OP_ADD && t->src[1] && t->src[1]->op==GGML_OP_MUL &&
        t->src[1]->src[0] && t->src[1]->src[0]->op==GGML_OP_UNARY &&
        named(t->src[1]->src[0]->src[0],"blk.6.loop_q_ctrl_gain.weight");
    const bool conv=t->op==GGML_OP_SSM_CONV && t->src[1] &&
        std::string(t->src[1]->name)=="blk.11.attn_k_conv.weight";
    const bool taps=t->op==GGML_OP_MUL_MAT && named(t,"blk.11.attn_k_conv_proj.weight");
    auto * acc=t->op==GGML_OP_SCALE && t->src[0]->op==GGML_OP_ADD ? t->src[0]->src[1] : nullptr;
    while(acc && acc->op==GGML_OP_ADD) acc=acc->src[0];
    const bool conv_out=acc && acc->op==GGML_OP_RESHAPE && acc->src[0]->op==GGML_OP_SSM_CONV &&
        std::string(acc->src[0]->src[1]->name)=="blk.11.attn_k_conv.weight";
    if (!(down || gain || forget || ctrl || conv || taps || conv_out)) return false;
    if (ask) return true;
    const char * kind=down?"down":gain?"gain":forget?"forget":ctrl?"ctrl":conv?"conv":taps?"taps":"conv_out";
    const int visit=c.visits[kind]++;
    const std::string prefix=(conv || conv_out)?"conv":taps?"taps":"ctrl";
    const fs::path path=c.out/(prefix+"-"+std::to_string(c.step)+"-"+std::to_string(visit));
    fs::create_directories(path);
    if (down) {
        auto * concat=t->src[1];
        GGML_ASSERT(concat->op==GGML_OP_CONCAT && concat->src[0]->op==GGML_OP_RMS_NORM &&
                    concat->src[1]->op==GGML_OP_RMS_NORM);
        save(path/"cur",concat->src[0]->src[0]); save(path/"msg",concat->src[1]->src[0]);
        save(path/"wd",t->src[0]);
    } else if (gain || forget) {
        save(path/(gain?"wg":"wf"),t->src[0]);
    } else if(ctrl) {
        save(path/"output",t); c.controllers++;
    } else if(conv) {
        save(path/"window",t->src[0]); save(path/"weight",t->src[1]); save(path/"ssm",t); c.convs++;
    } else if(taps) {
        save(path/"values",t);
    } else {
        save(path/"output",t);
    }
    return true;
}
int main(int argc, char ** argv) {
    GGML_ASSERT(argc>6);
    capture c{argv[2]};
    std::vector<llama_token> ids;
    for(int i=3;i<argc;i++) ids.push_back(std::atoi(argv[i]));
    ggml_backend_load_all();
    auto * dev=ggml_backend_dev_by_name("CUDA0"); GGML_ASSERT(dev);
    ggml_backend_dev_t devices[]={dev,nullptr};
    auto mp=llama_model_default_params();
    mp.devices=devices; mp.n_gpu_layers=999; mp.memory_budget_size=size_t(20580)<<20;
    auto * m=llama_model_load_from_file(argv[1],mp); GGML_ASSERT(m);
    auto cp=llama_context_default_params();
    cp.n_ctx=4096; cp.n_batch=cp.n_ubatch=1000; cp.n_seq_max=1;
    cp.n_threads=cp.n_threads_batch=8; cp.flash_attn_type=LLAMA_FLASH_ATTN_TYPE_ENABLED;
    cp.type_k=cp.type_v=GGML_TYPE_Q4_0; cp.cb_eval=inspect; cp.cb_eval_user_data=&c;
    auto * ctx=llama_init_from_model(m,cp); GGML_ASSERT(ctx);
    // First token exercises empty history. Restart the sequence for the matched prompt.
    c.step=1;
    GGML_ASSERT(llama_decode(ctx,llama_batch_get_one(ids.data(),1))==0);
    llama_synchronize(ctx);
    llama_memory_clear(llama_get_memory(ctx),true);
    c.step=0;
    GGML_ASSERT(llama_decode(ctx,llama_batch_get_one(ids.data(),ids.size()-2))==0);
    for(int i=0;i<2;i++) {
        c.step=i+2; c.visits.clear();
        GGML_ASSERT(llama_decode(ctx,llama_batch_get_one(ids.data()+ids.size()-2+i,1))==0);
        llama_synchronize(ctx);
    }
    std::printf("Captured %d controllers and %d convolutions\n",c.controllers,c.convs);
    llama_free(ctx); llama_model_free(m); llama_backend_free();
    return c.controllers && c.convs ? 0 : 2;
}
