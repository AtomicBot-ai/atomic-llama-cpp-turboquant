"""Record identities of captured inputs and restore records without their model bytes."""
import sys
import hashlib
import json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from window import BASE, FIXTURE, HERE, LAB, R08, file_hash

fixture=json.loads(FIXTURE.read_text())
out={"fixture_file_sha256":file_hash(FIXTURE),"fixtures":{},"real_inputs":{},"binaries":{},"windows":{}}
for case,v in fixture.items():
    out["fixtures"][case]={k:{"length":len(ids),"sha256_le_i32":hashlib.sha256(
        b"".join(n.to_bytes(4,"little",signed=True) for n in ids)).hexdigest()} for k,ids in v.items()}
for d in sorted((HERE/"inputs01").iterdir()):
    if d.is_dir():out["real_inputs"][d.name]={p.name:file_hash(p) for p in sorted(d.iterdir()) if p.is_file()}
for p in [HERE/"probe.exe",HERE/"replay.exe",*(LAB/"build/bin").glob("f01-*.exe"),*(LAB/"build/bin").glob("f06-*.exe"),*(LAB/"build/bin").glob("f07-*.exe")]:
    out["binaries"][p.name]=file_hash(p)
for path in sorted(HERE.glob("*/restoration.json")):
    out["windows"][path.parent.name]=json.loads(path.read_text())
if "--health" in sys.argv:
    import runpy
    import urllib.request
    from datetime import datetime,timezone
    root=BASE["ROOT"]
    registry=json.loads((root/"results/source-rollback-retain-20261125/manual-instance.json").read_bytes())
    service=runpy.run_path(str(BASE["OLD"]/"serve-loopback.py"))["load"]()
    cmd,_=service["prepare"]()
    pid=service["owner"]()
    exe=service["pid_path"](pid)
    url=registry.get("url","http://127.0.0.1:8080").rstrip("/")
    with urllib.request.urlopen(url+"/health",timeout=8) as reply:
        status=json.load(reply)
    out["final_service"]=dict(utc=datetime.now(timezone.utc).isoformat(),url=url,pid=pid,health=status,
                              exe_sha256=file_hash(exe),same_command=cmd==registry["cmd"],
                              same_exe=Path(exe)==Path(cmd[0]),same_pid=pid==registry["pid"])
    assert out["final_service"]["exe_sha256"]==registry["sha256"] and status["status"]=="ok"
    assert all(out["final_service"][k] for k in ("same_command","same_exe","same_pid"))
print(json.dumps(out))
