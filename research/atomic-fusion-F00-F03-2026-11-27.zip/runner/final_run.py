"""Sequential qualification of the measured winner, preserving completed arms on reconnect."""
import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qualify_fusion import arm
from reduce import timing
from window import exclusive

root=Path(__file__).resolve().parent

def group(name, action, modes):
    out=root/name
    out.mkdir(exist_ok=True)
    if not (out/"complete.json").is_file():
        with exclusive(out):
            for index,mode in enumerate(modes):
                stem=f"{index:02}-{mode}"
                if (out/(stem+".json")).is_file(): continue
                old=out/(stem+".log")
                if old.is_file():
                    import time
                    old.rename(out/(stem+f".{time.time_ns()}.log"))
                arm(out,action,index,mode)
        (out/"complete.json").write_text(json.dumps(modes))
    return [json.loads((out/f"{i:02}-{m}.json").read_text()) for i,m in enumerate(modes)]

if __name__=="__main__":
    mode=sys.argv[1]
    ref="frozen+ext" if "ext" in mode.split("+") else "frozen"
    if ref=="frozen+ext":
        all_rows=group("abba_final01","abba",[ref,mode,mode,ref]*3)
        for i in (0,4,8):
            values=[timing(x["requests"])["ms_per_update"] for x in all_rows[i:i+4]]
            print("ABBA",[round(x,3) for x in values],flush=True)
        group("state_final01","state",[ref,mode])
        group("budget_final01","partial",[ref,mode])
        ordinary=group("serving_final01","serve",[ref,mode])
        rates=[timing(x["requests"])["tps"] for x in ordinary]
        print("Normal serving",rates,flush=True)
        if rates[1]<=rates[0]:
            raise RuntimeError("Extension failed ordinary serving; evaluate earlier candidate before DFlash")
    group("df_final01","dflash",[ref,mode,mode,ref])
    group("dfprobe_final01","probe",[mode])
    group("dfstate_final01","rollback",[ref,mode])
    if ref=="frozen+ext" and not (root/"trace_next/summary.json").is_file():
        subprocess.run([sys.executable,"-u","trace_fusion.py","trace_next",ref,mode],cwd=root,check=True)
