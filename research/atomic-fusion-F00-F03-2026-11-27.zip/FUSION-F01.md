# Inkling 2 Mini on RTX Spark N1X · F00–F03

The best profile tested across all six R08 chat prompts (F06) increased warmed target-only throughput from **35.36 to 40.58 updates/s** on 12 ordinary requests. Median time to first token (TTFT) was **322→315 ms**. The three-block fixed-continuation result was +14.79%. These final pairs ran near 1.43 GHz. A supplemental depth-copy variant (F07) reached **35.49→41.28 updates/s (+16.30%)** across three fixed-continuation blocks. Its ordinary serving rate remains open. The initial F00 reference ran near 2.45 GHz, and the final profile lacks a matched high-clock result.

## Scope and reference

Atomic worktree at `6115c7090feebdacd90f737cf02de9a45734e6b8`, PR 105. The private build starts from the R08 resident combined patch. The short-prompt scratch pool is enabled in every arm. “Frozen” uses the original target math and graph cuts. “Prior” additionally enables the R08 controller tail, relative mask and aligned capture cuts. The ordinary serving binary and the diagnostic fingerprint binary have separate hashes. Comparisons within either experiment use the same executable.

Target GGUF SHA-256 `c271770860619fcf2908262070a40e9cd656f82c9650f41415d7558722957759`. One sequence, full GPU offload, 4,096 context, Q4_0 K/V, batch and microbatch 1,000, unchanged 20,580 MiB managed budget. All performance runs were sequential. The evidence JSON includes the actual arguments and environment, input-ID hashes, raw timings and executable identities.

## F00 · where the time went

The fresh frozen control ran one lunch and one short/long warmup pair, then two alternating sky/briefing pairs. Each emitted exactly 65 instances of ID 13 using logit bias, without grammar, probability export or prompt caching. The four server decode times were **21.718, 23.216, 22.030 and 22.638 ms/update**. Pooling their 256 updates gives **22.401 ms/update**. At this baseline +15% throughput requires saving **2.922 ms** and +20% requires **3.733 ms**. Client median inter-token gaps were 21.443, 22.764, 21.492 and 22.297 ms. Short TTFT was 191–198 ms and long TTFT 2,576–2,579 ms. These first-token times are outside the decode denominator.

Matched R08 CUPTI segment, third interior decode, between transfers of full logits to host. Each cell gives kernel executions and summed device ms. The attribution script checks that each event belongs to only one group. These sums include the cost of the replacement when comparing to stock. Host time has a different clock interpretation.

| Block and site per update | Atomic | Broad fusion2 | Stock b12810 | Recoverable component and action |
|---|---:|---:|---:|---|
| 96 controllers at Q/K/V/FFN, two revisits to physical 6–17 | 1,128 / 2.410 | 672 / 1.963 | 192 / 1.585 | 0.825 ms difference. Preserve reduction and projection ordering. Atomic omits 24 nonadjacent normalization kernels from this attribution. |
| 192 short convolutions, four sites across 48 logical layers | 768 / 1.331 | 192 / 0.292 | 192 / 0.320 | 1.011 ms in compute against stock. 16 visits use dynamic taps and 176 use only static taps. |
| Assemble four-wide windows and store their three-entry histories | 384 / 0.571 | 384 / 0.565 | folded | Included in stock's short-convolution time. Direct staging still needs a recurrent-cell write. |
| Following residual adds, only immediately identifiable events | 88 / 0.140 | 88 / 0.088 | folded | The new kernel stops at the convolution result. These downstream adds are an upper-bound component only. |
| Depth stack, normalization, query scores, weights and reduction | 1,048 / 1.845 | 120 / 1.967 | 118 / 1.310 | 0.535 ms comparison gap. The earlier broad replacement was slower. |
| Routed expert projections | 96 / about 6.38 | 96 / about 6.4 | 96 / about 6.26 | Comparable work across profiles. Excluded from the fusion estimate. |

Controller and convolution together account for about 2.55 ms of device-time differences when the entire window and following residual are counted. Including depth brings the sum to about 3.08 ms. Atomic/stock GPU kernel envelopes were 21.240/17.083 ms, giving an arithmetic remainder of **1.07 ms** before separate clipping attribution. The six operations *after* the Q/K/relative sum-of-squares reduction consumed 0.801 ms across 144 sites (864 recorded kernels). Their replacement also costs time. Only paired end-to-end timings establish the wall savings. All three original traces used different graph groupings, and Atomic used MSVC/CUDA 13.4 and stock used Clang/CUDA 13.5.

Atomic/fusion2/stock executed 7,540/4,175/2,650 kernels, occupied a union of 20.135/18.537/16.229 GPU ms, and submitted 8/8/22 host graph launches. There were 33/32/7 stream synchronizations. The sums of host waits, 12.750/15.250/0.097 ms, overlap GPU work, including expert kernels. The matched intervals were 24.240/21.959/17.739 ms wall. Adding the waits to the GPU sums would count work twice.

## F01 · real-input replay

The controller probe captured physical layer 6, Q branch, both loop revisits, on the first token with empty state and two consecutive decode tokens. The original sends each FP32 2,304-element row through its own RMS norm (epsilon 1e-6), concatenates the two rows and applies a 4,608→64 down projection and two 64→2,304 projections. The candidate stacks two rows *before* RMS and flattens the result. The CUDA RMS kernel therefore still reduces two independent 2,304-element groups. The initial data and both output rows are contiguous, FP32, four bytes per element. The order of multiplying by the inverse norm and of the matrix products stays intact. Stock's fused projection moves normalization relative to the dot product. The previously tested CONTROL_PROJECT changes a different part of this block.

All six complete controller outputs matched the engine byte for byte. An ABBA replay (16 warm submissions, 128 timed per arm, then device synchronization) averaged 20.260→18.889 µs. Per-input paired savings ranged from −0.342 to +2.511 µs, median +1.526 µs. This measures the complete block through drain. One sample went backwards.

The convolution probe captured physical layer 11, K, all three logical visits on the same three steps. Each input contained 1,024 channels, three history entries per channel, one current value, four static coefficients and four dynamic coefficients per each of eight heads. The new kernel reads the three old values before producing the new window. It executes the four static FMAs, rounds each dynamic multiply and add separately, adds the residual, multiplies by the original scale and stages the next three values. The reference reconstructed the separate window, SSM, dynamic terms, output and history store. The integrated graph copies staged history into the original charged recurrent cell. The block replay writes a distinct contiguous history output.

All nine reference and candidate outputs, static SSM reference outputs and next histories matched the captured/reference values, with maximum absolute and relative error zero. The previous step's candidate history also matched the engine's next input history on all three visits. Thirty-two warm CUDA Graph launches and 256 timed launches per ABBA arm averaged 19.005→15.193 µs, a paired saving of 2.068–6.279 µs, median 3.733 µs. This is a dynamic K result. Multiplying it by all 192 sites would extrapolate to other geometries.

## F02 · numerical localization

The broad R08 candidate had changed 10/260 top choices. The archived single-family ablations changed 10 for depth, 13 for convolution and 5 for clipping. Controller and relative mask each changed zero. The new unconditional convolution also failed. On identical inputs it changed 12/260 argmax values and 256/260 full-vocabulary fingerprints. The first changed vector was lunch index 1. At lunch index 20 (zero-based) the first changed argmax went from token 150921 to 149921, and the maximum difference among shared top-12 log-probabilities was 4.1701. Combining it with the paired controller produced the same failures. The controller alone matched all 260 fingerprints.

Holding the new math fixed and restoring the earlier capture-boundary rule still changed 23/24 lunch fingerprints. Activating only dynamic convolution, only K, only V or only FFN changed zero. Static convolution alone and attention-output convolution alone each reproduced the 23/24 differences and the first argmax change at index 20. This localizes a sufficient integration site to the convolution after the attention output projection. Localization stops at the operator boundary. Its generic path is retained. The retained convolution sites are K, V and FFN, 144 invocations per interior update. Each keeps its original state cell and copies the three history elements only after reading them.

The restricted convolution with and without paired RMS matched **260/260** full-vocabulary fingerprints. The repeated lunch request matched its own fresh result at **65/65** positions. The frozen control changed all 65 repeat hashes and one top choice on that specific cross-length sequence. The earlier aligned R08 path reproduced its own fresh output. Repeated outputs are therefore compared both across configurations and within each arm.

The combination reproduced all 16 fresh fingerprints after an intervening natural EOS and again after a two-token cap. At the 16,484 MiB partial budget it selected zero new operators, matched 8/8 fingerprints, read 2,579,890,176 logical expert bytes and reached a ledger high-water mark of 16,483.934 MiB in both arms. Sampled device peaks were 15,640/15,680 MiB. Device memory samples include the rest of the system. The allocator ledger measures the model's accounting contract.

## F02 · clipping without moving upstream operations

The R08 broad clipping experiment rebuilt the model graph and changed five top choices. Here the graph keeps its original input-scale, sum, downstream consumers and cuts. Only during resident tagged width-one CUDA capture does a backend matcher recognize the exact operation sequence. It checks use counts, edges, shape, contiguity and aliasing. An aliased input is allowed only for one-to-one output indexing. One version starts at square root and fuses six operations. Another starts at square and reuses the existing clip kernel with the same reduction geometry and already-scaled input. Other chunks use the generic graph. Width 16 is relative attention. Width 128 is Q/K.

The 128-only tail first brought the single screen from 22.003 to 21.348 ms/update. Applying the tail to both widths and then comparing it to the full matcher gave 21.039 vs 20.888 ms/update. Both versions matched all 260 full logits fingerprints and the 65-position repeated lunch. The complete matcher was selected at all 144 sites per capture. In the four-prompt-plus-repeat diagnostic there were 720 convolution graph selections, 480 paired controller selections and 720 full clipping selections across five graph constructions/captures. These counts describe graph construction. A separate CUPTI capture checks actual executions on a replay.

The restricted full-clipping candidate also matched 16/16 fresh fingerprints after each EOS and limit transition, and 8/8 at 16,484 MiB. All new dispatch counts were zero in partial mode. High-water accounting was 16,483.934 MiB on both arms.

## F02 · fixed-input ABBA before the depth experiment

A is frozen math with the R08 pool, B additionally enables the aligned R08 path, paired RMS, K/V/FFN convolution and full clipping. Each arm was a fresh server with a short/long warmup before the measured short/long pair, temperature zero, 65 constant IDs, no grammar and no probability export. All rates count 64 decode updates per measured request. Device peaks are 300 ms samples of total GPU memory. Exact managed high water is reported separately.

| Uninterrupted ABBA | Frozen ms/update | Candidate ms/update | Throughput gain | Short / long gain | Largest within-arm difference |
|---|---:|---:|---:|---:|---:|
| Initial 2.44–2.48 GHz | 22.396 | 20.272 | +10.48% | +10.41 / +10.55% | 0.218 ms |
| Later 1.42–1.43 GHz | 28.306 | 25.032 | +13.08% | +12.60 / +13.55% | 0.042 ms |
| Later low-clock repeat | 28.276 | 25.119 | +12.57% | +12.31 / +12.81% | 0.104 ms |

A fourth, split ABBA is retained as a sensitivity check. During its first B arm end-of-run telemetry moved from 2,450 MHz/48.90 W to 1,443 MHz/13.44 W, the SSH connection closed, and the runner restored the service. The remaining B/A resumed in a fresh exclusive window. Arithmetic across that transition gives +0.31%. Each uninterrupted block showed the same direction on both prompts, with the pooled saving larger than the within-arm spread. Combining the clock regimes into one absolute production speed would obscure the difference. In the high-clock block B saved 2.124 ms. A further 0.80 ms would reach +15% against that block's A. The baseline for the high-clock goal is the high-clock A arm.

## F02 · normal serving before the depth experiment

Six original R08 conversations, seeds 42 and 43, temperature 1, normal EOS, 1,536-token cap, identical sampler defaults and cache disabled. One separate warmup used seed 44. The low-clock frozen run produced 6,797 decode updates in 194.573 s, **34.93 updates/s, 28.626 ms/update**. B produced 7,076 in 177.486 s, **39.87 updates/s, 25.083 ms/update**. That is **+14.13%**. The six per-prompt paired rates all improved. Median TTFT was 319.96→320.94 ms, total HTTP time 203.25→186.16 s, and both had 11 EOS and one limit. Sampled device peak was 17,031→17,024 MiB and managed high water 17,978.08 MiB for both. Seven of twelve visible-answer hashes and seven reasoning hashes matched. Different sampled lengths affect total HTTP time, so the fixed-trajectory ABBA remains the primary causal estimate.

Against the previously qualified aligned R08 arithmetic, the new convolution, RMS pairing and clipping raised ordinary serving by **7.57%**, from 37.06 to 39.87 updates/s. Both generated 7,076 updates and all twelve visible-answer hashes matched. The prior control took 26.981 ms/update, with 331.0 ms median TTFT and 199.61 s wall.

At 15:10 UTC Windows reported external power and the Balanced plan. Independent telemetry subsequently continued to show about 1.43 GHz and 12 W at high GPU utilization. Power and clock regimes in this report are derived from measurements. The runner only read power telemetry.

## Remaining work measured in the input trace

The depth mix passed normalized residual rows to both a scoring product and a transposed weighted sum. In the matched Atomic step its 260 stack-concat kernels cost 0.341 ms, 120 normalizations 0.209, 120 transpose copies 0.240 and 120 single-token query repeats 0.211. Together these cost **1.001 ms before replacement**, within the depth row of F00. An optional private variant takes the same rows, uses the original aligned FP32 RMS reduction order, emits both layouts from one kernel and uses the existing query at width one. Both matmuls and softmax still use the generic implementation. The full broad depth kernel previously changed ten top choices.

Separately, in R08 fusion2 the 96 pairs of rank-64 controller up projections cost 0.735 ms, with another 0.096 ms for their tail. The original private projected controller assigned each lane two elements 32 apart. Frozen CUDA MMVF takes *adjacent* FP32 pairs and reduces their sums across a warp. A second optional matcher combines the two up projections and the residual with that actual ordering. These values bound the time available for replacement on the traced inputs.


The next same-binary experiment separated depth preparation and the corrected rank-64 projection. The depth-only variant changed 9/260 argmax results, the first at lunch index 4, and 256/260 full logit fingerprints. The combined depth + projection variant also changed nine. The projected controller alone matched all 260 reference vectors by fingerprint and repeated all 65 fresh lunch fingerprints. On five graph captures it replaced 465 projection pairs, or 93 per construction. The remaining three pairs per update use the ordinary projections. A frozen-continuation A/B/A screen on the established path gave **25.249 / 24.403 / 25.269 ms/update**. Only the corrected projections advanced to final qualification.

## Final width-one qualification

The final measured profile combines the R08 pool and aligned controller/mask, paired RMS, K/V/FFN short convolution, capture-time clipping, and adjacent-pair rank-64 projection. Depth packing is disabled. Full verification uses the same extended executable on both sides. Twelve fresh-server arms made three uninterrupted ABBA blocks. High-utilization median GPU clocks remained around 1.43 GHz.

| ABBA | Frozen ms/update | Candidate ms/update | Saving | Throughput gain | Short / long gain | Largest within-arm difference |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 28.080 | 24.337 | 3.743 ms | +15.38% | +14.84 / +15.89% | 0.137 ms |
| 2 | 28.018 | 24.791 | 3.228 ms | +13.02% | +12.45 / +13.57% | 0.332 ms |
| 3 | 28.324 | 24.420 | 3.904 ms | +15.99% | +15.63 / +16.33% | 0.322 ms |

Across the three blocks each arm contributed 768 updates. The aggregate was **28.141→24.516 ms/update**, **35.54→40.79 updates/s**, or **+14.79%**. The pooled saving was 3.625 ms. Another 0.046 ms/update is required for +15% and 1.065 for +20% in this regime. The client medians were 27.861→24.218 ms. All 24 measured requests ended at the specified cap. The aggregate HTTP totals were 40.24→37.33 s and sampled device peaks were 17,046→17,038 MiB. The JSON separates TTFT by short and long prompt.

The final candidate matched 260/260 full-vocabulary fingerprints and 65/65 repeated-lunch fingerprints. After a natural stop and again after a limit, 16/16 probe fingerprints matched fresh. At 16,484 MiB it matched 8/8 with zero new operator hits and the same 2,579,890,176 logical expert bytes read.


On the 12 normal R08 requests the final same-binary pair gave **35.36→40.58 updates/s (+14.78%)**, or **28.284→24.641 ms/update**. Frozen produced 6,797 updates in 192.245 decode seconds, while the candidate produced 7,076 in 174.362 s. Median TTFT changed from 322.13 to 315.00 ms and total HTTP wall from 200.94 to 183.08 s. Both recorded 11 EOS and one length stop, 17,978.08 MiB managed high water, and sampled device peaks of 17,046 and 17,038 MiB. The paired improvement appeared in all six prompt families. Seven of twelve visible answers and seven reasoning streams matched frozen. All twelve visible answers matched the earlier aligned R08 control, which also emitted 7,076 updates. That earlier control ran at 37.06 updates/s, providing a cross-run incremental comparison of about +9.5% to the final controller/convolution/clipping combination.

On ordinary serving, median TTFT for lunch was 324.4→310.7 ms, sky 276.7→277.0 ms and the long briefing 3,207.5→3,191.5 ms. On the fixed continuations, TTFT was 201.5→201.5 ms for sky and 2,901.5→2,887.1 ms for briefing. Each pair uses the same prompt and request mode.

The matched interior GPU step in the final trace went from 7,540 to 4,714 kernel executions across eight host graph launches in each arm. The first-to-last kernel interval fell from 27.510 to 23.473 ms, and the union of busy kernel intervals from 25.960 to 21.961 ms. The candidate executed 144 fused convolutions, 144 clipping kernels, 93 corrected controller projections, three fallback projections and 48 relative masks. Both arms executed 96 routed NVFP4 expert kernels. These trace timings include instrumentation. Speedup figures above come from clean serving.

## F03 · DFlash2, seven proposals, width eight

Four clean process arms in ABBA order, each warming on lunch seed 44 and then serving lunch/sky at seeds 42/43 with normal EOS and a 192-token cap. Both sides produced **1,394 committed decode updates in 448 verification rounds**. The original log reports a rounded mean accepted length. The accepted/generated integers uniquely determine every per-request round count in this run.

| Short DFlash2 ABBA | Frozen | Width-one switches enabled |
|---|---:|---:|
| Committed updates/s | 47.65 | 47.53 |
| ms/committed update | 20.986 | 21.040 |
| ms/round | 65.301 | 65.469 |
| Committed updates/round | 3.112 | 3.112 |
| Accepted / proposed | 952 / 3,120 | 952 / 3,120 |
| Median TTFT | 338.7 ms | 334.8 ms |
| HTTP wall across eight measured requests per arm | 31.30 s | 31.34 s |
| EOS / length | 4 / 4 | 4 / 4 |
| Sampled device peak / managed high water | 17,514 / 18,403.39 MiB | 17,514 / 18,403.39 MiB |

The −0.26% point estimate is neutral at the scale of this smoke. Each of the four paired visible answers matched. All new dispatch counters were zero on the instrumented DFlash2 probe and on the rollback check. Greedy lunch emitted the same 32 IDs when fresh, after a 217-token sky EOS and after a two-token cap. Both modes saw 25 accepted of 35 proposals on each lunch check. The two-token capped request exercised the short tail. The observed rollback check covers request boundaries and the sampled rejection paths. Keep DFlash2 on its existing implementation.

## Supplemental width-one depth experiment (F07)

The first depth candidate still changed the lunch argmax at index 4 when query repetition was restored. Both variants that restricted the kernel to copying raw rows and retained ggml normalization and transpose matched all 260 full-vocabulary fingerprints and all 65 repeat fingerprints. Each used 120 packed copies per interior step. With the exact F06 controller held constant, the short fixed screen measured 24.525 ms/update at entry, 24.398 with the generic query repeat, 24.368 with direct width-one query access and 24.512 on return to control. Both packing variants are experimental.

Against the original frozen control in the same F07 binary, the direct-query variant produced 35.49→41.28 updates/s (28.175→24.226 ms/update). Three independent ABBA blocks gave +16.37%, +16.42%, +16.12%, pooled **+16.30%**. The frozen and candidate arms each processed 768 fixed updates. The low-clock regime persisted. The F06-to-F07 incremental evidence is the four-arm screen above. The percentage against frozen includes the earlier F06 changes.

After EOS and the length limit the candidate reproduced 16/16 and 16/16 fresh fingerprints, respectively.

At 16,484 MiB the candidate matched 8/8 frozen full-vocabulary fingerprints. The diagnostic counted 0 experimental dispatches at this budget.

The optional short F07 serving runner failed during import before acquiring the service. The embedded Python path was corrected in the archived runner. The remaining time was insufficient for a complete pair. The next experiment is the same-binary, six-prompt serving set for F07 with the frozen control, plus a projection-only F07 arm to measure the incremental depth effect. The four-arm fixed screen suggests about 0.15 ms/update of incremental savings.

F06 remains the best variant with the complete six-prompt serving comparison and the DFlash2 smoke. F07 still needs the 12-request ordinary comparison and a DFlash2 fallback check. The 2.45 GHz fixed and ordinary F07/F06 results remain unknown. The main patch represents F06. The depth-diagnostic patch applies on top of the archived R08 starting patch.

## Reproduction

The combined patch applies directly to PR 105 revision `6115c7090` and passed `git apply --check` on that revision. The capture and compilation scripts use the prepared Windows ARM64 R08 libraries and service registry. In a fresh private sibling directory, put the runner files and the archived R08 analysis helper side by side. The supplied fixture has exact native IDs and continuations. Every benchmark requests a fresh output directory, with service restoration checked against the registered command, executable hash and HTTP endpoint. Reference scripts and prompt texts are included in the ZIP. The stand retains large activation blobs and original job JSONs under their recorded hashes.

The final research binary uses `LLAMA_EXPERIMENTAL_SPARK_SHORT_PROMPT_POOL=1`, `LLAMA_EXPERIMENTAL_SPARK_TARGET_FUSION=1`, `ATOMIC_F01_PAIR=1`, `ATOMIC_F01_CONV=1`, `ATOMIC_F01_SELECT=safe`, `ATOMIC_F01_CLIP=1`, `ATOMIC_F01_CLIP_FULL=1` and `ATOMIC_F01_PROJECT=1`. The depth switch is off. Normal timings use the clean server without probability or operator tracing. The raw server exports full-logit fingerprints and counts during graph construction or capture. A disabled capture matcher retains a small platform-specific dispatch predicate. Disabled-path overhead relative to an unmodified build was outside this comparison. Validation covered the sampled model, fixture, budgets, single-GPU resident profile and speculative smoke. Aggregate repository tests were outside the approved run. The last experiment restored the registered service. An independent HTTP check at 15:49:12 UTC returned ok on port 8080 with the registered command, PID and executable SHA-256. The first-pass GPU window closed within the 90-minute limit.

[Machine-readable evidence](FUSION-F01.json) · [Combined patch](FUSION-F01.patch)
