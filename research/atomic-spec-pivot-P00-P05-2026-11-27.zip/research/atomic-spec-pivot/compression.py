"""Trace-weighted CPU feasibility test. Read selected byte tiles from an immutable GGUF v3."""
import argparse
from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
import math
import mmap
from pathlib import Path
import random
import struct
import time
import zlib

BLOCK = 36
FORMATS = {0:"B",1:"b",2:"H",3:"h",4:"I",5:"i",6:"f",7:"?",10:"Q",11:"q",12:"d"}


def metadata(f):
    def read(fmt):
        return struct.unpack("<"+fmt, f.read(struct.calcsize("<"+fmt)))[0]
    def string():
        return f.read(read("Q")).decode()
    def value(kind):
        if kind in FORMATS:
            return read(FORMATS[kind])
        if kind == 8:
            return string()
        if kind != 9:
            raise ValueError(kind)
        element, count = read("I"), read("Q")
        if element in FORMATS:
            f.seek(count*struct.calcsize("<"+FORMATS[element]), 1)
        elif element == 8:
            for _ in range(count):
                f.seek(read("Q"), 1)
        else:
            raise ValueError(element)
    assert f.read(4) == b"GGUF" and read("I") == 3
    nt, nk = read("Q"), read("Q")
    fields = {}
    for _ in range(nk):
        key = string()
        fields[key] = value(read("I"))
    tensors = {}
    for _ in range(nt):
        name = string()
        shape = [read("Q") for _ in range(read("I"))]
        kind, offset = read("I"), read("Q")
        if "_exps.weight" in name:
            assert kind == 40 and len(shape) == 3 and shape[2] == 128
            tensors[name] = (shape,offset)
    align = fields.get("general.alignment",32)
    base = (f.tell()+align-1)//align*align
    return fields,tensors,base


def split(raw):
    scales = b"".join(raw[i:i+4] for i in range(0,len(raw),BLOCK))
    codes = b"".join(raw[i+4:i+BLOCK] for i in range(0,len(raw),BLOCK))
    return scales,codes


def join(scales,codes):
    return b"".join(scales[4*i:4*i+4]+codes[32*i:32*i+32] for i in range(len(scales)//4))


def packed_scales(scales):
    lo = min(scales)
    bits = (max(scales)-lo).bit_length()
    out = bytearray([lo,bits])
    for i in range(0,len(scales),8):
        v = sum((x-lo)<<(j*bits) for j,x in enumerate(scales[i:i+8]))
        out.extend(v.to_bytes(bits,"little"))
    return bytes(out)


def unpack_scales(payload,n):
    lo,bits = payload[:2]
    mask = (1<<bits)-1
    scales = bytearray()
    for i in range(n//8):
        v = int.from_bytes(payload[2+i*bits:2+(i+1)*bits],"little")
        scales.extend(lo+((v>>(bits*j)) & mask) for j in range(8))
    return bytes(scales),payload[2+(n//8)*bits:]


def sparse_bytes(codes):
    out = bytearray()
    for i in range(0,len(codes),8):
        group = codes[i:i+8]
        out.append(sum((v!=0)<<j for j,v in enumerate(group)))
        out.extend(v for v in group if v)
    return bytes(out)


def dense_bytes(data,n):
    it = iter(data)
    out = bytearray()
    while len(out)<n:
        mask = next(it)
        out.extend(next(it) if mask & (1<<j) else 0 for j in range(8))
    assert next(it,None) is None
    return bytes(out)


def codecs(raw):
    scales,codes = split(raw)
    frame = packed_scales(scales)
    practical = [raw, frame+codes, frame+sparse_bytes(codes)]
    split_deflate = zlib.compress(scales+codes, 6)
    def padded(n):
        return (n+15)//16*16
    # The top two bits of the per-expert 32-bit tile offset give the payload mode.
    # The raw tile size is implicit in the row/K dimensions; no cross-tile dictionary.
    mode = min(range(3), key=lambda i:padded(len(practical[i])))
    buf = practical[mode]
    decoded = buf
    if mode:
        scales_out,codes_out = unpack_scales(buf,len(scales))
        if mode == 2:
            codes_out = dense_bytes(codes_out,len(codes))
        decoded = join(scales_out,codes_out)
    digest = sha256(raw).digest()
    assert sha256(decoded).digest() == digest
    flat = zlib.decompress(split_deflate)
    assert sha256(join(flat[:len(scales)],flat[len(scales):])).digest() == digest
    return padded(len(buf)),min(len(raw),padded(len(split_deflate))),mode,digest


def entropy(counter):
    n=sum(counter.values())
    return -sum((v/n)*math.log2(v/n) for v in counter.values())


def evaluate(model, route_dir):
    start_time = time.monotonic()
    rng = random.Random(105)
    summary = defaultdict(Counter)
    hist = defaultdict(Counter)
    experts = defaultdict(Counter)
    hashes = sha256()
    footprint = Counter()
    sampled = 0
    with model.open("rb") as file, mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as data:
        h,tensors,base = metadata(data)
        m = "inkling2_loop."
        start,end,passes,nphys = (h[m+k] for k in ("loop.start","loop.end","loop.count","block_count"))
        physical = list(range(start))+list(range(start,end))*passes+list(range(end,nphys))
        assert len(tensors)==2*nphys and len(physical)==48
        for trace in ("lunch","handover"):
            with (route_dir/(trace+"-routes.csv")).open() as f:
                rows=list(csv.reader(f))
            if trace=="handover":
                rows=rows[1:]
            assert len(rows)==2*len(physical)
            for op,row in enumerate(rows):
                values=list(map(int,row))
                proj = ("gate_up","down")[op%2]
                name=f"blk.{physical[op//2]}.ffn_{proj}_exps.weight"
                (k,n,ne),offset=tensors[name]
                expert_bytes=k//64*n*BLOCK
                if trace=="lunch":
                    assert values[:3]==[op,k,n]
                    ids=set(values[3:])
                else:
                    assert values[:2]==[op,expert_bytes]
                    ids=set(values[2:])
                assert min(ids)>=0 and max(ids)<ne and n%64==0
                footprint[trace]+=expert_bytes*len(ids)
                samples=rng.sample(sorted(ids),2)
                for expert in samples:
                    row0=rng.randrange(n//64)*64
                    full,tail=divmod(k//64,8)
                    pieces=[(rng.randrange(full)*8,8,full)]
                    if tail:
                        pieces.append((full*8,tail,1))
                    for col,blocks,multiplicity in pieces:
                        tile=bytearray()
                        for r in range(row0,row0+64):
                            pos=base+offset+expert*expert_bytes+(r*k//64+col)*BLOCK
                            tile.extend(data[pos:pos+blocks*BLOCK])
                        assert len(tile)==64*blocks*BLOCK
                        scales,codes=split(tile)
                        hist["scales"].update(scales)
                        hist["packed_pairs"].update(codes)
                        hist["scale_pairs"].update(zip(scales[::2],scales[1::2]))
                        sampled+=len(tile)
                        for height in (16,64):
                            size=height*blocks*BLOCK
                            # Inverse inclusion probability for chosen experts, row bands and K tiles.
                            weight=len(ids)/len(samples)*(n//64)*multiplicity
                            table_per_tile=4+12/((n//height)*(full+bool(tail)))
                            for i in range(0,len(tile),size):
                                raw=bytes(tile[i:i+size])
                                practical,reference,mode,digest=codecs(raw)
                                hashes.update(digest)
                                group=summary[(trace,proj,height)]
                                group.update(raw=size*weight,practical=(practical+table_per_tile)*weight,
                                             deflate=(reference+table_per_tile)*weight,tiles_checked=1)
                                group["mode_"+str(mode)]+=1
                                if height==64:
                                    e=experts[(name,expert)]
                                    e.update(raw=size*weight,practical=(practical+table_per_tile)*weight)
    nibbles=Counter()
    for byte,count in hist["packed_pairs"].items():
        nibbles[byte&15]+=count
        nibbles[byte>>4]+=count
    variations=sorted(1-x["practical"]/x["raw"] for x in experts.values())
    result={f"{trace}-{proj}-{height}":dict(v) for (trace,proj,height),v in summary.items()}
    for trace,actual in footprint.items():
        for height in (16,64):
            assert abs(sum(summary[trace,proj,height]["raw"] for proj in ("gate_up","down"))-actual)<1
    return dict(footprint=footprint,groups=result,sampled_bytes=sampled,sampled_experts=len(experts),
                tensors=len(tensors),physical_expert_bytes=sum(math.prod(shape)*BLOCK//64 for shape,_ in tensors.values()),
                roundtrip_hash_stream=hashes.hexdigest(),entropy_bits=dict(nibble=entropy(nibbles),
                scale=entropy(hist["scales"]),packed_pair=entropy(hist["packed_pairs"]),
                scale_pair=entropy(hist["scale_pairs"])),nibble_counts=nibbles,scale_counts=hist["scales"],
                expert_saving_min_median_max=[variations[0],variations[len(variations)//2],variations[-1]],
                seconds=time.monotonic()-start_time)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("model",type=Path)
    p.add_argument("route_dir",type=Path)
    a=p.parse_args()
    print(json.dumps(evaluate(a.model,a.route_dir),indent=2))
