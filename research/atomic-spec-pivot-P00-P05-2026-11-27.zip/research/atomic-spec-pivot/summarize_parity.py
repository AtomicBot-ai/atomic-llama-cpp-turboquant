"""Pool verified P03 measurements and retain the first/last control separately."""
from collections import defaultdict
import json
from pathlib import Path
import re
import sys


def pooled(rows):
    ms = sum(r["timings"]["predicted_ms"] for r in rows)
    count = sum(r["timings"]["predicted_n"] for r in rows)
    return dict(requests=len(rows), emitted=count, tps=count*1000/ms,
                ms_per_update=ms/(count-len(rows)),
                mean_prompt_ms=sum(r["timings"]["prompt_ms"] for r in rows)/len(rows),
                total_http_s=sum(r["wall_s"] for r in rows))


def analyze(directory):
    results={}
    total_seconds=0
    for path in sorted(directory.glob("*.jsonl")):
        rows=[json.loads(line) for line in path.read_text().splitlines()]
        measured=[r for r in rows if r.get("warmup") is False]
        chat=next(r for r in measured if r["case"]=="sky-chat")
        fixed=[r for r in measured if r["case"]!="sky-chat"]
        assert len(fixed)==4 and all(r["timings"]["predicted_n"]==32 for r in fixed)
        by_case=defaultdict(list)
        for r in fixed:
            by_case[r["case"]].append(r)
        log=path.with_suffix(".log").read_text()
        stamps=re.findall(r"^(\d+)\.(\d+)\.(\d+)\.(\d+) ",log,re.M)
        def timestamp(s):
            m,sec,ms,us=map(int,s)
            return m*60+sec+ms/1000+us/1e6
        span=timestamp(stamps[-1])-timestamp(stamps[0]) if stamps else None
        total_seconds+=span or 0
        results[path.stem]=dict(fixed=pooled(fixed), by_case={c:pooled(rs) for c,rs in by_case.items()},
            chat=dict(**pooled([chat]),ttft_ms=chat["ttft_s"]*1000,finish=chat["finish"]),
            metrics=rows[-1]["metrics"],after_requests_gpu=rows[-1]["gpu"],
            graph_reuse=re.findall(r"graphs reused =\s*(\d+)",log),log_span_s=span)
    return dict(arms=results,aggregate_log_span_s=total_seconds)

if __name__=="__main__":
    print(json.dumps(analyze(Path(sys.argv[1])),indent=2))
