"""Matched target-only HTTP paths on the prepared Spark. Each label must be fresh."""
import argparse
import copy
import json
from pathlib import Path
import runpy
import subprocess
import time
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))

from inventory import OLD, S00, ROOT
from capture_s00 import file_hash, post, save, server, completion
from spark_window import exclusive

HERE = Path(__file__).resolve().parent
API = runpy.run_path(str(OLD/"bench.py"))
HTTP = API["BENCH"]
FIXTURE = {x["id"]:x["messages"] for line in (OLD/"prompts.jsonl").read_text(encoding="utf-8").splitlines()
           if (x := json.loads(line))}
FLAGS = {"mmq":"VERIFY_MMQ", "split":"SPLIT_GRAPH", "attention":"ATTENTION", "verify":"VERIFY"}


def config(mode):
    baseline = json.loads((S00/"capture-01/anchors/profile.json").read_text())["target"]
    if mode == "stock":
        with (OLD/"R00b-2-stock.jsonl").open() as f:
            return json.loads(next(f))
    c = copy.deepcopy(baseline)
    if mode != "A":
        c["env"].pop("GGML_CUDA_GRAPH_DEBUG")
    if mode in FLAGS:
        c["env"]["LLAMA_EXPERIMENTAL_SPARK_"+FLAGS[mode]] = "0"
    if mode == "standard":
        i = c["cmd"].index("--engine-budget-mib")
        del c["cmd"][i:i+2]
    return c


def make_paths(url):
    path = json.loads((S00/"capture-01/anchors/guides.json").read_text())["sky"]
    short = dict(prompt=path["prompt"], tokens=path["tokens"][:32])
    text = post(HTTP,url,"/apply-template",dict(messages=FIXTURE["briefing"]))["prompt"]
    ids = post(HTTP,url,"/tokenize",dict(content=text,add_special=True,parse_special=True))["tokens"]
    record = completion(HTTP,url,ids,42,32)
    assert record["timings"]["cache_n"] == 0 and len(record["tokens"]) == 32 and len(ids)>len(short["prompt"])
    return dict(sky=short, briefing=dict(prompt=ids,tokens=record["tokens"]))


def replay(url, path):
    ids = path["tokens"]
    grammar = "root ::= " + " ".join(f"<[{t}]>" for t in ids)
    start = time.perf_counter()
    response = post(HTTP,url,"/completion",dict(prompt=path["prompt"],temperature=1,seed=42,n_predict=len(ids),
                    grammar=grammar,cache_prompt=False,return_tokens=True,id_slot=0))
    wall = time.perf_counter()-start
    t = response["timings"]
    if (response["tokens"] != ids or t["prompt_n"] != len(path["prompt"]) or
        t["cache_n"] or t["predicted_n"] != len(ids) or t.get("draft_n")):
        raise ValueError(("fixed path mismatch",response["tokens"],t))
    return dict(tokens=response["tokens"],timings=t,wall_s=wall,stop=response["stop_type"])


def run(directory, modes, source):
    directory.mkdir(exist_ok=False)
    paths = json.loads(source.read_text()) if source else None
    with exclusive(directory):
        for n, mode in enumerate(modes):
            c = config(mode)
            assert file_hash(c["cmd"][0]) == c["sha256"] and "-md" not in c["cmd"]
            name = f"{n:02}-{mode}"
            print(name,flush=True)
            with server(HTTP,c,directory/(name+".log")) as url:
                if paths is None:
                    assert mode == "A"
                    paths = make_paths(url)
                save(directory/"paths.json", paths)
                with (directory/(name+".jsonl")).open("x") as f:
                    def emit(value):
                        f.write(json.dumps(value)+"\n")
                        f.flush()
                    emit(c)
                    with HTTP["HTTP"].open(url+"/props") as props:
                        settings = json.load(props)["default_generation_settings"]
                    emit(dict(default_settings=settings))
                    for iteration in range(3):
                        for case,path in paths.items():
                            emit(dict(case=case,iteration=iteration,warmup=iteration==0,**replay(url,path)))
                    for warm in (True,False):
                        row = API["measure"](url, dict(messages=FIXTURE["sky"],seed=42,temperature=1,
                                                  max_tokens=96,cache_prompt=False,stream=True))
                        emit(dict(case="sky-chat",warmup=warm,**row))
                    emit(dict(metrics=HTTP["engine_metrics"](url),gpu=subprocess.check_output(["nvidia-smi",
                            "--query-gpu=temperature.gpu,clocks.sm,power.draw,memory.used","--format=csv"],text=True)))
            print(name,"complete",flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("directory",type=Path)
    p.add_argument("modes",nargs="+",choices=("A","B",*FLAGS,"standard","stock"))
    p.add_argument("--paths",type=Path)
    a = p.parse_args()
    run(a.directory.resolve(), a.modes, a.paths)
