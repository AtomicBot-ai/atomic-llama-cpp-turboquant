"""Score static draft temperatures on the frozen S00 proposal paths."""
import json
import math
from pathlib import Path
from statistics import mean
import sys

S00 = Path(__file__).resolve().parents[1] / "atomic-spec"
sys.path.insert(0, str(S00))
from capture_s00 import bind, schedule

TRAIN = ("lunch", "python")
HOLD = ("sky", "reasoning")
TEMPS = (0.65, 0.8, 1.0, 1.25, 1.5)
EOG = {199999, 200006}  # target vocabulary in the R05 loader log


def probabilities(scores, temperature):
    peak = max(scores)
    values = [math.exp((s-peak)/temperature) for s in scores]
    return [v/sum(values) for v in values]


def measure(capture, temperature):
    previous = 0
    reach = 1.0
    overlap, weights, prior = [], [], []
    for row in capture["target"]:
        assert len({x for x, _, _ in row}) == len(row)
        assert all(math.isfinite(raw) and 0 < p <= 1.00001 for _, raw, p in row)
        assert abs(sum(p for _, _, p in row)-1) < 2e-4
        # With EOG in target support the bonus/correction could terminate early.
        assert EOG.isdisjoint(x for x, _, _ in row)
    for i, (token, lattice) in enumerate(zip(capture["proposals"], capture["lattice"], strict=True)):
        ids = lattice["ids"]
        assert len(set(ids)) == len(ids) == 16
        scores = lattice["scores"][16*previous:16*(previous+1)]
        old = lattice["sampled_path_q"]
        assert len(scores) == len(old) == 16 and all(math.isfinite(s) for s in scores)
        assert max(abs(a-b) for a,b in zip(old, probabilities(scores, 1))) < 2e-6
        assert min(old) > 0 and abs(sum(old)-1) < 2e-6
        p = {x:prob for x, _, prob in capture["target"][i]}
        new = probabilities(scores, temperature)
        previous = ids.index(token)
        prior.append(reach)
        overlap.append(sum(min(p.get(x, 0), q) for x,q in zip(ids,new)))
        reach *= min(p.get(token,0), new[previous]) / old[previous]
        weights.append(reach)
    return dict(weights=weights, overlap=overlap, prior=prior, observed=len(capture["emitted_ids"]))


def summarize(rows):
    depths = []
    for i in range(7):
        w = [r["weights"][i] for r in rows]
        total = sum(w)
        depths.append(dict(survival=mean(w), conditional_overlap=mean(r["overlap"][i] for r in rows),
                           ess=total**2/sum(x*x for x in w) if total else 0,
                           largest_share=max(w)/total if total else None))
    pairs = sorted((o,w) for r in rows for o,w in zip(r["overlap"],r["prior"]))
    total = sum(w for _,w in pairs)
    quantiles = []
    for q in (0.1,0.5,0.9):
        accumulated = 0
        for value, w in pairs:
            accumulated += w
            if accumulated >= total*q:
                quantiles.append(value)
                break
    return dict(anchors=len(rows), emitted_per_anchor=1+sum(d["survival"] for d in depths),
                observed_per_anchor=mean(r["observed"] for r in rows), depths=depths,
                reach_weighted_overlap_p10_p50_p90=quantiles)


def analyze():
    directory = S00/"capture-01/anchors"
    guides = json.loads((directory/"guides.json").read_text())
    sets = {**{k:(k,) for k in guides}, "train":TRAIN, "holdout":HOLD}
    results = {}
    for temp in TEMPS:
        rows = []
        for item in schedule():
            case, offset = item["case"], item["offset"]
            record = json.loads((directory/f"{case}-{offset:02}.json").read_text())
            assert record["anchor"] == bind(item,guides[case])
            assert guides[case]["settings"]["temperature"] == 1 and not guides[case]["settings"]["grammar"]
            rows.append((case,measure(record["capture"],temp)))
        results[temp] = {k:summarize([r for case,r in rows if case in cases]) for k,cases in sets.items()}
    selected = max(TEMPS, key=lambda t:results[t]["train"]["emitted_per_anchor"])
    return dict(train=TRAIN,holdout=HOLD,selected=selected,results=results)

if __name__ == "__main__":
    print(json.dumps(analyze(),indent=2,allow_nan=False))
