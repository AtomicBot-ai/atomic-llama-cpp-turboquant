"""Run read-only on the prepared Spark host."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path.home() / "inkling-spark"
OLD = ROOT / "blackwell-fast-1127"
S00 = ROOT / "atomic-spec-s00-1127-01"
sys.path.insert(0, str(S00))
from capture_s00 import CLEAN, DRAFT, TARGET, file_hash

def inventory():
    resident = json.loads((OLD / "resident-dflash2.json").read_text())
    with (S00 / "screen-01/2-df7-42.jsonl").open() as f:
        loaded = json.loads(next(f))
        requests = [r for line in f if (r := json.loads(line)).get("warmup") is False]
    assert loaded["cmd"] == resident["cmd"] and loaded["env"] == resident["env"]
    cmd = loaded["cmd"]
    assert resident["mode"] == "df7" and cmd[cmd.index("--spec-draft-n-max")+1] == "7"
    files = {cmd[0]: CLEAN, cmd[cmd.index("-m")+1]: TARGET, cmd[cmd.index("-md")+1]: DRAFT}
    hashes = {f: file_hash(f) for f in files}
    assert hashes == files and loaded["sha256"] == CLEAN
    assert all(r["expert_source_bytes"] == 0 for r in requests)
    query = "name,driver_version,temperature.gpu,power.draw,clocks.sm,utilization.gpu"
    gpu = subprocess.check_output(["nvidia-smi", "--query-gpu=" + query, "--format=csv"], text=True)
    return dict(resident=resident, hashes=hashes, gpu=gpu.splitlines(),
                baseline_source_bytes=[r["expert_source_bytes"] for r in requests])

if __name__ == "__main__":
    print(json.dumps(inventory(), indent=2))
