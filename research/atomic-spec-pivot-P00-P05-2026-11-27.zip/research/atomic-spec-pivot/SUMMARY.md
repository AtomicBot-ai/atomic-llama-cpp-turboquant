# Post-S02 acceleration sprint on PR 105

**Keep ordinary seven-proposal DFlash2.** The frozen two-chat control remains 53.87 emitted tokens/s. The tested calibration and compression mechanisms missed their gates. Fixed-path comparisons and the neighboring R08 qualification explain much of the target-only cost. Short-prompt scratch reuse improves time to first token on the ordinary managed target. No measured change in this sprint raised DFlash2 decode throughput.

| Stage | Decision | Evidence |
|---|---|---|
| [P00](P00.md) | Verified | Current target, draft and clean executable hashes match the frozen resident profile and the actual S01 launch. |
| [P01](P01.md) | NO-GO | The 0.8 temperature multiplier won on the training prompts but lost 0.23% estimated yield on the held-out prompts. |
| [P02](P02.md) | Skipped | No calibration candidate met its live-test gate. |
| [P03](P03.md) | GO for attribution | Fresh ordinary sky measured 45.80 vs 53.20 emitted tokens/s for frozen Atomic vs stock. The independent R08 fusion control accounted for 3.90 of 4.77 ms per update on its grammar-free fixture. The separate qualified short-prompt allocator change nearly halved first-token time. The two engines still use different CUDA/compiler toolchains. |
| [P04](P04.md) | NO-GO | SHA-256-verified tiles saved 6.08% on the logical weight footprint of two real route traces. Free decompression would project only +2.62% under the historical expert-phase cost model. |
| [P05](P05.md) | Skipped | No GPU compression prototype warranted. |

At 53.87 tokens/s a token takes 18.56 ms on average. At 100 tokens/s it must take 10 ms, a reduction of 46.1%. At 58.10 ms/round, that would require 5.81 emitted tokens per round against the observed 3.13. The measurements show no path to 100 tokens/s under the tested unchanged-weight and unchanged-drafter mechanisms. Cross-build residual latency and long-prompt prefill remain partly unattributed.

The clean timing, CPU analysis and archived neighboring measurements are identified in their respective reports. Scripts, raw parity requests, server logs, hash checks and the final service health record are included. All engine and model changes were outside this sprint. [Spark restoration](parity-01/restoration.json)
