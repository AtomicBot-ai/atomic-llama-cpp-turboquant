"""Generate one diagnostic translation unit from the frozen PR without editing engine sources."""
import argparse
import re
from pathlib import Path


def insert_probe(source):
    probe = Path(__file__).with_name("s00-probe.inc").read_text()
    hooks = {
        "struct server_context_impl {": probe + "\nstruct server_context_impl {\n    s00_probe s00;",
        "const int n_draft_max = slot.get_n_draft_max();":
            "const int n_draft_max = s00.at_anchor(slot) ? slot.get_n_draft_max() : 0;",
        "                common_speculative_draft(spec.get());":
            "                s00.start_us = ggml_time_us();\n                common_speculative_draft(spec.get());",
        "            slot.stats.n_draft_tokens += draft.size();":
            "            s00.draft(slot);\n            slot.stats.n_draft_tokens += draft.size();",
        "            const int64_t verify_start = measure_verify ? ggml_time_us() : 0;":
            """            const int64_t s00_target_start = s00.start_us && !s00.verified ? ggml_time_us() : 0;
            const int64_t verify_start = measure_verify ? ggml_time_us() : 0;""",
        "            if (measure_verify && ret == 0) {":
            """            if (s00_target_start && ret == 0) {
                s00.row["target_sync_us"] = ggml_time_us() - s00_target_start;
            }
            if (measure_verify && ret == 0) {""",
        "                ok = common_speculative_process(spec.get(), batch.view);":
            """                const int64_t inject_start = ggml_time_us();
                ok = common_speculative_process(spec.get(), batch.view);
                if (s00.start_us && !s00.verified) {
                    s00.row["draft_inject_call_us"] = ggml_time_us() - inject_start;
                }""",
        "            common_sampler_accept(slot.smpl.get(), id, true);":
            """            if (slot.stats.n_gen == 0) { s00.begin(slot); }
            if (size_t(slot.stats.n_gen) < s00.guide.size()) { id = s00.guide[slot.stats.n_gen]; }
            common_sampler_accept(slot.smpl.get(), id, true);""",
        "                    accepted = common_sampler_sample_and_accept_n_rejection(slot.smpl.get(), slot.ctx_tgt, spec_i_batch, slot.spec_draft, slot.spec_draft_q);":
            """                    llama_synchronize(slot.ctx_tgt);
                    const int64_t verify_start = ggml_time_us();
                    accepted = common_sampler_sample_and_accept_n_rejection(slot.smpl.get(), slot.ctx_tgt, spec_i_batch, slot.spec_draft, slot.spec_draft_q);
                    s00.after_verifier(slot, smpl_save.get(), spec_i_batch, accepted, t_decode_start, verify_start);""",
        "            slot.spec_is_replay = false;\n\n            slot.stats.update_gen_last();":
            "            const bool s00_replay = slot.spec_is_replay;\n            slot.spec_is_replay = false;\n\n            slot.stats.update_gen_last();",
        "            for (size_t i = 0; i < ids.size(); ++i) {\n                completion_token_output result;":
            """            GGML_ASSERT(s00.verified && s00.start_us);
            s00.finish(s00_replay);
            for (size_t i = 0; i < ids.size(); ++i) {
                completion_token_output result;""",
    }
    for old, new in hooks.items():
        if source.count(old) != 1:
            raise ValueError("Unexpected PR #105 source at hook: " + old)
        source = source.replace(old, new)
    return source


def private_rules(oracle_ninja, output):
    # Reuse the successful R04 link against the frozen Windows static libraries.
    rules = oracle_ninja.read_text()
    pattern = r"(?m)^(build [^\n]+server-oracle\.cpp\.obj: \S+ )(.+?[\\/]server-context\.cpp)(?= |$)"
    escaped = str(output.resolve()).replace("$", "$$").replace(":", "$:").replace(" ", "$ ")
    rules, count = re.subn(pattern, lambda m: m[1] + escaped, rules)
    if count != 1 or "llama-oracle.exe" not in rules or "oracle-state" not in rules:
        raise ValueError("Expected the frozen R04 oracle.ninja with one private server object")
    return rules.replace("server-oracle", "server-s00").replace("llama-oracle", "llama-s00").replace("oracle-state", "s00-state")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--oracle-ninja", type=Path, help="also write s00.ninja beside the generated source")
    args = parser.parse_args()
    rules = private_rules(args.oracle_ninja, args.output) if args.oracle_ninja else None
    source = insert_probe(args.source.read_text(encoding="utf-8"))
    with args.output.open("x", encoding="utf-8") as out:
        out.write(source)
    if rules:
        with args.output.with_name("s00.ninja").open("x", encoding="utf-8") as out:
            out.write(rules)
