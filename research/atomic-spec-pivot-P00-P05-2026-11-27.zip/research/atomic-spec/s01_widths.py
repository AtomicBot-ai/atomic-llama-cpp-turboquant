"""Historical fixed-width measurements and a two-width truncation replay (Python 3.10+)."""
import argparse
import json
import re
from itertools import product
from statistics import median
from zipfile import ZipFile

from read_s00 import read, records, traced_rounds


def measured(archive, stem):
    log = read(archive, stem + ".log")
    counts = re.findall(r"draft acceptance = .*?\(\s*(\d+) accepted /\s*(\d+) generated\), mean len =\s+([.\d]+)", log)
    rows = records(archive, stem + ".jsonl")
    result = {}
    for row, (a, offered, mean) in zip(rows[2:], counts, strict=True):
        if row["warmup"]:
            continue
        t = row["timings"]
        assert (int(a), int(offered)) == (t["draft_n_accepted"], t["draft_n"])
        steps, = [n for n in range(1, int(offered) + 1) if abs(1 + int(a)/n - float(mean)) <= .00500001]
        result[row["case"]] = dict(steps=steps, emitted=t["predicted_n"], decode_ms=t["predicted_ms"],
                                   ttft_s=row["ttft_s"], wall_s=row["wall_s"], finish=row["finish"],
                                   new_source_bytes=row["expert_source_bytes"])
    return result


def totals(rows):
    count = sum(r["emitted"] for r in rows)
    duration = sum(r["decode_ms"] for r in rows)
    steps = sum(r["steps"] for r in rows)
    return dict(tps=1000*count/duration, emitted_per_step=count/steps, ms_per_step=duration/steps,
                http_s=sum(r["wall_s"] for r in rows), ttft_median_s=median(r["ttft_s"] for r in rows))


def evaluate(accepts, widths, costs):
    tokens = sum(1 + min(a, w) for a, w in zip(accepts, widths, strict=True))
    ms = sum(costs[w] for w in widths)
    return dict(tokens=tokens, ms=ms, modeled_tps=1000*tokens/ms, short_count=widths.count(4))


def hindsight_choices(accepts, costs):
    # Cutting to four has the same saving in ms at every anchor of a prompt.
    # For each possible count of cuts, cut where the fewest tokens would be lost.
    order = sorted(range(len(accepts)), key=lambda i: max(0, accepts[i] - 4))
    widths = [7]*len(accepts)
    choices = [evaluate(accepts, widths, costs)]
    for i in order:
        widths[i] = 4
        choices.append(evaluate(accepts, widths, costs))
    return choices


def causal(accepts, threshold):
    # No previous round at the first anchor. Default to seven there.
    previous = None
    widths = []
    for recorded in accepts:
        width = 7 if previous is None or previous >= threshold else 4
        widths.append(width)
        previous = min(recorded, width)
    return widths


def analyze(archive):
    clean = {4: measured(archive, "R01-4-df4"), 7: measured(archive, "R00b-3-df7")}
    repeat = measured(archive, "R02-1-df7")
    summary = {w: {c: totals([r]) for c, r in by_case.items()} | {"pooled": totals(by_case.values())}
               for w, by_case in clean.items()}
    rounds = list(traced_rounds(archive))
    cases = list(clean[7])
    sequences = {c: [r["accepted"] for r in rounds if r["case"] == c and len(r["proposals"]) == 7] for c in cases}
    costs = {c: {w: summary[w][c]["ms_per_step"] for w in clean} for c in cases}
    proxy = {}
    for case, other in (("lunch", "sky"), ("sky", "lunch")):
        train = sequences[other]
        # Choose solely on the other prompt. Ties favor the lower threshold (longer width).
        threshold = max(range(9), key=lambda t: evaluate(train, causal(train, t), costs[other])["modeled_tps"])
        current = sequences[case]
        proxy[case] = dict(rounds=len(current), thresholds_trained_on=other, threshold=threshold,
                           fixed4=evaluate(current, [4]*len(current), costs[case]),
                           fixed7=evaluate(current, [7]*len(current), costs[case]),
                           previous=evaluate(current, causal(current, threshold), costs[case]),
                           oracle=max(hindsight_choices(current, costs[case]), key=lambda r: r["modeled_tps"]))
    matched = json.loads(read(archive, "R06-bandwidth.json"))["common_prefix_rounds"]
    footprints = {}
    for case in cases:
        path = [r for r in rounds if r["case"] == case]
        byte_count = emitted = 0
        for row in (r for r in matched if r["case"] == case):
            ref = path[row["round"]-1]
            assert row["target_us"] == ref["target_us"] and len(ref["proposals"]) == 7
            byte_count += row["bytes"]
            emitted += 1 + ref["accepted"]
        footprints[case] = dict(logical_bytes=byte_count, accepted_plus_one=emitted,
                                bytes_per_token=byte_count/emitted)
    pooled_proxy = {}
    for policy in ("fixed4", "fixed7", "previous"):
        rows = [r[policy] for r in proxy.values()]
        pooled_proxy[policy] = 1000*sum(r["tokens"] for r in rows)/sum(r["ms"] for r in rows)
    choices = [hindsight_choices(sequences[c], costs[c]) for c in cases]
    pooled_proxy["oracle"] = max(1000 * sum(r["tokens"] for r in combo) / sum(r["ms"] for r in combo)
                                 for combo in product(*choices))
    return dict(measured=clean, summary=summary, repeat7=totals(repeat.values()), truncation_proxy=proxy,
                pooled_proxy_tps=pooled_proxy, matched_width7_footprints=footprints)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    args = parser.parse_args()
    with ZipFile(args.archive) as archive:
        print(json.dumps(analyze(archive), indent=2))
