"""Summarize the five sequential launches in spark_window.py screen."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
from statistics import median


def summarize(directory):
    runs = defaultdict(list)
    files = sorted(directory.glob("[1-5]-*.jsonl"))
    assert len(files) == 5
    for path in files:
        meta, template, *requests = map(json.loads, path.read_text(encoding="utf-8").splitlines())
        mode = meta["mode"]
        log = path.with_suffix(".log").read_text(errors="replace")
        counts = re.findall(r"draft acceptance = .*?\(\s*(\d+) accepted /\s*(\d+) generated\), mean len =\s+([.\d]+)", log)
        assert len(requests) == 3 and requests[0]["warmup"]
        assert [r["case"] for r in requests[1:]] == ["lunch", "sky"]
        assert mode == "target" or len(counts) == len(requests)
        for i, r in enumerate(requests[1:], 1):
            t = r["timings"]
            assert not r["warmup"] and t["cache_n"] == 0
            row = dict(case=r["case"], seed=r["seed"], tokens=t["predicted_n"], decode_ms=t["predicted_ms"],
                       ttft_s=r["ttft_s"], wall_s=r["wall_s"], finish=r["finish"], visible=bool(r["answer"].strip()),
                       peak_bytes=r["metrics"]["budget_high_water_bytes"], new_source_bytes=r["expert_source_bytes"])
            if mode != "target":
                a, n, m = counts[i]
                assert (int(a), int(n)) == (t["draft_n_accepted"], t["draft_n"])
                steps = [j for j in range(1, int(n)+1) if abs(1+int(a)/j-float(m)) <= .00500001]
                assert steps
                row.update(accepted=int(a), offered=int(n), steps_min=min(steps), steps_max=max(steps))
            runs[mode].append(row)

    def pool(rows):
        tokens = sum(r["tokens"] for r in rows)
        ms = sum(r["decode_ms"] for r in rows)
        data = dict(emitted=tokens, tps=1000*tokens/ms, decode_ms=ms, wall_s=sum(r["wall_s"] for r in rows),
                    median_ttft_ms=1000*median(r["ttft_s"] for r in rows))
        if "steps_min" in rows[0]:
            bounds = [sum(r[key] for r in rows) for key in ("steps_min", "steps_max")]
            data.update(steps=bounds, ms_per_step=[ms/n for n in bounds[::-1]],
                        emitted_per_step=[tokens/n for n in bounds[::-1]])
        return data

    summary = {mode: {c: pool([r for r in rows if r["case"]==c]) for c in ("lunch","sky")} | {"pooled":pool(rows)}
               for mode, rows in runs.items()}
    ratios = {case: summary["df4"][case]["tps"]/summary["df7"][case]["tps"] for case in summary["df4"]}
    return dict(requests=runs, summary=summary, df4_over_df7=ratios)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    print(json.dumps(summarize(parser.parse_args().directory), indent=2))
