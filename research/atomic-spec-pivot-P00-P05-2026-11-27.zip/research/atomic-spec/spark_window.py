"""Run the S00/S01 screen on the prepared, idle Spark, restoring the registered service."""
import argparse
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from contextlib import contextmanager

ROOT = Path.home() / "inkling-spark"
OLD = ROOT / "blackwell-fast-1127"
LAB = ROOT / "indexed-fa-1127-ab01/baseline"
HERE = Path(__file__).resolve().parent


def build():
    subprocess.run([sys.executable, str(HERE/"prepare_s00.py"), str(LAB/"src/tools/server/server-context.cpp"),
                    str(HERE/"s00-context.cpp"), "--oracle-ninja", str(LAB/"build/oracle.ninja")], check=True)
    # Keep the ARM64 compiler, SDK and CRT settings of the frozen R04 build.
    prefix, marker, _ = (LAB/"build.cmd").read_text().partition("cmake -S")
    if not marker or 'cd /d "%~dp0"' not in prefix:
        raise ValueError("Unexpected Spark build environment")
    prefix = prefix.replace('cd /d "%~dp0"', f'cd /d "{LAB}"')
    script = HERE/"build-s00.cmd"
    script.write_text(prefix + f'ninja -C build -f "{HERE / "s00.ninja"}" -j 2 bin\\llama-s00.exe\nexit /b %errorlevel%\n')
    subprocess.run(["cmd", "/c", str(script)], check=True)


@contextmanager
def exclusive(out):
    launcher = OLD/"serve-loopback.py"
    service = runpy.run_path(str(launcher))["load"]()
    state = json.loads((ROOT/"results/source-rollback-retain-20261125/manual-instance.json").read_bytes())
    cmd, _ = service["prepare"]()
    pid, exe = state["pid"], Path(cmd[0])
    if not (Path(state["launcher"]) == launcher and cmd == state["cmd"] and service["owner"]() == pid
            and service["pid_path"](pid) == exe):
        raise RuntimeError("Registered service has changed. No process stopped.")
    busy = service["ps"]("Get-Process -ErrorAction SilentlyContinue | Where-Object { ($_.ProcessName -match 'llama|^cl$|^nvcc$|^ninja$') -and $_.Id -ne "
                         + str(int(pid)) + " } | Select-Object -ExpandProperty ProcessName")
    if busy:
        raise RuntimeError(f"Other work on the stand: {busy}")
    service["idle"]()
    service["stop"](pid, exe)
    try:
        yield
    finally:
        service["launch"](launcher, ["serve"])
        restored = service["ready"](exe, pid)
        if restored["cmd"] != cmd or restored["sha256"] != state["sha256"]:
            raise RuntimeError("Restored service differs from the registered one")
        (out/"restoration.json").write_text(json.dumps(dict(url=restored["url"], pid=restored["pid"],
                                                      sha256=restored["sha256"], health="ok")))
        print("Restored", restored["url"], restored["pid"], flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=["build", "screen", "capture"])
    p.add_argument("directory", type=Path, nargs="?")
    a = p.parse_args()
    if a.action == "build":
        build()
    else:
        out = a.directory.resolve()
        out.mkdir(exist_ok=False)
        os.environ["PYTHONUTF8"] = "1"
        with exclusive(out):
            if a.action == "capture":
                subprocess.run([sys.executable, str(HERE/"capture_s00.py"), "collect", str(OLD),
                                str(LAB/"build/bin/llama-s00.exe"), str(out/"anchors")], check=True)
            else:
                run = runpy.run_path(str(OLD/"bench.py"))["run"]
                for i, (mode, seed) in enumerate([("target", 42), ("df7", 42), ("df4", 42),
                                                   ("df4", 43), ("df7", 43)], 1):
                    run(mode, out/f"{i}-{mode}-{seed}.jsonl", ["lunch", "sky"], [seed], 192)
