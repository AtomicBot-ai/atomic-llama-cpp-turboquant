"""Screen prefix trees on saved target-only continuations. No inference or policy access to future IDs."""
import argparse
import heapq
import json
import math
from pathlib import Path

from capture_s00 import CASES, bind, check, schedule

TRAIN = ("lunch", "python")
HOLDOUT = ("sky", "reasoning")


def choices(lattice, depth, previous):
    row = lattice[depth]
    ids = row["ids"]
    k = len(ids)
    scores = row["scores"][previous*k:(previous+1)*k]
    peak = max(scores)
    log_norm = peak + math.log(sum(math.exp(s-peak) for s in scores))
    return sorted(((log_norm-s, token, i) for i, (s, token) in enumerate(zip(scores, ids, strict=True))))


def build(lattice, budget, policy):
    # The empty tuple is the already sampled anchor. Heap keys accumulate negative log scores.
    nodes = {()}
    queue = [(0.0, (), 0)]
    while len(nodes) < budget and queue:
        cost, prefix, prev = heapq.heappop(queue)
        nodes.add(prefix)
        depth = len(prefix)
        if len(nodes) == budget or depth == len(lattice) or (policy == "shallow" and depth == 3):
            continue
        children = choices(lattice, depth, prev)
        if policy == "linear":
            children = children[:1]
        if policy == "shallow":
            children = children[:2]
        for edge, token, idx in children:
            heapq.heappush(queue, (cost + edge, prefix + (token,), idx))
    assert len(nodes) == budget and all(p[:-1] in nodes for p in nodes if p)
    return nodes


def coverage(nodes, future):
    for depth in range(1, len(future)+1):
        if tuple(future[:depth]) not in nodes:
            return depth  # includes mismatch correction or the leaf bonus
    return len(future)


def analyze(directory, live):
    guides = json.loads((directory/"guides.json").read_text())
    records = []
    for item in schedule():
        case, offset = item["case"], item["offset"]
        anchor = bind(item, guides[case])
        if anchor is None:
            continue
        data = json.loads((directory/f"{case}-{offset:02}.json").read_text())
        capture = data["capture"]
        check(anchor == data["anchor"] and capture["key"] == anchor["prefix_sha256"]+"-capture",
              "capture/trajectory mismatch")
        check(guides[case]["finish"] == "limit", "check EOS accounting before using shorter trajectories")
        records.append((case, offset, capture["lattice"], anchor["future"], len(capture["emitted_ids"])))
    assert len(records) == json.loads((directory/"complete.json").read_text())["captured"]
    costs = {nodes: live["summary"][mode]["pooled"]["ms_per_step"][0] for nodes, mode in ((5, "df4"), (8, "df7"))}
    results = {}
    for budget in (4, 5, 6, 8):
        for policy in ("linear", "shallow", "best_first"):
            by_case = {c: [] for c in CASES}
            for case, _, lattice, future, _ in records:
                by_case[case].append(coverage(build(lattice, budget, policy), future))
            results[f"{budget}-{policy}"] = by_case
    def total(key, cases):
        return sum(sum(results[key][c]) for c in cases)

    # Choose on two prompts. Restrict cost-based selection to budgets with live width timings.
    candidates = [(n, p) for n in costs for p in ("shallow", "best_first")]
    n, policy = max(candidates, key=lambda pair: total(f"{pair[0]}-{pair[1]}", TRAIN)/costs[pair[0]])
    key = f"{n}-{policy}"
    y = total(key, HOLDOUT)
    actual = sum(emitted for case, _, _, _, emitted in records if case in HOLDOUT)
    absolute_bound = {}
    for case, _, lattice, future, _ in records:
        depth = 0
        for row, token in zip(lattice, future):
            if token not in row["ids"]:
                break
            depth += 1
        absolute_bound[case] = absolute_bound.get(case, 0) + 1 + depth
    count = sum(case in HOLDOUT for case, *_ in records)
    return dict(train=TRAIN, holdout=HOLDOUT, anchors=len(records), selected=key, live_linear_ms=costs,
                emitted_by_anchor=results, hindsight_lattice_bound_8_nodes=absolute_bound,
                held_out=dict(anchors=count, tree_emitted=y, same_rule_linear_emitted=total(f"{n}-linear",HOLDOUT),
                              observed_rejection_emitted=actual, tree_over_linear=y/total(f"{n}-linear",HOLDOUT),
                              rate_ratio_vs_rejection={str(extra): (y/actual)*costs[8]/(costs[n]+extra) for extra in (0,2,5,10)},
                              max_tree_ms_for_15pct_gain=(y/actual)*costs[8]/1.15))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("capture_directory",type=Path)
    p.add_argument("--live",type=Path,default=Path(__file__).with_name("S01-live.json"))
    args = p.parse_args()
    print(json.dumps(analyze(args.capture_directory, json.loads(args.live.read_text())),indent=2))
