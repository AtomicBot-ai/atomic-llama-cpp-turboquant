"""Collect matched target-only prefixes and a private DFlash2 diagnostic, in separate processes."""
import argparse
import hashlib
import json
import math
import os
import runpy
import subprocess
import tempfile
from contextlib import contextmanager
from pathlib import Path

CASES = ("lunch", "sky", "python", "reasoning")
OFFSETS = range(0, 41, 8)
HORIZON = 8
GUIDE_SEED = 42
TEMPLATE = "a04653367fbabaf38e91c426b8572ec18b1342dee6675caa8ce9564b6877da94"
TARGET = "c271770860619fcf2908262070a40e9cd656f82c9650f41415d7558722957759"
DRAFT = "0dde9db3881f6874d45f0d48b75545e00ee69776ffffe0b479cacce529e3c230"
CLEAN = "1c228252e6e076a63e119bc727991f009a8ad1cecaf996ffe5e1840fab2fd946"
FIXTURE = "dcdda86893ca44a98379bb53431e45fac4bca51d8fa7f5bd75d9784b6c0e1d54"
CAP = 20580 << 20


def check(condition, message):
    if not condition:
        raise ValueError(message)


def digest_json(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":"), sort_keys=True).encode()).hexdigest()


def file_hash(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 22), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path, record):
    # Publish only complete JSON. The caller owns a fresh output directory.
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, separators=(",", ":"), allow_nan=False), encoding="utf-8")
    tmp.replace(path)


def schedule():
    return [dict(case=case, offset=offset, probe_seed=42000 + 100*i + offset)
            for i, case in enumerate(CASES) for offset in OFFSETS]


def bind(item, trajectory):
    i = item["offset"]
    path = trajectory["tokens"]
    if i + 1 + HORIZON > len(path):
        return None
    prompt = trajectory["prompt"]
    guide = path[:i+1]
    return dict(**item, guide_seed=GUIDE_SEED, prompt=prompt, guide=guide, anchor=guide[-1],
                prefix_sha256=digest_json(prompt + guide), future=path[i+1:i+1+HORIZON])


def validate(row, response, anchor, key, inspect):
    prompt, guide = anchor["prompt"], anchor["guide"]
    check(row["key"] == key and row["pos"] == len(prompt) + len(guide) - 1, "wrong capture identity/position")
    generated = response["tokens"]
    check(generated[:len(guide)] == guide and row["anchor"] == guide[-1], "replayed prefix differs")
    check(response["timings"]["prompt_n"] == len(prompt) and response["timings"]["cache_n"] == 0,
          "incomplete or cached prompt")
    proposals, ids = row["proposals"], row["verifier_ids"]
    accepted = len(ids)-1
    check(len(proposals) == 7 and 0 <= accepted <= 7 and ids[:-1] == proposals[:accepted],
          "invalid verification prefix")
    emitted = generated[len(guide):len(guide)+len(ids)]
    check(emitted and emitted == ids[:len(emitted)], "HTTP output differs from verifier")
    check(len(emitted) == len(ids) or response["stop_type"] == "eos", "unexpected partial round")
    row.update(emitted_ids=emitted, accepted_proposals=accepted,
               first_rejected_index=accepted if accepted < 7 else None)
    check(row["start_to_trim_us"] >= row["draft_call_us"] > 0 and
          0 <= row["inspection_us"] <= row["start_to_trim_us"] and
          0 < row["target_sync_us"] <= row["submit_to_sync_us"] and row["draft_inject_call_us"] >= 0 and
          row["verifier_us"] >= 0, "invalid round timing")
    if not inspect:
        check("lattice" not in row and "target" not in row, "unexpected capture in timing control")
        return
    check(len(row["lattice"]) == 7 and len(row["target"]) == 8, "missing evaluated rows")
    prev = 0
    for depth, (proposal, position) in enumerate(zip(proposals, row["lattice"], strict=True)):
        ids, scores, q = position["ids"], position["scores"], position["sampled_path_q"]
        check(len(set(ids)) == len(ids) == len(q) == 16 and len(scores) == (16 if depth == 0 else 256)
              and all(math.isfinite(s) for s in scores), "invalid selector shape/scores")
        selected = scores[16*prev:16*(prev+1)]
        mass = [math.exp(s-max(selected)) for s in selected]  # frozen temperature 1
        total = sum(mass)
        check(all(abs(a/total-b) <= 2e-5 for a, b in zip(mass, q)), "wrong predecessor row or temperature")
        prev = ids.index(proposal)
    for support in row["target"]:
        check(0 < len(support) <= 64 and len({item[0] for item in support}) == len(support)
              and all(math.isfinite(logit) and 0 < p <= 1.00001 for _, logit, p in support)
              and abs(sum(item[2] for item in support)-1) < 2e-4, "invalid post-sampler target support")


def post(api, url, route, payload):
    with api["post"](url + route, payload) as r:
        return json.load(r)


@contextmanager
def server(api, config, log, control=None):
    env = {k: v for k, v in os.environ.items() if not k.startswith(("LLAMA_", "GGML_", "INKLING_", "ATOMIC_S00_"))}
    env.update(config["env"])
    if control:
        env["ATOMIC_S00_CONTROL"] = str(control)
    cuda = Path(os.environ["ProgramFiles"]) / "NVIDIA GPU Computing Toolkit/CUDA/v13.4/bin/arm64"
    env["PATH"] = str(cuda) + os.pathsep + env["PATH"]
    with log.open("x") as f:
        proc = subprocess.Popen(config["cmd"], env=env, stdout=f, stderr=subprocess.STDOUT)
        try:
            url = api["wait_ready"](proc, log)
            with api["HTTP"].open(url+"/props") as r:
                template = json.load(r)["chat_template"]
            check(hashlib.sha256(template.encode()).hexdigest() == TEMPLATE, "template hash mismatch")
            yield url
        finally:
            if proc.poll() is None:
                proc.terminate()
            proc.wait()


def completion(api, url, prompt, seed, n):
    return post(api, url, "/completion", dict(prompt=prompt, temperature=1, seed=seed, n_predict=n,
                                              cache_prompt=False, return_tokens=True, id_slot=0))


def run(args):
    root = Path.home()/"inkling-spark/indexed-fa-1127-ab01/baseline"
    api = runpy.run_path(str(root/"src/tools/expert-source/bench-inkling-metal.py"))
    fixture = {r["id"]: r["messages"] for r in map(json.loads, (args.archive_dir/"prompts.jsonl").read_text(encoding="utf-8").splitlines())}
    check(digest_json({c: fixture[c] for c in CASES}) == FIXTURE, "prompt fixture mismatch")
    spec = json.loads((args.archive_dir/"resident-dflash2.json").read_text())
    with (args.archive_dir/"R00b-1-target.jsonl").open() as f:
        target = json.loads(next(f))
    args.out.mkdir(parents=True, exist_ok=False)
    for cfg in (target, spec):
        cmd = cfg["cmd"]
        check(cfg["sha256"] == CLEAN and cmd[cmd.index("--host")+1] == "127.0.0.1" and
              cmd[cmd.index("--port")+1] == "0" and cmd[cmd.index("-np")+1] == "1", "unexpected frozen profile")
    check("-md" not in target["cmd"] and "--spec-type" not in target["cmd"], "guide is not target-only")
    check(spec["cmd"][spec["cmd"].index("--spec-draft-n-max")+1] == "7" and
          spec["env"]["LLAMA_EXPERIMENTAL_SPARK_BLOCK_VERIFY"] == "0", "unexpected verifier")
    model = target["cmd"][target["cmd"].index("-m")+1]
    check(model == spec["cmd"][spec["cmd"].index("-m")+1] and file_hash(model) == TARGET, "target weight mismatch")
    check(file_hash(spec["cmd"][spec["cmd"].index("-md")+1]) == DRAFT, "draft weight mismatch")
    check(file_hash(target["cmd"][0]) == CLEAN, "clean binary mismatch")
    spec["cmd"][0] = str(args.probe.resolve(strict=True))
    spec["sha256"] = file_hash(args.probe)
    check(spec["sha256"] != CLEAN, "capture requires the private executable")
    save(args.out/"profile.json", dict(target=target, diagnostic=spec, target_sha256=TARGET,
                                       draft_sha256=DRAFT, template_sha256=TEMPLATE, fixture_sha256=FIXTURE, schedule=schedule()))
    trajectories = {}
    with server(api, target, args.out/"guide.log") as url:
        for case in CASES:
            rendered = post(api, url, "/apply-template", {"messages": fixture[case]})["prompt"]
            prompt = post(api, url, "/tokenize", dict(content=rendered, add_special=True, parse_special=True))["tokens"]
            r = completion(api, url, prompt, GUIDE_SEED, 1+max(OFFSETS)+HORIZON)
            t = r["timings"]
            check(t["prompt_n"] == len(prompt) and not t["cache_n"] and not t.get("draft_n") and
                  t["predicted_n"] == len(r["tokens"]), "invalid target-only trajectory")
            trajectories[case] = dict(prompt=prompt, tokens=r["tokens"], settings=r["generation_settings"],
                                      finish=r["stop_type"], timings=t)
    save(args.out/"guides.json", trajectories)
    anchors = [anchor for item in schedule() if (anchor := bind(item, trajectories[item["case"]]))]
    check(len(anchors) >= 16 and {a["case"] for a in anchors} == set(CASES), "insufficient frozen guide coverage")
    with tempfile.TemporaryDirectory(dir=args.out) as tmp:
        control = Path(tmp)/"control.json"
        result = Path(tmp)/"result.json"
        with server(api, spec, args.out/"diagnostic.log", control) as url:
            for anchor in anchors:
                pair = []
                for inspect in ([False, True] if anchor["offset"] == 0 else [True]):
                    key = anchor["prefix_sha256"] + ("-capture" if inspect else "-control")
                    if result.exists():
                        result.unlink()
                    save(control, dict(key=key, inspect=inspect, output=str(result),
                                       prompt=anchor["prompt"], guide=anchor["guide"]))
                    before = api["engine_metrics"](url)
                    r = completion(api, url, anchor["prompt"], anchor["probe_seed"], len(anchor["guide"])+8)
                    after = api["engine_metrics"](url)
                    check(after["budget_applied_bytes"] == CAP and 0 < after["budget_high_water_bytes"] <= CAP and
                          after["expert_logical_read_bytes"] == before["expert_logical_read_bytes"], "nonresident run")
                    row = json.loads(result.read_text())
                    validate(row, r, anchor, key, inspect)
                    row.update(stop=r["stop_type"], timings=r["timings"], peak_bytes=after["budget_high_water_bytes"])
                    pair.append(row)
                if len(pair) == 2:
                    check(all(pair[0][k] == pair[1][k] for k in ("anchor", "proposals", "verifier_ids", "emitted_ids")),
                          "inspection changed this trajectory")
                save(args.out/f'{anchor["case"]}-{anchor["offset"]:02}.json',
                     dict(anchor=anchor, capture=pair[-1], timing_control=pair[0] if len(pair)==2 else None))
    save(args.out/"complete.json", {"planned": len(schedule()), "captured": len(anchors)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("plan", help="print the predetermined schedule without accessing a server")
    collect = sub.add_parser("collect", help="use only during an exclusive Spark window")
    collect.add_argument("archive_dir", type=Path)
    collect.add_argument("probe", type=Path)
    collect.add_argument("out", type=lambda p: Path(p).resolve())
    args = parser.parse_args()
    if args.command == "plan":
        print(json.dumps(schedule(), indent=2))
    else:
        run(args)
