"""Extract S00 evidence from the frozen R00–R07 review ZIP. Writes JSONL to stdout."""
import argparse
import json
import re
from collections import defaultdict
from statistics import median
from zipfile import ZipFile


def read(archive, name):
    return archive.read("research/blackwell-fast/" + name).decode()


def records(archive, name):
    return [json.loads(line) for line in read(archive, name).splitlines()]


def oracle_anchors(archive):
    rows = records(archive, "oracle-resume.jsonl")
    guides = {row["case"]: row["guide"] for row in rows if "guide" in row}
    for row in rows:
        if "alternatives" not in row:
            continue
        a, b = row["alternatives"]
        assert [a["rank"], b["rank"]] == [0, 1]
        assert a["anchor"] == b["anchor"] and a["tokens"] == b["tokens"]
        alternatives = []
        for path in (a, b):
            rank = path["rank"]
            assert len(path["routes"]) == 96
            footprint = sum(stride * len(set(ids)) for _, stride, *ids in path["routes"])
            alternatives.append(dict(token=path["tokens"][rank], original_q=path["q"][rank],
                                     target_p=path["p"], eos=path["candidate_eos"],
                                     logical_expert_weight_bytes=footprint))
        offset = row["offset"]
        guide = guides[row["case"]]
        yield dict(case=row["case"], guide_offset=offset, anchor=a["anchor"],
                   guide_token=guide[offset], candidates=alternatives)


def traced_rounds(archive):
    stem = "graph05-1-trace-df7"
    log = read(archive, stem + ".log")
    accepts = {int(i): (int(a), int(n)) for i, a, n in
               re.findall(r"^ROUND_ACCEPT (\d+) (\d+) (\d+)", log, re.M)}
    positions = {int(i): int(pos) for i, pos in re.findall(r"^ROUND_INPUT (\d+) (\d+)", log, re.M)}
    for row in json.loads(read(archive, stem + ".graphs.json")):
        index = row["idx"]
        anchor, *proposals = row["tokens"]
        accepted, offered = accepts[index] if proposals else (None, 0)
        assert offered == len(proposals) and (accepted is None or 0 <= accepted <= offered)
        yield dict(case=("lunch", "sky")[row["request"]], round_id=index, pos=positions[index],
                   anchor=anchor, proposals=proposals, accepted=accepted, target_us=row["target_us"],
                   expert_kernel_us=round(row["expert_us"], 3))


def baseline(archive):
    groups = defaultdict(list)
    for stem in ("qual-2-df7@42", "qual-5-df7@43"):
        counts = re.findall(r"draft acceptance = .*?\(\s*(\d+) accepted /\s*(\d+) generated\), mean len =\s+([.\d]+)",
                            read(archive, stem + ".log"))
        for row, (accepted, proposed, mean) in zip(records(archive, stem + ".jsonl")[2:], counts, strict=True):
            if row["warmup"]:
                continue
            # The server prints 1 + accepted/steps to two decimal places.
            steps = [i for i in range(1, int(proposed) + 1) if abs(1 + int(accepted)/i - float(mean)) <= .00500001]
            assert len(steps) == 1
            item = (row["timings"]["predicted_n"], row["timings"]["predicted_ms"], steps[0],
                    row["ttft_s"], row["wall_s"])
            groups[row["case"]].append(item)
            groups["pooled"].append(item)
    for case, rows in groups.items():
        assert len(rows) == (12 if case == "pooled" else 2)
        emitted, ms, steps, ttft, wall = zip(*rows)
        yield dict(case=case, tokens=sum(emitted), steps=sum(steps), tps=1000*sum(emitted)/sum(ms),
                   emitted_per_step=sum(emitted)/sum(steps), ms_per_step=sum(ms)/sum(steps),
                   median_ttft_s=median(ttft), wall_s=sum(wall))


if __name__ == "__main__":
    sources = {"baseline": baseline, "anchors": oracle_anchors, "rounds": traced_rounds}
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    parser.add_argument("dataset", choices=sources)
    args = parser.parse_args()
    with ZipFile(args.archive) as archive:
        for record in sources[args.dataset](archive):
            print(json.dumps(record, separators=(",", ":")))
