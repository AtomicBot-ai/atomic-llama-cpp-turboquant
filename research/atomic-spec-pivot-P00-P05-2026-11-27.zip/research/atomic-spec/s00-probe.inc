// Included in a private copy of server-context.cpp by prepare_s00.py.
struct s00_probe {
    json control;
    llama_tokens guide;
    json row;
    int64_t start_us = 0;
    int64_t inspect_us = 0;
    bool verified = false;

    void begin(const server_slot & slot) {
        const char * path = std::getenv("ATOMIC_S00_CONTROL");
        GGML_ASSERT(path && *path);
        std::ifstream file(path);
        std::string line;
        GGML_ASSERT(std::getline(file, line));
        control = json::parse(line);
        guide = control.at("guide").get<llama_tokens>();
        GGML_ASSERT(!guide.empty() && guide.size() <= 41);
        GGML_ASSERT(slot.prompt.tokens.get_text_tokens() == control.at("prompt").get<llama_tokens>());
        GGML_ASSERT(slot.id == 0 && slot.ctx_dft && slot.use_spec_rejection());
        row = {{"key", control.at("key")}, {"anchor", guide.back()}};
        start_us = inspect_us = 0;
        verified = false;
    }

    bool at_anchor(const server_slot & slot) const {
        return size_t(slot.stats.n_gen) == guide.size();
    }

    void draft(const server_slot & slot) {
        GGML_ASSERT(slot.sampled == guide.back() && slot.spec_draft.size() == 7 && slot.spec_draft_q.size() == 7);
        const auto now = ggml_time_us();
        row["draft_call_us"] = now - start_us;
        row["proposals"] = slot.spec_draft;
        row["pos"] = slot.prompt.tokens.pos_next();
        if (control.at("inspect").get<bool>()) {
            const auto * model = llama_get_model(slot.ctx_dft);
            const int k = llama_model_dflash_selector_top_k(model);
            const int stride = llama_model_n_embd(model);
            GGML_ASSERT(k == 16 && stride >= k + k*k);
            const float * lattice = llama_get_embeddings_nextn(slot.ctx_dft);
            GGML_ASSERT(lattice);
            for (int i = 0; i < 7; ++i) {
                const float * block = lattice + (i + 1)*stride;
                const auto & chosen = slot.spec_draft_q[i];
                GGML_ASSERT(chosen.size() == size_t(k));
                llama_tokens ids;
                std::vector<float> q;
                for (int j = 0; j < k; ++j) {
                    GGML_ASSERT(chosen[j].id == (llama_token) block[j]);
                    ids.push_back(chosen[j].id);
                    q.push_back(chosen[j].p);
                }
                // Row zero is sufficient at the first position (one anchor predecessor).
                const int n_scores = i == 0 ? k : k*k;
                row["lattice"].push_back({{"ids", ids}, {"scores", std::vector<float>(block+k, block+k+n_scores)},
                                          {"sampled_path_q", q}});
            }
        }
        inspect_us += ggml_time_us() - now;
    }

    void after_verifier(const server_slot & slot, common_sampler * saved, const std::vector<int> & indices,
                        const llama_tokens & result, int64_t target_submit, int64_t verify_start) {
        const int64_t now = ggml_time_us();
        row["submit_to_sync_us"] = verify_start - target_submit;
        row["verifier_us"] = now - verify_start;
        row["verifier_ids"] = result;
        if (control.at("inspect").get<bool>()) {
            common_sampler_ptr shadow(common_sampler_clone(saved));
            for (size_t i = 0; i < indices.size(); ++i) {
                common_sampler_sample(shadow.get(), slot.ctx_tgt, indices[i]);
                const auto * p = common_sampler_get_candidates(shadow.get(), false);
                const float * raw = llama_get_logits_ith(slot.ctx_tgt, indices[i]);
                GGML_ASSERT(raw);
                json support = json::array();
                for (size_t j = 0; j < p->size; ++j) {
                    const auto & item = p->data[j];
                    if (item.p > 0) {
                        support.push_back(json::array({item.id, raw[item.id], item.p}));
                    }
                }
                GGML_ASSERT(!support.empty() && support.size() <= 64);
                row["target"].push_back(std::move(support));
                if (i < slot.spec_draft.size()) {
                    common_sampler_accept(shadow.get(), slot.spec_draft[i], true);
                }
            }
        }
        inspect_us += ggml_time_us() - now;
        verified = true;
    }

    void finish(bool replay) {
        row["checkpoint_replay"] = replay;
        row["start_to_trim_us"] = ggml_time_us() - start_us;
        row["inspection_us"] = inspect_us;
        std::ofstream file(control.at("output").get<std::string>(), std::ios::binary);
        file << row.dump() << '\n';
        file.close();
        GGML_ASSERT(file.good());
        start_us = 0;
    }
};
