"""Leave one prompt out when scoring captured lattices. All speed estimates are truncation proxies."""
import argparse
import json
import math
from pathlib import Path

from capture_s00 import CASES, bind, check, schedule


def features(lattice):
    # Follow the greedy selector before any RNG draw. Width seven costs three
    # extra verification rows after width four, but reaching them needs the prefix too.
    prev = 0
    log_peak = entropy = gap = 0.0
    for row in lattice:
        scores = row["scores"][16*prev:16*(prev+1)]
        high = max(scores)
        masses = [math.exp(s-high) for s in scores]
        norm = sum(masses)
        p = [m/norm for m in masses]
        first, second = sorted(p, reverse=True)[:2]
        log_peak += math.log(first)
        gap += first-second
        entropy -= sum(x*math.log(x) for x in p if x)
        prev = scores.index(high)
    n = len(lattice)
    return dict(geometric_peak=math.exp(log_peak/n), concentration=1-entropy/(n*math.log(16)), gap=gap/n)


def score(rows, feature, cutoff, cost):
    ms = tokens = wide = 0
    for f, accepted, emitted in rows:
        width = 7 if f[feature] >= cutoff else 4
        tokens += min(emitted, 1 + min(width, accepted))
        ms += cost[width]
        wide += width == 7
    return dict(anchors=len(rows), width7=wide, tokens=tokens, modeled_ms=ms, modeled_tps=1000*tokens/ms)


def analyze(directory, width_data):
    complete = json.loads((directory/"complete.json").read_text())
    guides = json.loads((directory/"guides.json").read_text())
    rows = {case: [] for case in CASES}
    for item in schedule():
        anchor = bind(item, guides[item["case"]])
        if anchor is None:
            continue
        data = json.loads((directory/f'{item["case"]}-{item["offset"]:02}.json').read_text())
        check(data["anchor"] == anchor, "mismatched guide or prefix")
        capture = data["capture"]
        check(capture["key"] == anchor["prefix_sha256"]+"-capture", "mismatched capture key")
        rows[item["case"]].append((features(capture["lattice"]), capture["accepted_proposals"], len(capture["emitted_ids"])))
    count = sum(map(len, rows.values()))
    check(count == complete["captured"] and count >= 16 and all(rows.values()), "incomplete corpus")

    # Fixed external costs, pooled across the two archived chat prompts.
    # Python/reasoning have no measured width-four cost on the clean fixture.
    summary = width_data["summary"]
    if "df7" in summary:
        cost = {}
        for w in (4, 7):
            lo, hi = summary[f"df{w}"]["pooled"]["ms_per_step"]
            check(lo == hi, "live round cost is ambiguous")
            cost[w] = lo
    else:
        cost = {w: summary[str(w)]["pooled"]["ms_per_step"] for w in (4, 7)}
    folds = {}
    for case, held_out in rows.items():
        train = [row for other, samples in rows.items() if other != case for row in samples]
        fold = {}
        for feature in ("geometric_peak", "concentration", "gap"):
            grid = (-1.0, .25, .5, .75, 2.0)  # includes both fixed controls
            cutoff = max(grid, key=lambda t: score(train, feature, t, cost)["modeled_tps"])
            fold[feature] = dict(threshold=cutoff, **score(held_out, feature, cutoff, cost))
        fold["fixed7"] = score(held_out, "gap", -1, cost)
        fold["fixed4"] = score(held_out, "gap", 2, cost)
        folds[case] = fold

    pooled = {}
    for policy in next(iter(folds.values())):
        values = [fold[policy] for fold in folds.values()]
        pooled[policy] = 1000*sum(r["tokens"] for r in values)/sum(r["modeled_ms"] for r in values)
    return dict(anchors=count, assumed_ms_per_step=cost, primary="geometric_peak", folds=folds, pooled_proxy_tps=pooled)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture_directory", type=Path)
    parser.add_argument("--width-data", type=Path, default=Path(__file__).with_name("S01-widths.json"))
    args = parser.parse_args()
    print(json.dumps(analyze(args.capture_directory, json.loads(args.width_data.read_text())), indent=2))
