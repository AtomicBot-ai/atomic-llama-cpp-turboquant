"""Summarize a completed F07 chat rerun. Inputs are the raw ZIP emitted by bench_chat.py."""
import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import median
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from summarize import compare, pooled


def read_run(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        arms = [json.loads(z.read(n)) for n in sorted(z.namelist()) if n[:2].isdigit() and n.endswith(".json")]
        restoration = json.loads(z.read("restoration.json"))
    assert len(arms) == 8 and restoration["health"] == "ok"
    assert len({a["profile"]["sha256"] for a in arms}) == 1
    return arms, restoration


def requests(arms):
    return {(r["case"],r["seed"]):r for a in arms for r in a["requests"] if not r["warmup"]}


def profiles(arms):
    groups = defaultdict(list)
    for a in arms:
        groups[a["engine"] + ("_f07" if a["fusion"] else "_base")].append(a)
    assert len(groups) == 4
    keys = set(requests(arms))
    assert len(keys) == 12 and {seed for name,seed in keys} == {42,43}
    data = {}
    for mode, pair in groups.items():
        rows = requests(pair)
        assert rows.keys() == keys and len(pair) == 2
        assert all(r["cap"] == 1536 and r["timings"]["cache_n"] == 0 for r in rows.values())
        if mode.startswith("dflash"):
            assert all(a["metrics"]["expert_logical_read_bytes"] == 0 for a in pair)
        summary = pooled(pair)
        summary.update(by_seed={a["seed"]:pooled([a]) for a in pair},
                       by_prompt={name:pooled(pair,name) for name in sorted({name for name,seed in keys})},
                       busy_device=[a["busy_device"] for a in pair])
        if mode.startswith("dflash"):
            accepted = sum(r["timings"]["draft_n_accepted"] for r in rows.values())
            proposed = sum(r["timings"]["draft_n"] for r in rows.values())
            summary.update(accepted=accepted,proposals=proposed,acceptance_percent=100*accepted/proposed)
        data[mode] = summary
    effects = {}
    for a,b in (("target_base","target_f07"),("dflash_base","dflash_f07"),("target_f07","dflash_f07")):
        x,y=requests(groups[a]),requests(groups[b])
        effects[a+"_to_"+b]=dict(**compare(data[a],data[b]),
                                  ttft_delta_ms=data[b]["ttft_median_ms"]-data[a]["ttft_median_ms"],
                                  same_visible=sum(x[k]["answer_sha256"]==y[k]["answer_sha256"] for k in keys),
                                  same_reasoning=sum(x[k]["reasoning_sha256"]==y[k]["reasoning_sha256"] for k in keys))
    return data,effects


def render(data, effects, restored):
    md = ["# F07 normal chat rerun on RTX Spark N1X", "",
          "Inkling 2 Mini NVFP4, one sequence, 4,096 context, Q4_0 KV and a 20,580 MiB managed budget. "
          "Each profile served the same six R08 conversations with seeds 42 and 43, temperature 1, normal EOS, "
          "a 1,536-token cap and prompt cache disabled. Each fresh server received one excluded 128-token warmup. "
          "The profile order was reversed for seed 43. All arms ran sequentially on the same F07 executable.", "",
          "| Mode | Decode updates/s | Median TTFT (ms) | HTTP wall (s) | Updates | Stop counts | GPU MHz under load¹ |",
          "|---|---:|---:|---:|---:|---|---|"]
    labels = dict(target_base="Target baseline",target_f07="Target F07",dflash_base="DFlash2 baseline",dflash_f07="DFlash2 with F07")
    for key,label in labels.items():
        v = data[key]
        mhz = " / ".join(str(round(t["median_mhz"])) if t["median_mhz"] else "n/a" for t in v["busy_device"])
        finish = ", ".join(f"{n} {s}" for s,n in v["finish"].items())
        md.append(f"| {label} | {v['updates_s']:.2f} | {v['ttft_median_ms']:.1f} | {v['wall_s']:.2f} | {v['updates']} | {finish} | {mhz} |")
    md.extend(["","¹ Per-seed median at ≥75% GPU utilization (sampled every 300 ms). Decode rate uses the sum of predicted tokens minus one per request divided by total server decode seconds. TTFT is measured at the client on the first reasoning or answer text. HTTP wall includes prefill and the sampled response length.",""])
    for effect,v in effects.items():
        a,b=effect.split("_to_")
        md.append(f"- {labels[a]} → {labels[b]}: {v['gain_percent']:+.2f}% decode rate, {v['ttft_delta_ms']:+.1f} ms median TTFT. Visible answer hashes matched on {v['same_visible']}/12 requests.")
    md+=["","DFlash2 used probabilistic sampling and seven proposals. Acceptance is measured over all measured requests, excluding warmup.",""]
    for key in ("dflash_base","dflash_f07"):
        v=data[key]
        bounds=v.get("updates_per_round")
        per_round=f" Estimated committed updates per verify round: {bounds[0]:.3f}–{bounds[1]:.3f}." if bounds else ""
        md.append(f"- {labels[key]} accepted {v['accepted']:,} of {v['proposals']:,} proposals ({v['acceptance_percent']:.2f}%)."+per_round)
    md.extend(["","| Prompt | F07 target updates/s | F07 DFlash2 updates/s | F07 target TTFT (ms) | F07 DFlash2 TTFT (ms) |",
               "|---|---:|---:|---:|---:|"])
    for name, t in data["target_f07"]["by_prompt"].items():
        d=data["dflash_f07"]["by_prompt"][name]
        md.append(f"| {name} | {t['updates_s']:.2f} | {d['updates_s']:.2f} | {t['ttft_median_ms']:.1f} | {d['ttft_median_ms']:.1f} |")
    md+=["","The JSON includes the per-prompt and per-seed measurements. Normal sampling permits different continuations between profiles. Two seeds per prompt give limited precision for small differences.","",
         f"The runner restored the registered loopback service at {restored['url']} and verified its command, executable hash and health."]
    return "\n".join(md)+"\n"


def stock_summary(directory):
    rows = []
    clocks = []
    for seed in (42,43):
        r = json.loads((directory/f"stock-{seed}.json").read_text())
        rows.extend(v for v in r["requests"] if not v["warmup"])
        samples = [line.split(",") for line in (directory/f"stock-{seed}.memory").read_text().splitlines()]
        clocks.append(median(float(v[1]) for v in samples if len(v)==4 and v[0].strip().isdigit() and float(v[3])>=75))
    assert len(rows)==12 and all(r["cap"]==1536 and r["timings"]["cache_n"]==0 for r in rows)
    updates=sum(r["timings"]["predicted_n"]-1 for r in rows)
    ms=sum(r["timings"]["predicted_ms"] for r in rows)
    return dict(updates=updates,updates_s=updates*1000/ms,ttft_median_ms=1000*median(r["ttft_s"] for r in rows),
                busy_mhz=clocks,restoration=json.loads((directory/"restoration.json").read_text()))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("raw", type=Path)
    p.add_argument("--stock",type=Path)
    args = p.parse_args()
    arms, restored = read_run(args.raw)
    data, effects = profiles(arms)
    summary = dict(profiles=data,comparisons=effects,restored=restored)
    md=render(data,effects,restored)
    if args.stock:
        stock=stock_summary(args.stock)
        history=json.loads((HERE/"history.json").read_text())
        summary.update(stock=stock,history=history)
        md+="\n## Same workload, upstream and earlier Atomic builds\n\n"
        md+="| Build and run | Decode updates/s | Median TTFT (ms) |\n|---|---:|---:|\n"
        for k,v in [("Upstream llama.cpp b12810, fresh",stock),*history["rows"].items()]:
            md+=f"| {k} | {v['updates_s']:.2f} | {v['ttft_median_ms']:.1f} |\n"
        md+="\nHistorical rows are separate sessions. Clock and power differences affect comparisons across sessions. Stock used its release CUDA libraries and native memory policy.\n"
    (HERE/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    (HERE/"RESULTS.md").write_text(md)
    dest=HERE.parent.parent/"atomic-fusion-F07-serving-2026-11-27.zip"
    with ZipFile(dest,"w",compression=ZIP_DEFLATED) as z:
        for path in [HERE/"RESULTS.md",HERE/"summary.json"]:
            z.write(path,path.name)
        for path in [HERE/"report.py",HERE/"bench_chat.py"]:
            z.write(path,"runner/serving-rerun/"+path.name)
        z.write(HERE.parent/"summarize.py","runner/summarize.py")
        z.write(args.raw,"raw.zip")
        if args.stock:
            z.write(HERE/"bench_stock.py","runner/serving-rerun/bench_stock.py")
            z.write(HERE/"history.json","runner/serving-rerun/history.json")
            for path in sorted(args.stock.iterdir()):
                z.write(path,"stock/"+path.name)
        for name in ("prompts.jsonl","resident-dflash2.json"):
            z.write(HERE.parent/"reference"/name,"runner/reference/"+name)
    with ZipFile(dest) as z:
        assert z.testzip() is None
    print((HERE/"RESULTS.md").read_text())
    print(dest, hashlib.sha256(dest.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
