"""Replay the six R08 conversations with matched F07 and DFlash2 profiles on Spark."""
import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from qualify_narrow import BASE, BENCH, MEASURE, exclusive, file_hash, gpu_memory, server


def utc():
    return datetime.now(timezone.utc).isoformat()


def profile(engine, fusion):
    # Use the exact clean F07 profiles of the fixed-token qualification.
    arm = "01" if fusion else "00"
    path, = (ROOT / "abba_depth01").glob(arm + "-*.json")
    cfg = json.loads(path.read_text())["profile"]
    if engine == "dflash":
        spec = json.loads((BASE["OLD"] / "resident-dflash2.json").read_text())
        cfg["cmd"] = [cfg["cmd"][0], *spec["cmd"][1:]]
        cfg["env"] = {**spec["env"], **cfg["env"]}
        cfg["env"].pop("GGML_CUDA_GRAPH_DEBUG", None)
    assert file_hash(cfg["cmd"][0]) == cfg["sha256"]
    return cfg


def measure_arm(out, index, engine, fusion, seed):
    label = f"{index:02}-{engine}-{'f07' if fusion else 'base'}-{seed}"
    cfg = profile(engine, fusion)
    log = out / (label + ".log")
    memory = out / (label + ".memory")
    record = dict(engine=engine, fusion=fusion, seed=seed, profile=cfg, started_utc=utc(), requests=[])
    print(label, "starting", flush=True)
    with server(BENCH, cfg, log) as url, gpu_memory(memory):
        for name, sample_seed in [("lunch", 44), *((name, seed) for name in BASE["cases"])]:
            warm = sample_seed == 44
            cap = 128 if warm else 1536
            item = MEASURE(url, dict(messages=BASE["cases"][name], seed=sample_seed, temperature=1.0,
                                     max_tokens=cap, stream=True, cache_prompt=False))
            item["answer_sha256"] = hashlib.sha256(item.pop("answer").encode()).hexdigest()
            item.update(case=name, seed=sample_seed, cap=cap, warmup=warm)
            record["requests"].append(item)
            timing = item["timings"]
            print(label, name, sample_seed, timing["predicted_n"], round(item["ttft_s"]*1000), flush=True)
            assert (timing.get("draft_n", 0) > 0) == (engine == "dflash")
        record["metrics"] = BENCH["engine_metrics"](url)
        assert record["metrics"]["budget_applied_bytes"] == 20580 * 2**20
        assert 0 < record["metrics"]["budget_high_water_bytes"] <= record["metrics"]["budget_applied_bytes"]
        record["gpu"] = BASE["telemetry"]()
    samples = [line.split(",") for line in memory.read_text().splitlines()]
    samples = [[float(v.strip()) for v in row] for row in samples if len(row)==4 and row[0].strip().isdigit()]
    busy = [row for row in samples if row[3] >= 75]
    record["device_memory_mib"] = {"peak":max(row[0] for row in samples), "interval_ms":300}
    record["busy_device"] = {"samples":len(busy), "median_mhz":median(row[1] for row in busy) if busy else None,
                             "median_watts":median(row[2] for row in busy) if busy else None}
    if engine == "dflash":
        pattern = r"draft acceptance = .*?\(\s*(\d+) accepted /\s*(\d+) generated\), mean len =\s+([.\d]+)"
        summaries = re.findall(pattern, log.read_text(errors="replace"))
        if len(summaries) == len(record["requests"]):
            for item, (accepted, generated, mean) in zip(record["requests"], summaries):
                a,t = int(accepted),int(generated)
                assert (a,t) == (item["timings"]["draft_n_accepted"], item["timings"]["draft_n"])
                bounds = [n for n in range(1,t+1) if abs(1+a/n-float(mean)) <= 0.00500001]
                if bounds:
                    item["round_bounds"] = [min(bounds),max(bounds)]
    record["finished_utc"] = utc()
    (out / (label + ".json")).write_text(json.dumps(record, indent=1))
    return record


def main():
    p = argparse.ArgumentParser()
    p.add_argument("directory", type=Path)
    out = p.parse_args().directory.resolve()
    out.mkdir(exist_ok=False)
    assert len(BASE["cases"]) == 6
    order = [("dflash", False), ("dflash", True), ("target", True), ("target", False)]
    jobs = [(engine, fusion, seed) for seed, modes in [(42, order), (43, reversed(order))] for engine, fusion in modes]
    with exclusive(out):
        for index, (engine, fusion, seed) in enumerate(jobs):
            measure_arm(out, index, engine, fusion, seed)
    with ZipFile(out.with_suffix(".zip"), "x", compression=ZIP_DEFLATED) as archive:
        for path in sorted(out.glob("*.json")):
            archive.write(path, path.name)
        for path in sorted(out.glob("*.memory")):
            archive.write(path, path.name)


if __name__ == "__main__":
    main()
