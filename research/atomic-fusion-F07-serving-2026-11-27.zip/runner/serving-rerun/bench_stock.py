"""Run upstream b12810 on the same chat workload following the Atomic arms."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from qualify_narrow import BASE, BENCH, MEASURE, exclusive, file_hash, gpu_memory, server

out = ROOT / sys.argv[1]
out.mkdir(exist_ok=False)
cmd, flags, digest = BASE["profile"]("stock")
assert file_hash(cmd[0]) == digest
cfg = dict(cmd=cmd, env=flags, sha256=digest)
with exclusive(out):
    for seed in (42, 43):
        rows = []
        with server(BENCH,cfg,out/f"stock-{seed}.log") as url, gpu_memory(out/f"stock-{seed}.memory"):
            for name, s in [("lunch",44), *((name,seed) for name in BASE["cases"])]:
                cap = 128 if s == 44 else 1536
                r = MEASURE(url,dict(messages=BASE["cases"][name],seed=s,temperature=1.0,max_tokens=cap,
                                     stream=True,cache_prompt=False))
                del r["answer"]
                rows.append(dict(case=name,seed=s,warmup=s==44,cap=cap,**r))
                print(name,s,r["timings"]["predicted_n"],flush=True)
        (out/f"stock-{seed}.json").write_text(json.dumps(dict(profile=cfg,requests=rows)))
