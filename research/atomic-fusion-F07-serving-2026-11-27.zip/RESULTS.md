# F07 normal chat rerun on RTX Spark N1X

Inkling 2 Mini NVFP4, one sequence, 4,096 context, Q4_0 KV and a 20,580 MiB managed budget. Each profile served the same six R08 conversations with seeds 42 and 43, temperature 1, normal EOS, a 1,536-token cap and prompt cache disabled. Each fresh server received one excluded 128-token warmup. The profile order was reversed for seed 43. All arms ran sequentially on the same F07 executable.

| Mode | Decode updates/s | Median TTFT (ms) | HTTP wall (s) | Updates | Stop counts | GPU MHz under load¹ |
|---|---:|---:|---:|---:|---|---|
| Target baseline | 35.49 | 316.8 | 207.41 | 7053 | 11 stop, 1 length | 1430 / 1443 |
| Target F07 | 41.10 | 329.2 | 180.88 | 7076 | 11 stop, 1 length | 1423 / 1423 |
| DFlash2 baseline | 61.75 | 386.5 | 130.42 | 7628 | 11 stop, 1 length | 1462 / 1456 |
| DFlash2 with F07 | 61.28 | 385.7 | 131.37 | 7628 | 11 stop, 1 length | 1456 / 1456 |

¹ Per-seed median at ≥75% GPU utilization (sampled every 300 ms). Decode rate uses the sum of predicted tokens minus one per request divided by total server decode seconds. TTFT is measured at the client on the first reasoning or answer text. HTTP wall includes prefill and the sampled response length.

- Target baseline → Target F07: +15.83% decode rate, +12.4 ms median TTFT. Visible answer hashes matched on 10/12 requests.
- DFlash2 baseline → DFlash2 with F07: -0.77% decode rate, -0.9 ms median TTFT. Visible answer hashes matched on 12/12 requests.
- Target F07 → DFlash2 with F07: +49.08% decode rate, +56.4 ms median TTFT. Visible answer hashes matched on 0/12 requests.

DFlash2 used probabilistic sampling and seven proposals. Acceptance is measured over all measured requests, excluding warmup.

- DFlash2 baseline accepted 5,820 of 12,755 proposals (45.63%). Estimated committed updates per verify round: 4.184–4.184.
- DFlash2 with F07 accepted 5,820 of 12,755 proposals (45.63%). Estimated committed updates per verify round: 4.184–4.184.

| Prompt | F07 target updates/s | F07 DFlash2 updates/s | F07 target TTFT (ms) | F07 DFlash2 TTFT (ms) |
|---|---:|---:|---:|---:|
| briefing | 40.65 | 68.30 | 3193.6 | 2044.9 |
| dispatch | 41.45 | 62.31 | 326.9 | 367.0 |
| lunch | 41.84 | 46.76 | 339.4 | 382.8 |
| python | 41.29 | 53.00 | 326.1 | 381.8 |
| reasoning | 41.46 | 65.84 | 322.1 | 515.7 |
| sky | 41.63 | 51.82 | 285.7 | 304.1 |

The JSON includes the per-prompt and per-seed measurements. Normal sampling permits different continuations between profiles. Two seeds per prompt give limited precision for small differences.

The runner restored the registered loopback service at http://127.0.0.1:8080 and verified its command, executable hash and health.

## Same workload, upstream and earlier Atomic builds

| Build and run | Decode updates/s | Median TTFT (ms) |
|---|---:|---:|
| Upstream llama.cpp b12810, fresh | 46.83 | 260.9 |
| Upstream llama.cpp b12810, archive R08 | 50.29 | 278.9 |
| Atomic R08 target-only | 44.63 | 300.6 |
| Atomic R08 DFlash2 | 66.91 | 395.3 |
| Atomic F06 target-only | 40.58 | 315.0 |

Historical rows are separate sessions. Clock and power differences affect comparisons across sessions. Stock used its release CUDA libraries and native memory policy.
